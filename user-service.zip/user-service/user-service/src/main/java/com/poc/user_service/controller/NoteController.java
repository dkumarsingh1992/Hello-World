package com.poc.user_service.controller;



import com.poc.user_service.dto.CreateNoteRequest;
import com.poc.user_service.model.Note;
import com.poc.user_service.model.User;
import com.poc.user_service.service.NoteService;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/api/notes")
@Validated
public class NoteController {
    private final NoteService service;

    public NoteController(NoteService service)
    {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Note> create(@RequestBody @Validated CreateNoteRequest req, Principal principal) {
        User owner = new User(); owner.setId( /* resolve from principal later */ 1L );
        Note n = new Note(); n.setTitle(req.title()); n.setBody(req.body()); n.setOwner(owner);
        return ResponseEntity.ok(service.create(n));
    }

    @GetMapping("/me")
    public List<Note> myNotes(Principal principal) throws Exception {
        Long ownerId = 1L; // replace with actual principal -> userId mapping
        if(1==1)
        throw new Exception("New Exception");
        return service.forUser(ownerId);
    }
}
