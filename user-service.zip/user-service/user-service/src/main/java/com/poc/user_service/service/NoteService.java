package com.poc.user_service.service;

import com.poc.user_service.model.Note;
import com.poc.user_service.repository.NoteRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@Transactional
public class NoteService {
    private final NoteRepository repo;

    public NoteService(NoteRepository repo) {
        this.repo = repo;
    }

    public Note create(Note n) { return repo.save(n); }
    public List<Note> forUser(Long userId) { return repo.findByOwnerId(userId); }
    public void delete(Long id) { repo.deleteById(id); }
}
