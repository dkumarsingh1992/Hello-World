package com.poc.user_service.logger;



import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

@Aspect @Component
public class LoggingAspect {

    // Pointcut: any public method in our services
    @Pointcut("execution(public * com.example.notes..*Service.*(..))")
    public void serviceMethods() {}

    @Around("serviceMethods()")
    public Object logAndProtect(ProceedingJoinPoint pjp) throws Throwable {
        long start = System.nanoTime();
        try {
            return pjp.proceed();
        } catch (Exception ex) {
            throw new RuntimeException("Service failed: " + pjp.getSignature().toShortString(), ex);
        } finally {
            long ms = (System.nanoTime() - start) / 1_000_000;
            System.out.println("[AOP] " + pjp.getSignature() + " took " + ms + " ms");
        }
    }
}
