package com.poc.user_service.dto;


import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record CreateNoteRequest(
        @NotBlank
        @Size(min = 1, max = 200)
        String title,
        String body
) {
}

