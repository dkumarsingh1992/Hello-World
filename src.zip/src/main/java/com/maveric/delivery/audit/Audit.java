package com.maveric.delivery.audit;

import com.maveric.delivery.model.IdentifiedEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "audit")
public class Audit extends IdentifiedEntity {
    private String username;
    private String methodName;
    private String status;
    private UUID oid;
    private String action;
    private String auditEntity;
    private String requestUrl;
    private LocalDateTime timestamp;
}