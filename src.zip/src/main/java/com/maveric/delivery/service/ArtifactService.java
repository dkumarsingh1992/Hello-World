package com.maveric.delivery.service;


import com.maveric.delivery.requestdto.ArtifactRequestDto;
import com.maveric.delivery.responsedto.ArtifactDownloadDto;
import com.maveric.delivery.responsedto.ArtifactListDto;

import javax.naming.directory.InvalidAttributesException;
import java.io.IOException;

import java.util.List;

import java.util.UUID;

public interface ArtifactService {
  ArtifactListDto saveArtifact(ArtifactRequestDto artifactRequestDto, UUID oid,Long projectId) throws InvalidAttributesException, IOException;
  List<ArtifactListDto> getAllArtifacts(UUID oid, Long projectId);

  void deleteArtifact(UUID userId, Long artifactId);

  ArtifactDownloadDto getAttachmentDetails(Long artifactId);

  ArtifactListDto checkAndDeleteAttachment(Long artifactId);


}
