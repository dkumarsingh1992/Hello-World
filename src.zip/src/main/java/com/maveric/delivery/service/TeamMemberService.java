package com.maveric.delivery.service;

import com.maveric.delivery.requestdto.TeamMemberDto;
import com.maveric.delivery.responsedto.TeamMemberResponseDto;
import com.maveric.delivery.responsedto.TeamMemberResponseListDto;

import java.util.List;
import java.util.UUID;

public interface TeamMemberService {
    TeamMemberResponseDto saveTeamMember(TeamMemberDto teamMemberDto, UUID oid,Long projectId);

    List<TeamMemberResponseListDto> getAllTeamMembers(Long projectId);

    TeamMemberResponseDto editTeamMember(TeamMemberDto teamMemberDto, UUID oid, Long teamMemberId);
    TeamMemberResponseListDto getTeamMemberById(Long teamMemberId);
}
