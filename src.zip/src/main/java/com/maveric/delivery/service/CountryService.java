package com.maveric.delivery.service;

import com.maveric.delivery.model.Country;

import java.util.List;

public interface CountryService {
    public List<Country> getAllCountries();
}
