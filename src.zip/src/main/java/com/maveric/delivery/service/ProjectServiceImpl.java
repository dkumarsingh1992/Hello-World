package com.maveric.delivery.service;

import com.maveric.delivery.exception.*;
import com.maveric.delivery.model.*;
import com.maveric.delivery.model.embedded.*;
import com.maveric.delivery.model.embedded.ProjectStatus;
import com.maveric.delivery.repository.*;
import com.maveric.delivery.requestdto.AccountRoles;
import com.maveric.delivery.requestdto.DeliveryInformationDto;
import com.maveric.delivery.requestdto.ProjectRequestDto;
import com.maveric.delivery.requestdto.ProjectsListDto;
import com.maveric.delivery.responsedto.ProjectListResponseDto;
import com.maveric.delivery.responsedto.ProjectResponseDto;
import com.maveric.delivery.utils.UtilMethods;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;
import static com.maveric.delivery.utils.Constants.*;
import static com.maveric.delivery.utils.Constants.DELIVERY_PARTNER;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProjectServiceImpl implements ProjectService {

    private final ProjectRepository projectRepository;
    private final AccountRepository accountRepository;
    private final DedRolesRepository dedRolesRepository;
    private final UserServiceImpl userServiceImpl;
    private final UtilMethods utils;
    private final BusinessSubverticalRepository businessSubverticalRepository;
    private final FrequencyRepository frequencyRepository;
    private final EngagementTypeRepository engagementTypeRepository;
    private final AzureUserRepository azureUserRepository;


    @Override
    public ProjectResponseDto saveProject(ProjectRequestDto projectDto) {
        Optional<Account> account = accountRepository.findById(projectDto.getAccountId());
        if(account.isEmpty()){
            log.error("ProjectServiceImpl::saveProject::  Project id not found");
            throw new AccountNotFoundException("Account with ID " + projectDto.getAccountId() + " not found");
        }
        List<Project> projectList = projectRepository.findByAccountId(projectDto.getAccountId());
        if (projectList != null && projectList.stream().anyMatch(p -> p.getProjectName().equals(projectDto.getProjectName()))) {
            log.error("ProjectServiceImpl::saveProject::error - Duplicate project name");
            throw new DuplicateProjectsException("Project name '" + projectDto.getProjectName() + "' already exists");
        }
        LocalDate startDate = Instant.ofEpochMilli(projectDto.getStartDate())
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
        if (startDate.isAfter(LocalDate.now())) {
            log.error("ProjectServiceImpl::Future date is not allowed::error");
            throw new ProjectDateException("Future date is not allowed: start date must be a past or current date");
        }

        //check project start date is after account start date
         if (isValidProjectAndAccountDate(projectDto.getStartDate(), account.get().getDateOnboarded())) {
            log.error("ProjectServiceImpl::Project start date::error");
            throw new ProjectDateException("Project start date should be after account onboarded date");
        }

        validateBusinessSubVerticalAndFrequencyAndEngagementType(projectDto.getBusinessSubVertical(),
                projectDto.getDeliveryInfo().getFrequency(),projectDto.getEngagementType());
        OtherInformation otherInformation = projectDto.getOtherInformation();
        if (otherInformation != null) {
            List<ExternalSystemInfo> externalSystemInfoList = otherInformation.getExternalSystemInfo();
            if (externalSystemInfoList != null) {
                for (ExternalSystemInfo info : externalSystemInfoList) {
                    if (info.getId() == null || info.getName() == null) {
                        throw new IllegalArgumentException("Both id and name are required for external system info");
                    }
                }
            }
            log.info("OtherInformation is null.");
        }
        utils.checkValidRole(projectDto.getAccountId(),projectDto.getDeliveryInfo().getAccountPartner().getUserId(),"AP");
        utils.checkValidRole(projectDto.getAccountId(),projectDto.getDeliveryInfo().getEngagementPartner().getUserId(), "EP");
        utils.checkValidRole(projectDto.getAccountId(),projectDto.getDeliveryInfo().getDeliveryPartner().getUserId(),"DP");
        Project project = new Project();
        log.info("ProjectServiceImpl::existsByAccountName::started");
        BeanUtils.copyProperties(projectDto, project);
        project.setDedRoles(mapToDedRoles(projectDto));
        project.setAccountName(account.get().getAccountName());
        project.setStatus(ProjectStatus.Active);
        DeliveryInformation deliveryInformation = new DeliveryInformation();
        BeanUtils.copyProperties(projectDto.getDeliveryInfo(), deliveryInformation);
        project.setDeliveryInfo(deliveryInformation);
        project.setEndDate(null);
        projectRepository.save(project);
        ProjectResponseDto projectResponseDto= mapProjectToResponseDto(project);
        userServiceImpl.saveRole(projectResponseDto);
        return projectResponseDto;
    }

private boolean isValidProjectAndAccountDate(Long prStartDate, Long accStartDate){
    LocalDate projectStartDate = Instant.ofEpochMilli(prStartDate)
            .atZone(ZoneId.systemDefault())
            .toLocalDate();
    LocalDate accountStartDate = Instant.ofEpochMilli(accStartDate)
            .atZone(ZoneId.systemDefault())
            .toLocalDate();
    return !projectStartDate.isAfter(accountStartDate);
}


    @Override
    public ProjectResponseDto editProject(ProjectRequestDto projectDto,Long projectId)  {
        Optional<Account> account = accountRepository.findById(projectDto.getAccountId());
        if(account.isEmpty()){
            log.error("ProjectServiceImpl::editProject:: Account id not found");
            throw new AccountNotFoundException("Account with ID " + projectDto.getAccountId() + " not found");
        }
        Optional<Project> projectOptional = projectRepository.findByIdAndAccountId(projectId,projectDto.getAccountId());
        if (projectOptional.isPresent()) {
            Project project = projectOptional.get();
            if(!project.getProjectName().trim().equals(projectDto.getProjectName().trim())){
                List<Project> projectList = projectRepository.findByAccountId(projectDto.getAccountId());
                if (projectList.stream().anyMatch(p -> p.getProjectName().equals(projectDto.getProjectName()))) {
                    log.error("ProjectServiceImpl::saveProject::error - Duplicate project name");
                    throw new DuplicateProjectsException("Project name '" + projectDto.getProjectName() + "' already exists");
                }
            }
            LocalDate startDate = Instant.ofEpochMilli(projectDto.getStartDate())
                    .atZone(ZoneId.systemDefault())
                    .toLocalDate();
            if (startDate.isAfter(LocalDate.now())) {
                log.error("ProjectServiceImpl::existsByAccountName::error");
                throw new ProjectDateException("Future date is not allowed: start date must be a past or current date");
            }
            if(projectDto.getEndDate() != null) {
                LocalDate endDate = Instant.ofEpochMilli(projectDto.getEndDate())
                        .atZone(ZoneId.systemDefault())
                        .toLocalDate();
                if (startDate.isAfter(endDate)) {
                    log.error("ProjectServiceImpl::existsByAccountName::error");
                    throw new ProjectDateException("End date must be a after start date");
                }
            }
            if (isValidProjectAndAccountDate(projectDto.getStartDate(), account.get().getDateOnboarded())) {
                log.error("ProjectServiceImpl::Edit: Project start date::error");
                throw new ProjectDateException("Project start date should be after account onboarded date");
            }
            validateBusinessSubVerticalAndFrequencyAndEngagementType(projectDto.getBusinessSubVertical(),
                    projectDto.getDeliveryInfo().getFrequency(),projectDto.getEngagementType());
            OtherInformation otherInformation = projectDto.getOtherInformation();
            if (otherInformation != null) {
                List<ExternalSystemInfo> externalSystemInfoList = otherInformation.getExternalSystemInfo();
                if (externalSystemInfoList != null) {
                    for (ExternalSystemInfo info : externalSystemInfoList) {
                        if (info.getId() == null || info.getName() == null) {
                            throw new IllegalArgumentException("Both id and name are required for external system info");
                        }
                    }
                }
            }
            if(projectDto.getStatus() == null){
                log.error("ProjectServiceImpl::editProject:: Status should not be null");
                throw new ProjectStatusException("Status should not be null");
            }

            /*if(projectDto.getStatus().equals(ProjectStatus.Delete)){
                if(!(userServiceImpl.getHighestRole(oid,null,null)).equalsIgnoreCase(SUPER_ADMIN)){
                    throw new CustomException("User is not authorised to delete the project", HttpStatus.UNAUTHORIZED);
                }
            }*/
            utils.checkValidRole(projectDto.getAccountId(),projectDto.getDeliveryInfo().getAccountPartner().getUserId(),"AP");
            utils.checkValidRole(projectDto.getAccountId(),projectDto.getDeliveryInfo().getEngagementPartner().getUserId(), "EP");
            utils.checkValidRole(projectDto.getAccountId(),projectDto.getDeliveryInfo().getDeliveryPartner().getUserId(),"DP");
            BeanUtils.copyProperties(projectDto, project);
            project.setDedRoles(mapToDedRoles(projectDto));
            project.setAccountName(account.get().getAccountName());
            DeliveryInformation deliveryInformation = new DeliveryInformation();
            BeanUtils.copyProperties(projectDto.getDeliveryInfo(), deliveryInformation);
            project.setDeliveryInfo(deliveryInformation);
            projectRepository.save(project);
            ProjectResponseDto projectResponseDto=mapProjectToResponseDto(project);
            dedRolesRepository.deleteByAccountIdAndProjectId(projectDto.getAccountId(),projectId);
            userServiceImpl.saveRole(projectResponseDto);
            return projectResponseDto;
        } else {
            log.error("ProjectServiceImpl::editProject:: Incorrect combination of account id and project id");
            throw new ProjectNotFoundException("Incorrect combination of account id and project id");
        }

    }


    public ProjectResponseDto getProjectById(Long projectId,UUID oid)
    {
        Optional<Project> optionalProject = projectRepository.findById(projectId);

        if (optionalProject.isPresent()) {
            Project project = optionalProject.get();
            Long accountId = project.getAccountId();
            Optional<Account> optionalAccount = accountRepository.findById(accountId);
            ProjectResponseDto projectResponseDto= mapProjectToResponseDto(project);
            projectResponseDto.setAccountName(optionalAccount.get().getAccountName());
            projectResponseDto.setProjectId(project.getId());
            if (!userServiceImpl.getHighestRole(oid,accountId,projectId).equalsIgnoreCase(SUPER_ADMIN_)) {
                String highestRole = userServiceImpl.getHighestRole(oid, accountId, projectId);
                if (!highestRole.isBlank()) {
                    projectResponseDto.setPrivileges(utils.getPrivilegesString(highestRole, List.of( PROJECTS,ARTIFACTS,TEAM_MEMBERS,ASSESSMENTS)));
                    return projectResponseDto;
                }
                projectResponseDto.setPrivileges(List.of(NO_ACCESS));
                return projectResponseDto;
            }
            projectResponseDto.setPrivileges(List.of(FULL_ACCESS));

            log.info("ProjectServiceImpl::getProjectById:: call ended");
            return projectResponseDto;
        } else {
            log.error("ProjectServiceImpl::getProjectById:: No id found");
            throw new ProjectNotFoundException("Project with ID " + projectId + " not found");
        }
    }



    private List<DedRoles> mapToDedRoles(ProjectRequestDto projectDto) {
        List<DedRoles> dedRoles = new ArrayList<>();
        Set<String> existingUserIds = new HashSet<>();
        addDedRoles(projectDto.getDeliveryInfo().getDeliveryManager(), existingUserIds, dedRoles,DELIVERY_MANAGER);
        addDedRoles(projectDto.getDeliveryInfo().getAccountPartner(), existingUserIds, dedRoles,ACCOUNT_PARTNER);
        addDedRoles(projectDto.getDeliveryInfo().getEngagementPartner(), existingUserIds, dedRoles,ENGAGEMENT_PARTNER);
        addDedRoles(projectDto.getDeliveryInfo().getDeliveryPartner(), existingUserIds, dedRoles,DELIVERY_PARTNER);

        return dedRoles;
    }

    private void addDedRoles(AccountRoles role, Set<String> existingUserIds, List<DedRoles> dedRoles,String roleName) {
        userServiceImpl.checkAndAddUserId(existingUserIds, String.valueOf(role.getUserId()));
        dedRoles.add(new DedRoles(role.getUserId(), null, null, role.getName(), mapRoleName(roleName)));
    }

    private String mapRoleName(String roleName) {
        return switch (roleName) {
            case DELIVERY_MANAGER -> DM;
            case ACCOUNT_PARTNER -> AP;
            case ENGAGEMENT_PARTNER -> EP;
            case DELIVERY_PARTNER -> DP;
            default -> roleName;
        };
    }

    private ProjectResponseDto mapProjectToResponseDto(Project project) {
        ProjectResponseDto responseDto = new ProjectResponseDto();
        BeanUtils.copyProperties(project, responseDto);
        responseDto.setProjectId(project.getId());
        responseDto.setIsBillable(project.getIsBillable().equals(true)?YES:NO);
        DeliveryInformationDto deliveryInformationDto = new DeliveryInformationDto();
        if (project.getDeliveryInfo() != null) {
            BeanUtils.copyProperties(project.getDeliveryInfo(), deliveryInformationDto);
        }
        responseDto.setDeliveryInfo(deliveryInformationDto);
        deliveryInformationDto.setDeliveryManager(returnUserRole(project.getDedRoles(), DM));
        deliveryInformationDto.setAccountPartner(returnUserRole(project.getDedRoles(), AP));
        deliveryInformationDto.setEngagementPartner(returnUserRole(project.getDedRoles(), EP));
        deliveryInformationDto.setDeliveryPartner(returnUserRole(project.getDedRoles(), DP));
        return responseDto;
    }


    private AccountRoles returnUserRole(List<DedRoles> dedRoles, String roleName) {
        for (DedRoles role : dedRoles) {
            if (roleName.equals(role.getRole())) {
                return new AccountRoles(role.getOid(), role.getName());
            }
        }
        return null;
    }

    @Override
    public boolean validateProjectName(Long accountId, String value) {
         Optional<Account> account=accountRepository.findById(accountId);
         if(account.isEmpty()){
             log.error("ProjectServiceImpl::validateProjectName:: Account not found");
             throw new AccountNotFoundException("Account ID "+account+" not found");
         }
        List<Project> projectList = projectRepository.findByAccountId(accountId);
        if(!projectList.isEmpty()){
            return projectList.stream().noneMatch(project -> project.getProjectName().trim().equalsIgnoreCase(value));
        }else {
            return true;
        }
    }
    public ProjectsListDto getProjectDetailsList(UUID oid, Long accountId)  {
        ProjectsListDto projectsListDto=new ProjectsListDto();
        List<ProjectListResponseDto> responseList=new ArrayList<>();
        log.info("ProjectServiceImpl::getProjectDetailsList:: call started");

        ProjectsListDto projectIdSet = getProjectId(oid,accountId,projectsListDto);

        if (projectIdSet.getProjectsList().isEmpty()) {
            return new ProjectsListDto(Collections.emptyList(),Collections.emptySet(),Collections.emptyList());
        } else
            responseList = getProjectDetails(projectIdSet.getProjectsList());
        log.info("ProjectServiceImpl::getProjectDetailsList:: call ended");
        projectsListDto.setProjectListResponseDtos(responseList);
        return projectsListDto;



    }


    public ProjectsListDto getProjectId(UUID oid, Long accountId,ProjectsListDto projectsListDto){
        Set<Long> projectIdSet=new HashSet<>();
        List<DedRoles> resultAccount;
       String highestRole=userServiceImpl.getHighestRole(oid,null,null);
        List<String> privileges=utils.getPrivilegesString(highestRole,List.of(ACCOUNTS,PROJECTS));
        List<String> privilegesAccLevel = null;
        if(accountId!=0) {
            String highestRoleAccLevel = userServiceImpl.getHighestRole(oid, accountId, null);
            privilegesAccLevel = utils.getPrivilegesString(highestRoleAccLevel, List.of(ACCOUNTS, PROJECTS));
        }
        if( accountId==0&& (highestRole.equalsIgnoreCase(SUPER_ADMIN_)
               ||privileges.contains(ACCOUNTS_VIEW_ALL))){
            resultAccount=dedRolesRepository.findAll();
        }else if (accountId!=0 && highestRole.equalsIgnoreCase(SUPER_ADMIN_)){
            resultAccount = dedRolesRepository.findByAccountId(accountId);
            projectsListDto.setPrivileges(List.of(FULL_ACCESS));
        }else if (accountId==0 && privileges.contains(ACCOUNTS_VIEW_ASSOCIATED)){
            resultAccount = dedRolesRepository.findByOid(oid);
        }else if((accountId!=0)&&privilegesAccLevel.contains(PROJECTS_VIEW_ALL)){
            projectsListDto.setPrivileges(utils.getPrivilegesString(userServiceImpl.getHighestRole(oid,accountId,null), List.of(PROJECTS)));
            resultAccount = dedRolesRepository.findByAccountId(accountId);
        }else if((accountId!=0)&&privilegesAccLevel.contains(PROJECTS_VIEW_ASSOCIATED)){
            projectsListDto.setPrivileges(utils.getPrivilegesString(userServiceImpl.getHighestRole(oid,accountId,null), List.of(PROJECTS)));
            resultAccount = dedRolesRepository.findByOidAndAccountId(oid, accountId);
        }else {
            return new ProjectsListDto(Collections.emptyList(),Collections.emptySet(),Collections.emptyList());
        }
        if(CollectionUtils.isEmpty(resultAccount)){
            return new ProjectsListDto(Collections.emptyList(),Collections.emptySet(),Collections.emptyList());
        }else
            for(DedRoles obj:resultAccount){
                if(obj.getAccountId()!=null) {
                    if (obj.getProjectId() != null) {
                        projectIdSet.add(obj.getProjectId());
                    }
                }

            }
        projectsListDto.setProjectsList(projectIdSet);
            return projectsListDto;
    }

    public   List<ProjectListResponseDto> getProjectDetails(Set<Long> projectIdSet){
        List<ProjectListResponseDto>  projectList=new ArrayList<>();
        List<Project> resultProject = projectRepository.findByIdIn(projectIdSet);
        for(Project project:resultProject) {
            ProjectListResponseDto projectListDto = setProjectListResponseDetails(project);
            projectList.add(projectListDto);
        }

        if(CollectionUtils.isEmpty(projectList)){
            return Collections.emptyList();
        }else
            return projectList;

    }



    public ProjectListResponseDto setProjectListResponseDetails(Project projectDetails) {
        ProjectListResponseDto projectListDto = new ProjectListResponseDto();
        projectListDto.setId(projectDetails.getId());
        projectListDto.setName(projectDetails.getProjectName());
        projectListDto.setStatus(projectDetails.getStatus());
        projectListDto.setCustomerLOB(projectDetails.getCustomerLOB());
        projectListDto.setIsBillable(projectDetails.getIsBillable().equals(true)?YES:NO);
        projectListDto.setStartDate(projectDetails.getStartDate());
        projectListDto.setEndDate(projectDetails.getEndDate());

        for (DedRoles dedRolesDto : projectDetails.getDedRoles()) {
            if (dedRolesDto.getRole().equalsIgnoreCase("DM"))
                projectListDto.setDeliveryManager(dedRolesDto.getName());
            else if (dedRolesDto.getRole().equalsIgnoreCase("DP"))
                projectListDto.setDeliveryPartner(dedRolesDto.getName());
            else if (dedRolesDto.getRole().equalsIgnoreCase("EP"))
                projectListDto.setEngagementPartner(dedRolesDto.getName());
            else if (dedRolesDto.getRole().equalsIgnoreCase("AP"))
                projectListDto.setAccountPartner(dedRolesDto.getName());

        }
        return projectListDto;


    }

    private void validateBusinessSubVerticalAndFrequencyAndEngagementType(String subVertical,String frequency,
                                                                         String engagementType){
        List<BusinessSubvertical> businessVerticals =businessSubverticalRepository.findAll();
        if(businessVerticals.stream().noneMatch(businessSubvertical ->
                businessSubvertical.getName().trim().equals(subVertical.trim()))){
            throw new IllegalArgumentException("Provided business sub vertical is incorrect");
        }

        List<Frequency> frequencies =frequencyRepository.findAll();
        if(frequencies.stream().noneMatch(frequency1 ->
                frequency1.getName().trim().equals(frequency.trim()))){
            throw new IllegalArgumentException("Provided frequency is incorrect");
        }

        List<EngagementType> engagementTypes =engagementTypeRepository.findAll();
        if(engagementTypes.stream().noneMatch(engagementType1 ->
                engagementType1.getName().trim().equals(engagementType))){
            throw new IllegalArgumentException("Provided engagement type is incorrect");
        }

    }


}
