package com.maveric.delivery.service;

import com.maveric.delivery.mapper.PrivilegesMapper;
import com.maveric.delivery.model.Privileges;
import com.maveric.delivery.repository.PrivilegesRepository;
import com.maveric.delivery.requestdto.PrivilegesDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class PrivilegesServiceImpl implements PrivilegesService {

    private final PrivilegesRepository privilegesRepository;

    @Override
    public List<PrivilegesDto> getPrivileges() {
        log.debug("PrivilegesServiceImpl.getPrivileges: start");
        List<Privileges> privileges = privilegesRepository.findAll();
        log.debug("PrivilegesServiceImpl.getPrivileges: end ");
        return PrivilegesMapper.MAPPER.toDtoList(privileges);
    }

}
