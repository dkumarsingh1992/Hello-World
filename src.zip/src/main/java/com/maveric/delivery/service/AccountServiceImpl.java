package com.maveric.delivery.service;

import com.maveric.delivery.exception.*;
import com.maveric.delivery.model.Account;
import com.maveric.delivery.model.AzureUsers;
import com.maveric.delivery.model.Project;
import com.maveric.delivery.model.embedded.AccountStatus;
import com.maveric.delivery.model.embedded.DedRoles;
import com.maveric.delivery.model.embedded.ProjectStatus;
import com.maveric.delivery.repository.AccountRepository;
import com.maveric.delivery.repository.AzureUserRepository;
import com.maveric.delivery.repository.DedRolesRepository;
import com.maveric.delivery.repository.ProjectRepository;
import com.maveric.delivery.requestdto.AccountRequestDto;
import com.maveric.delivery.requestdto.AccountRoles;
import com.maveric.delivery.requestdto.AccountSummaryCountDto;
import com.maveric.delivery.requestdto.AccountSummaryDto;
import com.maveric.delivery.responsedto.AccountMemberDto;
import com.maveric.delivery.requestdto.*;
import com.maveric.delivery.responsedto.AccountNamesResponseDto;
import com.maveric.delivery.responsedto.AccountResponseDto;
import com.maveric.delivery.utils.UtilMethods;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.stream.Collectors;

import java.util.*;

import static com.maveric.delivery.utils.Constants.*;


@Service
@RequiredArgsConstructor
@Slf4j
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;
    private final UserService userService;
    private final DedRolesRepository dedRolesRepository;
    private final UserServiceImpl userServiceImpl;
    private final UtilMethods utils;
    private final AzureUserRepository azureUserRepository;
    private final ProjectRepository projectRepository;
    private final ProjectServiceImpl projectServiceImpl;

    @Override
    public AccountResponseDto createAccount(AccountRequestDto accountRequestDto) {
        if (accountRepository.existsByAccountName(accountRequestDto.getAccountName())) {
            log.error("AccountServiceImlp::existsByAccountName::error");
            throw new DuplicateAccountException("Account name '" + accountRequestDto.getAccountName() + "' already exists");
        }
        log.info("AccountServiceImpl::createAccount:: call started");
        if (accountRequestDto.getStatus() != AccountStatus.Active) {
            throw new IllegalArgumentException("Account status is invalid");
        }
        LocalDate startDate = Instant.ofEpochMilli(accountRequestDto.getDateOnboarded())
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
        if (startDate.isAfter(LocalDate.now())) {
            log.error("AccountServiceImpl::createAccount::error");
            throw new ProjectDateException("Future date is not allowed: onboarded date must be a past or current date");
        }

        checkUserAuthenticity(accountRequestDto.getDeliveryHead().get(0).getUserId(),
                accountRequestDto.getDeliveryHead().get(0).getName());
        accountRequestDto.getAccountPartners()
                .stream().toList()
                .forEach(role -> checkUserAuthenticity(role.getUserId(), role.getName()));
        accountRequestDto.getEngagementPartners()
                .stream().toList()
                .forEach(role -> checkUserAuthenticity(role.getUserId(), role.getName()));
        accountRequestDto.getDeliveryPartners()
                .stream().toList()
                .forEach(role -> checkUserAuthenticity(role.getUserId(), role.getName()));

        Account account = new Account();
        account.setCreatedAt(System.currentTimeMillis());
        account.setUpdatedAt(System.currentTimeMillis());
        BeanUtils.copyProperties(accountRequestDto, account);
        account.setDedRoles(mapToDedRoles(accountRequestDto));
        accountRepository.save(account);
        AccountResponseDto accountResponseDto = mapAccountToResponseDto(account);
        userServiceImpl.saveRole(accountResponseDto);
        return accountResponseDto;


    }

    private void checkUserAuthenticity(UUID userId, String name) {
        String userName = getDisplayName(userId);
        if (null == userName
                || userName.isEmpty()) {
            log.error("AccountService ::User not found");
            throw new UserNotFoundException(":User not found " + userId);
        }
      /* if(!name.equals(userName)){
            log.error("AccountService ::User name does not match");
            throw new UserNotFoundException(":User name does not match for the " + userId);
        }*/
    }

    public String getDisplayName(UUID oid) {
        Optional<AzureUsers> userOptional = azureUserRepository.findById(oid);
        return userOptional.map(AzureUsers::getDisplayName).orElse("");
    }

    private List<DedRoles> mapToDedRoles(AccountRequestDto accountRequestDto) {
        List<DedRoles> dedRoles = new ArrayList<>();
        Set<String> seenUserIds = new HashSet<>();

        AccountRoles deliveryHead = accountRequestDto.getDeliveryHead().get(0);
        if (deliveryHead != null) {
            seenUserIds = userServiceImpl.checkAndAddUserId(seenUserIds, String.valueOf(deliveryHead.getUserId()));
            dedRoles.add(new DedRoles(deliveryHead.getUserId(), null, null, deliveryHead.getName(), mapRoleName(DELIVERY_HEAD)));
        }
        for (AccountRoles role : accountRequestDto.getAccountPartners()) {
            seenUserIds = userServiceImpl.checkAndAddUserId(seenUserIds, String.valueOf(role.getUserId()));
            dedRoles.add(new DedRoles(role.getUserId(), null, null, role.getName(), mapRoleName(ACCOUNT_PARTNER)));
        }
        for (AccountRoles role : accountRequestDto.getEngagementPartners()) {
            seenUserIds = userServiceImpl.checkAndAddUserId(seenUserIds, String.valueOf(role.getUserId()));
            dedRoles.add(new DedRoles(role.getUserId(), null, null, role.getName(), mapRoleName(ENGAGEMENT_PARTNER)));
        }
        for (AccountRoles role : accountRequestDto.getDeliveryPartners()) {
            seenUserIds = userServiceImpl.checkAndAddUserId(seenUserIds, String.valueOf(role.getUserId()));
            dedRoles.add(new DedRoles(role.getUserId(), null, null, role.getName(), mapRoleName(DELIVERY_PARTNER)));
        }

        return dedRoles;
    }


    private void addDedRoles(AccountRoles role, Set<String> existingUserIds, List<DedRoles> dedRoles, String roleName) {
        existingUserIds = userServiceImpl.checkAndAddUserId(existingUserIds, String.valueOf(role.getUserId()));
        dedRoles.add(new DedRoles(role.getUserId(), null, null, role.getName(), mapRoleName(roleName)));
    }


    private String mapRoleName(String roleName) {
        switch (roleName) {
            case DELIVERY_HEAD:
                return DH;
            case ACCOUNT_PARTNER:
                return AP;
            case ENGAGEMENT_PARTNER:
                return EP;
            case DELIVERY_PARTNER:
                return DP;
            default:
                return roleName;
        }
    }

    private List<AccountRoles> mapToAccountRolesOrList(List<DedRoles> dedRoles, String roleName) {
        List<AccountRoles> accountRolesList = new ArrayList<>();
        for (DedRoles role : dedRoles) {
            if (roleName.equals(role.getRole())) {
                accountRolesList.add(new AccountRoles(role.getOid(), role.getName()));
            }
        }
        return accountRolesList;
    }

    private AccountRoles mapToAccountRoles(List<DedRoles> dedRoles, String roleName) {
        for (DedRoles role : dedRoles) {
            if (roleName.equals(role.getRole())) {
                return new AccountRoles(role.getOid(), role.getName());
            }
        }
        return null;
    }


    private AccountResponseDto mapAccountToResponseDto(Account account) {
        AccountResponseDto responseDto = new AccountResponseDto();
        BeanUtils.copyProperties(account, responseDto);
        responseDto.setAccountId(account.getId());
        responseDto.setDeliveryHead(mapToAccountRoles(account.getDedRoles(), DH));
        responseDto.setAccountPartners(mapToAccountRolesOrList(account.getDedRoles(), AP));
        responseDto.setEngagementPartners(mapToAccountRolesOrList(account.getDedRoles(), EP));
        responseDto.setDeliveryPartners(mapToAccountRolesOrList(account.getDedRoles(), DP));
        log.info("AccountServiceImpl::createAccount:: call ended");
        return responseDto;
    }


    @Override
    public AccountResponseDto getAccountById(Long accountId, UUID oId) {

        Optional<Account> optionalAccount = accountRepository.findById(accountId);
        log.info("AccountServiceImpl::getAccountById:: call started");
        if (optionalAccount.isPresent()) {
            log.info("AccountServiceImpl::getAccountById:: call ended");
            AccountResponseDto accountResponseDto = mapAccountToResponseDto(optionalAccount.get());
            if (!userServiceImpl.getHighestRole(oId, null, null).equalsIgnoreCase(SUPER_ADMIN_)) {
                String highestRole = userServiceImpl.getHighestRole(oId, accountId, null);
                if (!highestRole.isBlank()) {
                    accountResponseDto.setPrivileges(utils.getPrivilegesString(highestRole, List.of(ACCOUNTS, PROJECTS)));
                    return accountResponseDto;
                }
                accountResponseDto.setPrivileges(List.of(NO_ACCESS));
                return accountResponseDto;
            }
            accountResponseDto.setPrivileges(List.of(FULL_ACCESS));
            return accountResponseDto;
        } else {
            log.error("AccountServiceImpl::getAccountById:: No id found");
            throw new AccountNotFoundException("Account with ID " + accountId + " not found");
        }
    }

  /* public List<String> getPrivilegesString(String highestRole, List<String> values) {
        List<PrivilegesDto> privilegesDtoList = dummyGetPrivileges(highestRole, values);
        List<String> privileges = new ArrayList<>();
        for (PrivilegesDto privilegesDto : privilegesDtoList) {
            privileges.addAll(privilegesDto.getPrivileges());
        }
        return privileges;
    }

    public List<PrivilegesDto> dummyGetPrivileges(String role, List<String> value) {
        List<PrivilegesDto> privilegeList = new ArrayList<PrivilegesDto>();

        PrivilegesDto privilegesDto = new PrivilegesDto();
        privilegesDto.setName("Accounts");
        privilegesDto.setPrivileges(List.of("Some access Accounts", "Some other access Accounts"));
        privilegeList.add(privilegesDto);

        privilegesDto.setName("Projects");
        privilegesDto.setPrivileges(List.of("Some access Projects ", "Some other access Projects"));
        privilegeList.add(privilegesDto);

        return privilegeList;


    }*/

    @Override
    public AccountResponseDto editAccount(AccountRequestDto accountRequestDto, Long accountId) {

            Optional<Account> optionalAccount = accountRepository.findById(accountId);
            log.info("AccountServiceImpl::editAccount:: call started");
            if (optionalAccount.isPresent()) {
                Account existingAccount = optionalAccount.get();
                String existingAccountName = existingAccount.getAccountName();
                String newAccountName = accountRequestDto.getAccountName();
                LocalDate startDate = Instant.ofEpochMilli(accountRequestDto.getDateOnboarded())
                        .atZone(ZoneId.systemDefault())
                        .toLocalDate();
                if (startDate.isAfter(LocalDate.now())) {
                    log.error("AccountServiceImpl::editAccount::error");
                    throw new ProjectDateException("Future date is not allowed: onboarded date must be a past or current date");
                }

                if (accountRequestDto.getStatus().equals(AccountStatus.Delete)) {
                    List<Project> activeProjects = projectRepository.findByAccountIdAndStatus(accountId, ProjectStatus.Active.name());
                    if (!activeProjects.isEmpty()) {
                        throw new ActiveProjectsFoundException("Cannot delete account, active projects exist");
                    }
                }

                if (existingAccountName.equals(newAccountName)) {
                    existingAccount.setUpdatedAt(System.currentTimeMillis());
                    BeanUtils.copyProperties(accountRequestDto, existingAccount);
                    existingAccount.setDedRoles(mapToDedRoles(accountRequestDto));
                    accountRepository.save(existingAccount);
                    dedRolesRepository.deleteByAccountIdAndProjectIdIsNull(accountId);
                    AccountResponseDto accountResponseDto = mapAccountToResponseDto(existingAccount);
                    userServiceImpl.saveRole(accountResponseDto);
                    return accountResponseDto;
                } else {
                    if (accountRepository.existsByAccountName(newAccountName)) {
                        log.error("AccountServiceImpl::editAccount:: AccountName duplication");
                        throw new DuplicateAccountException("Account name '" + newAccountName + "' already exists");
                    } else {
                        existingAccount.setUpdatedAt(System.currentTimeMillis());
                        BeanUtils.copyProperties(accountRequestDto, existingAccount);
                        existingAccount.setDedRoles(mapToDedRoles(accountRequestDto));
                        accountRepository.save(existingAccount);
                        dedRolesRepository.deleteByAccountIdAndProjectIdIsNull(accountId);
                        AccountResponseDto accountResponseDto = mapAccountToResponseDto(existingAccount);
                        userServiceImpl.saveRole(accountResponseDto);
                        log.info("AccountServiceImpl::editAccount:: call ended");
                        return accountResponseDto;
                    }
                }
            } else {
                log.error("AccountServiceImpl::editAccount:: No id found");
                throw new AccountNotFoundException("Account with ID " + accountId + " not found");
            }

    }

    @Override

    public AccountSummaryCountDto getCountOfAccountByuserId(UUID userId) throws Exception {
        log.info("AccountServiceImpl::getCountOfAccountByuserId:: call started");
        AccountSummaryCountDto accountSummaryCountDto = new AccountSummaryCountDto();
        accountSummaryCountDto.setAccounts(getAllAccountsByUserId(userId).size());
        accountSummaryCountDto.setProjects(projectServiceImpl.getProjectId(userId, 0L,null).getProjectsList().size());
        accountSummaryCountDto.setTeamMembers(0);
        accountSummaryCountDto.setArtifacts(0);
        accountSummaryCountDto.setAssessmentCompleted(0);
        String highestRole = userServiceImpl.getHighestRole(userId, null, null);
        if (!highestRole.equalsIgnoreCase(SUPER_ADMIN_)) {
            List<String> privileges = utils.getPrivilegesString(highestRole, List.of(ACCOUNTS));
            accountSummaryCountDto.setPrivileges(privileges);
            return accountSummaryCountDto;
        }
        accountSummaryCountDto.setPrivileges(List.of(FULL_ACCESS));
        log.info("AccountServiceImpl::getCountOfAccountByuserId:: call ended");
        return accountSummaryCountDto;
    }


    @Override
    public Boolean duplicateAccountName(String accountName) {
        List<Account> existingAccountName = accountRepository.findByAccountNameIgnoreCase(accountName.trim());
        log.info("AccountServiceImpl::duplicateAccountName:: call started");
        boolean isDuplicate = true;
        if (existingAccountName.isEmpty()) {
            log.info("AccountServiceImpl::duplicateAccountName:: call ended");
            isDuplicate = false;
        }
        log.info("AccountServiceImpl::duplicateAccountName:: call ended");
        return isDuplicate;

    }


    @Override
    public List<AccountSummaryDto> getAllAccountsByUserId(UUID userId) {
        log.info("AccountServiceImpl::getAllAccountsByUserId:: call started");
        String highestRole = userService.getHighestRole(userId, null, null);
        if (highestRole != null) {
            if (!highestRole.equalsIgnoreCase(SUPER_ADMIN_)) {
                List<String> privileges = utils.getPrivilegesString(highestRole, List.of(ACCOUNTS));
                if (!privileges.contains(ACCOUNTS_VIEW_ALL)) {
                    if (!privileges.contains(ACCOUNTS_VIEW_ASSOCIATED)) {
                        return Collections.emptyList();
                    } else {
                        List<DedRoles> dedRolesList = dedRolesRepository.findByOid(userId);
                        List<Account> accountList = new ArrayList<>();
                        for (DedRoles role : dedRolesList) {
                            if (role.getProjectId() == null && null != role.getAccountId()) {
                                accountList.add(accountRepository.findById(role.getAccountId()).get());
                            }
                        }
                        log.info("AccountServiceImpl::getAllAccountsByUserId:: call ended");
                        return convertToAccountSummaryDtoList(accountList);
                    }
                } else {
                    List<Account> allAccounts = accountRepository.findAll();
                    return convertToAccountSummaryDtoList(allAccounts);
                }
            } else {
                List<Account> allAccounts = accountRepository.findAll();
                return convertToAccountSummaryDtoList(allAccounts);
            }

        } else {
            return Collections.emptyList();
        }
    }

    private AccountSummaryDto convertToAccountSummaryDto(Account account) {
        AccountSummaryDto dto = new AccountSummaryDto();
        dto.setAccountId(account.getId());
        dto.setAccountName(account.getAccountName());

        String deliveryHead = null;
        String deliveryPartners = null;
        String accountPartners = null;
        String engagementPartners = null;
        for (DedRoles dedRole : account.getDedRoles()) {
            switch (dedRole.getRole()) {
                case "DH":
                    deliveryHead = deliveryHead == null ? dedRole.getName() : dedRole.getName() + "," + deliveryHead;
                    break;
                case "DP":
                    deliveryPartners = deliveryPartners == null ? dedRole.getName() : dedRole.getName() + "," + deliveryPartners;
                    break;
                case "AP":
                    accountPartners = accountPartners == null ? dedRole.getName() : dedRole.getName() + "," + accountPartners;
                    break;
                case "EP":
                    engagementPartners = engagementPartners == null ? dedRole.getName() : dedRole.getName() + "," + engagementPartners;
                    break;
                default:
                    break;
            }
        }

        dto.setDeliveryHead(deliveryHead);
        dto.setDeliveryPartners(deliveryPartners);
        dto.setAccountPartners(accountPartners);
        dto.setEngagementPartners(engagementPartners);
        dto.setDateOnboarded(account.getDateOnboarded());
        dto.setAccountType(account.getAccountType());
        dto.setActiveProjects(0L);
        dto.setTotalProjects(0L);
        dto.setStatus(account.getStatus());

        return dto;
    }

    private List<AccountSummaryDto> convertToAccountSummaryDtoList(List<Account> accounts) {
        return accounts.stream()
                .map(this::convertToAccountSummaryDto)
                .toList();
    }

    @Override
    public AccountMemberDto getAccountMembers(Long accountId) {
        log.info("AccountServiceImpl::getAccountMembers()::start");
        log.info("Fetching AccountMembers for AccountId:" + accountId);
        List<DedRoles> dedRoles = dedRolesRepository.findByAccountIdAndProjectIdIsNull(accountId);
        AccountMemberDto responseDto = new AccountMemberDto();
        responseDto.setAccountPartners(mapToAccountRolesOrList(dedRoles, AP));
        responseDto.setEngagementPartners(mapToAccountRolesOrList(dedRoles, EP));
        responseDto.setDeliveryPartners(mapToAccountRolesOrList(dedRoles, DP));
        log.info("AccountServiceImpl::getAccountMembers()::end");
        return responseDto;
    }

    AccountListDto convertToAccountListDto(Account account) {
        AccountListDto dto = new AccountListDto();
        dto.setId(account.getId());
        dto.setName(account.getAccountName());
        return dto;
    }


    private List<AccountListDto> convertToAccountListDtoList(List<Account> accounts) {
        return accounts.stream()
                .map(this::convertToAccountListDto)
                .toList();
    }

    @Override
    public AccountNamesResponseDto getAccountsList(UUID oid) throws Exception {
        AccountNamesResponseDto accountNamesResponseDto = new AccountNamesResponseDto();
        List<AccountListDto> responseList;
        log.info("AccountServiceImpl::getAllAccountsByUserId:: call started");
        String highestRole = userService.getHighestRole(oid, null, null);
        if (!highestRole.isEmpty()) {
            if (!highestRole.equalsIgnoreCase(SUPER_ADMIN_)) {
                List<String> privileges = utils.getPrivilegesString(highestRole, List.of(ACCOUNTS,PROJECTS));
                if (!privileges.contains(ACCOUNTS_VIEW_ALL)) {
                    if (privileges.contains(ACCOUNTS_VIEW_ASSOCIATED)) {
                        List<Long> accIdList = getAccountId(oid);
                        if (accIdList.isEmpty()) {
                            return new AccountNamesResponseDto(Collections.emptyList(), Collections.emptyList());
                        } else
                            responseList = getAccountDetails(accIdList);
                        log.info("AccountServiceImpl::getAllAccountsByUserId:: call ended");
                        accountNamesResponseDto.setAccountListDtoList(responseList);
                        accountNamesResponseDto.setPrivileges(privileges);
                        return accountNamesResponseDto;
                    } else {
                        return new AccountNamesResponseDto(Collections.emptyList(), Collections.emptyList());
                    }
                } else {
                    List<Account> allAccounts = accountRepository.findAll();
                    return new AccountNamesResponseDto(privileges, convertToAccountListDtoList(allAccounts));
                }
            } else {
                List<Account> allAccounts = accountRepository.findAll();
                return new AccountNamesResponseDto(List.of(FULL_ACCESS), convertToAccountListDtoList(allAccounts));
            }
        } else {
            log.error("AccountServiceImpl::getAllAccountsByUserId:: empty collections false userid");
            return null;
        }
    }


    public List<Long> getAccountId(UUID oid) {
        List<Long> accountIdList = new ArrayList<>();
        List<DedRoles> resultAccount = dedRolesRepository.findByOid(oid);
        if (CollectionUtils.isEmpty(resultAccount)) {
            return Collections.emptyList();
        } else
            for (DedRoles obj : resultAccount) {
                if (null != obj.getAccountId()) {
                    accountIdList.add(obj.getAccountId());
                }

            }
        return accountIdList.stream().distinct().collect(Collectors.toList());
    }

    public List<AccountListDto> getAccountDetails(List<Long> accountIdList) {
        List<AccountListDto> accountList = new ArrayList<>();
        for (Long accId : accountIdList) {
            Optional<Account> resultAccount = accountRepository
                    .findById(accId);

            AccountListDto accountListDto = new AccountListDto();
            accountListDto.setId(accId);
            accountListDto.setName(resultAccount.get().getAccountName());
            accountList.add(accountListDto);

        }
        if (CollectionUtils.isEmpty(accountList)) {
            return Collections.emptyList();
        } else
            return accountList;

    }
    public List<AccountListDto> getAccountNamesListInCreateProject(UUID userId){
        List<Long> accountIdList= getAccountId(userId);
        List<AccountListDto> accountList = new ArrayList<>();
        AccountListDto accountListDto;
        for (Long accId : accountIdList) {
            List<String> privileges=utils.getPrivilegesString(userServiceImpl.getHighestRole(userId, accId,null),List.of(PROJECTS));
            if(privileges.contains(PROJECTS_CREATE)) {
                Optional<Account> resultAccount = accountRepository
                        .findById(accId);

                accountListDto = new AccountListDto();
                accountListDto.setId(accId);
                accountListDto.setName(resultAccount.get().getAccountName());
                accountList.add(accountListDto);
            }
        }

        return accountList;

    }
}
