package com.maveric.delivery.service;

import com.maveric.delivery.exception.DataNotFoundException;
import com.maveric.delivery.mapper.RolesMapper;
import com.maveric.delivery.model.Roles;
import com.maveric.delivery.repository.RolesRepository;
import com.maveric.delivery.requestdto.RolesDto;
import com.maveric.delivery.utils.FailedMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import static com.maveric.delivery.utils.Constants.SUPER_ADMIN_;

@Service
@RequiredArgsConstructor
@Slf4j
public class RolesServiceImpl implements RolesService {

    private final RolesRepository rolesRepository;


    @Override
    public String getRoleName(Long roleId) {
        log.debug("RolesServiceImpl.getRoleName: start -> RoleId:{}", roleId);
        Optional<Roles> role = rolesRepository.findById(roleId);
        log.debug("RolesServiceImpl.getRoleName: end -> RoleId:{}", roleId);
        return role.map(Roles::getName).orElse(null);
    }

    @Override
    public List<RolesDto> getRoles() {
        log.debug("RolesServiceImpl.getRoleName: start");
        List<Roles> roles = rolesRepository.findAll();
        log.debug("RolesServiceImpl.getRoleName: end ");
        return RolesMapper.MAPPER.toDtoList(roles.stream().filter(role -> SUPER_ADMIN_.equalsIgnoreCase(role.getName())).toList());
    }

    @Override
    public RolesDto getRole(Long roleId) {
        log.debug("RolesServiceImpl.getRole: start -> RoleId:{}", roleId);
        Optional<Roles> role = rolesRepository.findById(roleId);
        return RolesMapper.MAPPER.toDto(role.orElseThrow(() -> new DataNotFoundException(FailedMessage.DATA_NOT_FOUND.getMessage().replace("<DATA>", "Roles"), FailedMessage.DATA_NOT_FOUND.getCode())));
    }

    @Override
    public List<RolesDto> findByGroups(List<String> userGroupList) {
        log.debug("RolePrivilegesServiceImpl.findByGroups: start -> userGroup:{} ",userGroupList);
        List<Roles> roles = rolesRepository.findByGroupIn(userGroupList);
        log.debug("RolePrivilegesServiceImpl.findByGroups: end -> userGroup:{} ",userGroupList);
        return RolesMapper.MAPPER.toDtoList(roles.stream().toList());
    }
}
