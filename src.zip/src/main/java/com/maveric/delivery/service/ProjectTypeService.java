package com.maveric.delivery.service;

import com.maveric.delivery.model.ProjectType;
import com.maveric.delivery.responsedto.BaseDto;
import com.maveric.delivery.responsedto.ProjectTypeDto;

import java.util.List;

public interface ProjectTypeService {

    ProjectType saveProjectType(ProjectTypeDto requestPayload);
    List<BaseDto> fetchAllProjectType();
}
