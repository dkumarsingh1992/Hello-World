package com.maveric.delivery.service;

import com.maveric.delivery.model.Account;
import com.maveric.delivery.requestdto.AccountListDto;
import com.maveric.delivery.requestdto.AccountRequestDto;
import com.maveric.delivery.requestdto.AccountSummaryCountDto;
import com.maveric.delivery.requestdto.AccountSummaryDto;
import com.maveric.delivery.responsedto.AccountMemberDto;
import com.maveric.delivery.responsedto.AccountNamesResponseDto;
import com.maveric.delivery.responsedto.AccountResponseDto;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * @author ankushk
 */
public interface AccountService {
    AccountResponseDto createAccount(AccountRequestDto accountRequestDto);

    List<AccountSummaryDto> getAllAccountsByUserId(UUID userId) throws Exception;

    AccountResponseDto getAccountById(Long accountId,UUID oid);


    AccountResponseDto editAccount(AccountRequestDto accountRequestDto,Long accountId);

    AccountSummaryCountDto getCountOfAccountByuserId(UUID userId) throws Exception;
    Boolean duplicateAccountName(String accountName);

    AccountMemberDto getAccountMembers(Long accountId);
    AccountNamesResponseDto getAccountsList(UUID oid)throws Exception;

}
