package com.maveric.delivery.service;

import com.maveric.delivery.exception.DataNotFoundException;
import com.maveric.delivery.mapper.PrivilegesMapper;
import com.maveric.delivery.mapper.RolePrivilegesMapper;
import com.maveric.delivery.model.IdentifiedEntity;
import com.maveric.delivery.model.Privileges;
import com.maveric.delivery.model.RolePrivileges;
import com.maveric.delivery.model.Roles;
import com.maveric.delivery.repository.RolePrivilegesRepository;
import com.maveric.delivery.repository.RolesRepository;
import com.maveric.delivery.requestdto.PrivilegesDto;
import com.maveric.delivery.requestdto.RolePrivilegesDto;
import com.maveric.delivery.utils.FailedMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class RolePrivilegesServiceImpl implements RolePrivilegesService {

    private final RolePrivilegesRepository rolePrivilegesRepository;

    private final RolesRepository rolesRepository;

    @Override
    @CacheEvict(value = {"findByRoleId", "findByGroupContaining"},allEntries = true)
    public List<RolePrivilegesDto> save( List<RolePrivilegesDto> rolePrivilegesDtoList) {
        log.debug("RolePrivilegesServiceImpl.save: started");
        List<RolePrivileges> rolePrivileges = new ArrayList<>();
        rolePrivilegesDtoList.forEach(rolePrivilegesDto -> {
            RolePrivileges privileges = RolePrivilegesMapper.MAPPER.toEntity(rolePrivilegesDto);
            Long id = rolePrivilegesRepository.findByRoleId(rolePrivilegesDto.getRoleId()).map(IdentifiedEntity::getId).orElse(null);
            privileges.setId(id);
            privileges = rolePrivilegesRepository.save(privileges);
            rolePrivileges.add(privileges);
        });
        log.debug("RolePrivilegesServiceImpl.save: end");
        return toDtoList(rolePrivileges);
    }

    @Override
    public List<RolePrivilegesDto> findAll() {
        log.debug("RolePrivilegesServiceImpl.get: start");
        List<RolePrivileges> rolePrivileges = rolePrivilegesRepository.findAll();
        log.debug("RolePrivilegesServiceImpl.get: end");
        return toDtoList(rolePrivileges);
    }

    @Override
    public RolePrivilegesDto findByRoleId(Long roleId) {
        log.debug("RolePrivilegesServiceImpl.findByRoleId: start -> RoleId:{}", roleId);
        Optional<RolePrivileges> rolePrivileges = rolePrivilegesRepository.findByRoleId(roleId);
        log.debug("RolePrivilegesServiceImpl.findByRoleId: end -> RoleId:{}", roleId);
        return toDto(rolePrivileges.orElse(null));

    }

    @Override
    public List<PrivilegesDto> findByGroup(List<String> module, String userGroup) {
        log.debug("RolePrivilegesServiceImpl.findByGroup: start -> type:{} ,userGroup:{} ", module,userGroup);
        Roles roles = rolesRepository.findByGroupContaining(userGroup);
        Optional<RolePrivileges> rolePrivileges = rolePrivilegesRepository.findByRoleId(roles.getId());
        Optional<List<Privileges>> privileges = rolePrivileges.map(RolePrivileges::getPrivileges);
        log.debug("RolePrivilegesServiceImpl.findByGroup: end -> type:{} ,userGroup:{} ", module,userGroup);
        List<PrivilegesDto> privilegesDtos= PrivilegesMapper.MAPPER.toDtoList(privileges.orElse(Collections.emptyList()).stream().filter(privileges1 -> module.contains(privileges1.getName())).toList());
        privilegesDtos.stream().filter(Objects::nonNull).forEach(privilegesDto -> {

        List<String> list= privilegesDto.getPrivileges().stream().filter(Objects::nonNull).map(s ->
                  ((privilegesDto.getName() + "_" + s).replace(" ", "_")).toUpperCase()
            ).toList();
                    privilegesDto.setPrivileges(list);
                }

        );
        return privilegesDtos;
    }

    @Override
    public RolePrivilegesDto findByName(String name) {
        log.debug("RolePrivilegesServiceImpl.findByName: start -> Role:{} ",name);
        Roles roles = rolesRepository.findByName(name);
        if (Objects.isNull(roles) || Objects.isNull(roles.getId()))
            throw new DataNotFoundException(FailedMessage.DATA_NOT_FOUND.getMessage().replace("<DATA>", "Roles"), FailedMessage.DATA_NOT_FOUND.getCode());
        Optional<RolePrivileges> rolePrivileges = rolePrivilegesRepository.findByRoleId(roles.getId());
        log.debug("RolePrivilegesServiceImpl.findByName: end -> Role:{} ",name);
        return toDto(rolePrivileges.orElse(null));
    }

    @Override
    public List<PrivilegesDto> findByName(List<String> module, String name) {
        log.debug("RolePrivilegesServiceImpl.findByName: start -> type:{} ,Role:{} ", module,name);
        Roles roles = rolesRepository.findByName(name);
        Optional<RolePrivileges> rolePrivileges = rolePrivilegesRepository.findByRoleId(roles.getId());
        Optional<List<Privileges>> privileges = rolePrivileges.map(RolePrivileges::getPrivileges);
        List<PrivilegesDto> privilegesDtos=new ArrayList<>();
        if(module.stream().anyMatch(s->s.equalsIgnoreCase("ALL"))) {
            privilegesDtos =PrivilegesMapper.MAPPER.toDtoList(privileges.get());
        }
        else {
            privilegesDtos = PrivilegesMapper.MAPPER.toDtoList(privileges.orElse(Collections.emptyList()).stream().filter(privileges1 -> module.contains(privileges1.getName())).toList());
        }
        privilegesDtos.stream().filter(Objects::nonNull).forEach(privilegesDto -> {

                    List<String> list= privilegesDto.getPrivileges().stream().filter(Objects::nonNull).map(s ->
                            ((privilegesDto.getName() + "_" + s).replace(" ", "_")).toUpperCase()
                    ).toList();
                    privilegesDto.setPrivileges(list);
                }

        );
        log.debug("RolePrivilegesServiceImpl.findByGroup: end -> type:{} , Role:{} ", module,name);
        return privilegesDtos;
    }


    private List<RolePrivilegesDto> toDtoList(List<RolePrivileges> rolePrivileges) {

        List<RolePrivilegesDto> rolePrivilegesDtos = RolePrivilegesMapper.MAPPER.toDtoList(rolePrivileges);
        rolePrivilegesDtos.stream().filter(Objects::nonNull).forEach(rolePrivilegesDto -> {
            Optional<Roles> roles = rolesRepository.findById(rolePrivilegesDto.getRoleId());
            if (roles.isPresent()) {
                rolePrivilegesDto.setRoleName(roles.get().getName());
                rolePrivilegesDto.setHierarchy(roles.get().getHierarchy());
            }
        });
        return rolePrivilegesDtos;
    }

    private RolePrivilegesDto toDto(RolePrivileges rolePrivileges) {
        RolePrivilegesDto rolePrivilegesDto = RolePrivilegesMapper.MAPPER.toDto(rolePrivileges);
        if (Objects.nonNull(rolePrivilegesDto) && Objects.nonNull(rolePrivilegesDto.getRoleId())) {
            Optional<Roles> roles = rolesRepository.findById(rolePrivilegesDto.getRoleId());
            if (roles.isPresent()) {
                rolePrivilegesDto.setRoleName(roles.get().getName());
                rolePrivilegesDto.setHierarchy(roles.get().getHierarchy());
            }
        }
        return rolePrivilegesDto;
    }
}
