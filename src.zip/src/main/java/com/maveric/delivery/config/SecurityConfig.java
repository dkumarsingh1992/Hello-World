package com.maveric.delivery.config;

import com.maveric.delivery.filter.securityFilter;
import com.maveric.delivery.service.UserService;
import com.maveric.delivery.utils.JwtTokenDecoder;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity(securedEnabled = true)
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtTokenDecoder jwtTokenDecoder;
    private final UserService userService;

    @Value("${security.patterns.allowed}")
    private String[] allowedPatterns;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http.csrf(AbstractHttpConfigurer::disable)
                .sessionManagement(sessionManagement -> sessionManagement.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(requests -> requests.requestMatchers(allowedPatterns).permitAll()
                        .anyRequest().authenticated())
                .addFilterBefore(new securityFilter(jwtTokenDecoder, userService), UsernamePasswordAuthenticationFilter.class)
        ;
        return http.build();
    }
}
