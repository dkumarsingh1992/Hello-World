package com.maveric.delivery.config;

import com.azure.identity.ClientSecretCredential;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.microsoft.graph.serviceclient.GraphServiceClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GraphServiceClientConfig {

    @Value("${maveric.de-dashboard.clientId}")
    private String clientId;
    @Value("${maveric.de-dashboard.tenantId}")
    private String tenantId;
    @Value("${maveric.de-dashboard.secretValue}")
    private String clientSecret ;
    @Value("${scope.graph}")
    private String graphScope;
    @Bean
    public GraphServiceClient graphServiceClient(){

        final ClientSecretCredential credential = new ClientSecretCredentialBuilder()
                .clientId(clientId).tenantId(tenantId).clientSecret(clientSecret).build();

       return new GraphServiceClient(credential, graphScope);
    }
}
