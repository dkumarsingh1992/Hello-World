package com.maveric.delivery.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(value = "projectRole")
@NoArgsConstructor
@AllArgsConstructor
public class ProjectRole extends IdentifiedEntity{
    private String name;

    public ProjectRole(long l, String projectRole1) {
        super();
    }
}
