package com.maveric.delivery.model.embedded;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;


/**
 * @author ankushk
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClientInformation {

    @Size(min = 3, max = 25, message = "Client name must be between 3 and 25 characters")
    private String clientName;
    @Size(min = 3, max = 500, message = "Client description must be between 3 and 500 characters")
    private String clientDescription;
    @Size(min = 2, max = 50, message = "Address 1 must be between 2 and 50 characters")
    @Pattern(regexp = "^[a-zA-Z0-9,.&()#\\- ]+$", message = "Address 1 field can only contain alphabets, numbers, comma,hashtag, dot, &, ()")
    private String businessAddressLineOne;
    @Size(min = 2, max = 50, message = "Address 2 must be between 2 and 50 characters")
    @Pattern(regexp = "^[a-zA-Z0-9,.&()#\\- ]+$", message = "Address 2 field can only contain alphabets, numbers, comma,hashtag, dot, &, ()")
    private String businessAddressLineTwo;
    @Size(min = 2, max = 50, message = "City must be between 2 and 50 characters")
    private String businessCity;
    @Size(min = 2, max = 50, message = "City must be between 2 and 50 characters")
    private String businessState;
    private String businessCountry;
    @Valid
    @Size(max = 5,message = "The number of client contacts cannot exceed 5")
    private List<ClientContacts> contactsList;
    public ClientInformation(String sampleCompany, String s, String s1) {
    }

    public void setContactsList(List<ClientContacts> contactsList){
        List<ClientContacts> clientContacts = new ArrayList<>();
        if(null == contactsList ||contactsList.isEmpty()){
            this.contactsList = contactsList;
        }else {
            for(ClientContacts contacts : contactsList){
                if(contacts.getContactName() == null && contacts.getContactNumber() == null
                        && contacts.getDesignation() == null && contacts.getEmailId() == null){
                    clientContacts.add(contacts);
                } else if (contacts.getContactName() == null || contacts.getContactNumber() == null
                        || contacts.getDesignation() == null || contacts.getEmailId() == null) {
                    throw new IllegalArgumentException("Invalid contact list");
                }
            }
            contactsList.removeAll(clientContacts);
            this.contactsList = contactsList;
        }
    }

}
