package com.maveric.delivery.model.embedded;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Question {

    private int number;
    private String questionText;
    private String subHeading;
    private boolean attachmentRequired;
    private String attachmentPath;
    private String fileName;
    private String documentId;
    private boolean comments;
    @Pattern(regexp = "^[a-zA-Z0-9,.&()\\- ]+$", message = "User comment can only contain alphabets, numbers, comma, dot, &, (), and hyphen")
    private String commentText;
    private QuestionType type;
    private CheckBoxOptions checkBoxOptions;
    private RadioOptions radioOptions;
    @Valid
    private Numerical numerical;
    @Valid
    private Slider slider;
    @Pattern(regexp = "^[a-zA-Z0-9,.&()\\- ]+$", message = "Reviewer comment can only contain alphabets, numbers, comma, dot, &, (), and hyphen")
    private String reviewerComment;
}
