package com.maveric.delivery.model.embedded;

public enum AssessmentCategoryType {
    PROJECT_MATURITY,EXECUTION_MATURITY,DELIVERY_MATURITY;
}
