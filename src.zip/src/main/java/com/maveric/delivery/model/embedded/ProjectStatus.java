package com.maveric.delivery.model.embedded;

public enum ProjectStatus {
    Inactive, Active, Delete
}
