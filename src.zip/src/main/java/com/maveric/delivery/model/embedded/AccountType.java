package com.maveric.delivery.model.embedded;

/**
 * @author ankushk
 */
public enum AccountType {
    Client , Internal
}
