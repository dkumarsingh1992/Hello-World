package com.maveric.delivery.model;

import com.maveric.delivery.model.embedded.AssessmentStatus;
import com.maveric.delivery.model.embedded.TemplateCategory;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document(collection = "assessment")
public class Assessment extends IdentifiedEntity {

    private Long accountId;
    private UUID userId;
    private String accountName;
    private Long projectId;
    private String projectName;
    private AssessmentStatus status;
    private Long initiatedOn;
    private Long dueOn;
    private Long submittedOn;
    private String reviewerName;
    private UUID reviewerId;
    private Double score;
    private List<TemplateCategory> templateCategory;
    @Pattern(regexp = "^[a-zA-Z0-9,.&()\\- ]*$", message = "Overall comment can only contain alphabets, numbers, comma, dot, &, (), and hyphen")
    private String overallComment;
}
