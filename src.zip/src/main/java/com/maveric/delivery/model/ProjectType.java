package com.maveric.delivery.model;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(value = "projectType")
@NoArgsConstructor
@AllArgsConstructor
public class ProjectType extends IdentifiedEntity{
    @NotNull(message = "ProjectTypeName should not be Empty")
    private String name;

    @NotNull(message = "ProjectType description should not be Empty")
    private String description;

}
