package com.maveric.delivery.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(value = "frequency")
@NoArgsConstructor
@AllArgsConstructor
public class Frequency extends IdentifiedEntity{
    private String name;

    public Frequency(long id, String name) {
        super();
    }
}
