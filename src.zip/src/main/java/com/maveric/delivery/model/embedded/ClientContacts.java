package com.maveric.delivery.model.embedded;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author ankushk
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClientContacts {

    @Size(min = 2, max = 50, message = "Contact name must be between 2 and 50 characters")
    @Pattern(regexp = "^[a-zA-Z0-9,.\\s]*$", message = "Contact name can only contain alphabets, numbers, white space, dot, and comma")
    private String contactName;

    @Size(min = 2, max = 50, message = "Designation must be between 2 and 50 characters")
    @Pattern(regexp = "^[a-zA-Z0-9,.\\s]*$", message = "Designation can only contain alphabets, numbers, white space, dot, and comma")
    private String designation;

    @Email(message = "Invalid email format")
    private String emailId;

    @Pattern(regexp = "^\\+?\\d+(-\\d+)?$", message = "Please enter the contact number in a valid format")
    private String contactNumber;


}
