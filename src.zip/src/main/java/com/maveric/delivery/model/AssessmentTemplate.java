package com.maveric.delivery.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(value = "assessmentTemplate")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AssessmentTemplate extends IdentifiedEntity{
    private String name;

    public AssessmentTemplate(long id, String name) {
        super();
    }
}
