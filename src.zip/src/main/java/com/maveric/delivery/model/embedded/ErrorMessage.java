package com.maveric.delivery.model.embedded;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ErrorMessage {

        private String field;
        private String message;

        public ErrorMessage(String message) {
                this.message = message;
        }
}