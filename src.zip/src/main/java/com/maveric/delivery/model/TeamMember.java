package com.maveric.delivery.model;

import com.maveric.delivery.model.embedded.TeamMemberStatus;
import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;


@Data
@Document(collection = "teamMember")
public class TeamMember extends IdentifiedEntity{

    private Long projectId;
    private String name;
    private String projectRole;
    private String location;
    private List<String> skillSet;
    private Boolean isBillable;
    private Long startDate;
    private Long endDate;
    private Long allocation;
    private TeamMemberStatus status;
    private String createdBy;
    private Long createdAt;
    private String updatedBy;
    private Long updatedAt;


}
