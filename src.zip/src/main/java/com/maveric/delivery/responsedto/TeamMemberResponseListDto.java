package com.maveric.delivery.responsedto;

import com.maveric.delivery.model.IdentifiedEntity;
import com.maveric.delivery.model.embedded.TeamMemberStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TeamMemberResponseListDto extends IdentifiedEntity {
    private String name;
    private String projectRole;
    private String location;
    private List<String> skillSet;
    private Boolean isBillable;
    private Long startDate;
    private Long endDate;
    private Long allocation;
    private TeamMemberStatus status;
    private String accountName;
    private String projectName;
}
