package com.maveric.delivery.responsedto;

import com.maveric.delivery.requestdto.AccountListDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountNamesResponseDto {
    List<String> privileges;
    List<AccountListDto> accountListDtoList;
}
