package com.maveric.delivery.responsedto;

import com.maveric.delivery.requestdto.AccountRoles;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountMemberDto {
    private List<AccountRoles> accountPartners;
    private List<AccountRoles> engagementPartners;
    private List<AccountRoles> deliveryPartners;
}
