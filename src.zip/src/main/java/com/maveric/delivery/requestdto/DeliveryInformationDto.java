package com.maveric.delivery.requestdto;

import com.maveric.delivery.model.embedded.BaseInfo;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DeliveryInformationDto {
    @NotBlank(message = "Project Type is required")
    private String projectType;
    @NotNull(message = "Assessment Templates Type is required")
    @Valid
    private List<BaseInfo> assessmentTemplates;
    @NotNull(message = "Frequency Type is required")
    private String frequency;
    @Size(min = 3, max = 500, message = "Delivery notes must be between 3 and 500 characters")
    @Pattern(regexp = "^[a-zA-Z0-9,.&()\\- ]+$", message = "Delivery notes can only contain alphabets, numbers, comma, dot, &, (), and hyphen")
    private String deliveryNotes;
    @NotNull(message = "Delivery Manager is required")
    @Valid
    private  AccountRoles deliveryManager;
    @NotNull(message = "Account Partner list is required")
    @Valid
    private AccountRoles accountPartner;
    @NotNull(message = "Engagement Partner list is required")
    @Valid
    private AccountRoles engagementPartner;
    @NotNull(message = "Delivery Partner list is required")
    @Valid
    private AccountRoles deliveryPartner;
}
