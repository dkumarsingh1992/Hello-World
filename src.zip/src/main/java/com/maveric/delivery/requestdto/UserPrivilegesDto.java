package com.maveric.delivery.requestdto;


import lombok.Data;

import java.util.List;

@Data
public class UserPrivilegesDto {

    private List<String> roles;
    private boolean isSuperAdmin = false;
    private String highestRole;
    private List<RolePrivilegesDto> privileges;
}
