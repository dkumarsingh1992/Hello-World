package com.maveric.delivery.requestdto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import net.minidev.json.annotate.JsonIgnore;

import java.util.List;

@Data
public class RolePrivilegesDto {

    @NotNull(message = "Role is required")
    private Long roleId;
    private String roleName;
    @JsonIgnore
    private int hierarchy;
    private List<PrivilegesDto> privileges;

}
