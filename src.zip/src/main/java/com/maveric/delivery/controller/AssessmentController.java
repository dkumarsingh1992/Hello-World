package com.maveric.delivery.controller;

import com.maveric.delivery.model.Account;
import com.maveric.delivery.model.Assessment;
import com.maveric.delivery.model.embedded.AssessmentRole;
import com.maveric.delivery.model.embedded.TemplateCategory;
import com.maveric.delivery.repository.AssessmentRepository;
import com.maveric.delivery.requestdto.AccountRequestDto;
import com.maveric.delivery.requestdto.AssessmentSectionWiseRequestDto;
import com.maveric.delivery.requestdto.MyAssessmentDto;
import com.maveric.delivery.responsedto.AssessmentResponseDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.AssessmentService;
import com.maveric.delivery.utils.SuccessMessage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.SUCCESS;

@RestController
@RequestMapping("/v1")
@Slf4j
@RequiredArgsConstructor
public class AssessmentController {

    private final AssessmentService assessmentService;

    @Operation(summary = "Save Assessment")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Assessment saved successfully",
                    content = @Content(schema = @Schema(implementation = Account.class))),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(path = "/assessments/{assessmentId}")
    public ResponseEntity<ResponseDto> saveAssessment(@RequestBody AssessmentSectionWiseRequestDto
                                                                  assessmentSectionWiseRequestDto,
                                                      @PathVariable Long assessmentId, @RequestParam Long projectId){
        TemplateCategory templateCategory = assessmentService.saveAssessment(assessmentSectionWiseRequestDto,
                assessmentId,projectId);
        return ResponseEntity.status(HttpStatus.CREATED).body(new ResponseDto(SUCCESS,
                SuccessMessage.USER_RESPONSE_SAVED.getCode(), SuccessMessage.USER_RESPONSE_SAVED.getMessage(),
                null,templateCategory ));
    }

    @Operation(summary = "Fetch Assessment")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", content = @Content(schema = @Schema(implementation =
                    AssessmentResponseDto.class))),
            @ApiResponse(responseCode = "404", description = "Not found")})
    @GetMapping(path = "/assessments/{assessmentId}")
    public ResponseEntity<ResponseDto> fetchAssessment(@PathVariable Long assessmentId,@RequestParam Long projectId){
        AssessmentResponseDto assessmentResponseDto = assessmentService.fetchAssessment(assessmentId,projectId);
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto(SUCCESS,
                SuccessMessage.FETCH_ASSESSMENT.getCode(), SuccessMessage.FETCH_ASSESSMENT.getMessage(),
                null,assessmentResponseDto ));
    }

    @Operation(summary = "Fetch Assessment List")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", content = @Content(schema = @Schema(implementation =
                    AssessmentResponseDto.class))),
            @ApiResponse(responseCode = "404", description = "Not found")})
    @GetMapping(path = "/assessments")
    public ResponseEntity<ResponseDto> fetchMyAssessment(HttpServletRequest servletRequest, @RequestParam AssessmentRole assessmentRole){
        UUID userId = UUID.fromString((String) servletRequest.getAttribute("oid"));
        List<AssessmentResponseDto> assessmentResponseDto;
        if(AssessmentRole.ASSIGNED.equals(assessmentRole)){
            MyAssessmentDto myAssessmentDto = assessmentService.fetchMyAssessment(userId);
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto(SUCCESS,
                    SuccessMessage.FETCH_ASSESSMENT_LIST.getCode(), SuccessMessage.FETCH_ASSESSMENT_LIST.getMessage(),
                    null,myAssessmentDto ));
        } else if (AssessmentRole.REVIEWER.equals(assessmentRole)) {
            assessmentResponseDto = assessmentService.fetchReviewerAssessment(userId);
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto(SUCCESS,
                    SuccessMessage.FETCH_ASSESSMENT_LIST.getCode(), SuccessMessage.FETCH_ASSESSMENT_LIST.getMessage(),
                    null,assessmentResponseDto ));
        }else {
            assessmentResponseDto = assessmentService.fetchAllAssessment(userId);
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto(SUCCESS,
                    SuccessMessage.FETCH_ASSESSMENT_LIST.getCode(), SuccessMessage.FETCH_ASSESSMENT_LIST.getMessage(),
                    null,assessmentResponseDto ));
        }
    }

}
