package com.maveric.delivery.controller;

import com.maveric.delivery.requestdto.DedRolesDto;
import com.maveric.delivery.requestdto.RolesDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.RolesService;
import com.maveric.delivery.utils.SuccessMessage;
import com.maveric.delivery.utils.ValidateApiAccess;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.*;

@RestController
@RequestMapping("/v1")
@Slf4j
@RequiredArgsConstructor
public class RolesController {

    private final RolesService rolesService;

    private final ValidateApiAccess validateApiAccess;

    @Operation(summary = "This API is intended to retrieve roles.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Retrieve successfully",
                    content = @Content(schema = @Schema(implementation = ResponseDto.class))),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/roles")
    public ResponseEntity<?> get(HttpServletRequest servletRequest) {
        log.debug("RolesController::get: start");
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, USER_ROLES, VIEW_ALL);
        List<RolesDto> response = rolesService.getRoles();
        log.debug("RolesController::get: end");
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto(SUCCESS, SuccessMessage.ROLES_FETCHED.getCode(), SuccessMessage.ROLES_FETCHED.getMessage(), null, response));
    }

    @Operation(summary = "This API is intended to retrieve the roles associated with id.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Retrieve successfully",
                    content = @Content(schema = @Schema(implementation = ResponseDto.class))),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/roles/{roleId}")
    public ResponseEntity<?> findByRoleId(HttpServletRequest servletRequest, @Valid @NonNull @PathVariable Long roleId) {
        log.debug("RolesController::findByRoleId: start -> roleId:{}", roleId);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, USER_ROLES, VIEW_ALL);
        RolesDto response = rolesService.getRole(roleId);
        log.debug("RolesController::findByRoleId: end -> roleId:{}", roleId);
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto(SUCCESS, SuccessMessage.ROLES_FETCHED.getCode(), SuccessMessage.ROLES_FETCHED.getMessage(), null, response));
    }
}