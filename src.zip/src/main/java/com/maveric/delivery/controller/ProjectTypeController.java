package com.maveric.delivery.controller;

import com.maveric.delivery.model.ProjectType;
import com.maveric.delivery.responsedto.BaseDto;
import com.maveric.delivery.responsedto.ProjectTypeDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.ProjectTypeService;
import com.maveric.delivery.utils.FailedMessage;
import com.maveric.delivery.utils.SuccessMessage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.maveric.delivery.utils.Constants.FAILED;
import static com.maveric.delivery.utils.Constants.SUCCESS;

@RestController
@Slf4j
@RequestMapping("/v1")
@RequiredArgsConstructor
public class ProjectTypeController {

    private final ProjectTypeService projectTypeService;

    @Operation(summary = "Save ProjectType")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful operation",
                    content = @Content(schema = @Schema(implementation = ProjectType.class))),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(path = "/projectTypes")
    public ResponseEntity<ResponseDto> saveProjectType(@Valid @RequestBody ProjectTypeDto requestPayload) {
        log.debug("ProjectTypeController::saveProjectType()::started", requestPayload);
        ProjectType projectType = projectTypeService.saveProjectType(requestPayload);
        log.debug("ProjectTypeController::saveProjectType()::ended");
        return ResponseEntity.ok(new ResponseDto("Success", SuccessMessage.PROJECT_TYPE_CREATED.getCode(), SuccessMessage.PROJECT_TYPE_CREATED.getMessage(),null, projectType));
    }

    @Operation(summary = "Fetch All ProjectType")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful operation",
                    content = @Content(schema = @Schema(implementation = ProjectType.class))),
            @ApiResponse(responseCode = "404", description = "ProjectTypes not Present in DB"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/projectTypes")
    public ResponseEntity<ResponseDto> fetchAllProjectType() {
        log.debug("ProjectTypeController::FetchAllProjectType() started");
        List<BaseDto> projectTypeList = projectTypeService.fetchAllProjectType();
        if (CollectionUtils.isEmpty(projectTypeList)) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new ResponseDto(FAILED, FailedMessage.FETCH_PROJECTTYPE_FAILED.getCode(), FailedMessage.FETCH_PROJECTTYPE_FAILED.getMessage(),null, projectTypeList));
        }
        log.debug("ProjectTypeController::FetchAllProjectType() ended");
        return ResponseEntity.ok(new ResponseDto(SUCCESS, FailedMessage.FETCH_PROJECTTYPE_FAILED.getCode(), SuccessMessage.FETCH_PROJECT_TYPE.getMessage(),null, projectTypeList));
    }
}
