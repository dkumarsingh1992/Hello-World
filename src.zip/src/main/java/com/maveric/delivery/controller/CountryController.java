package com.maveric.delivery.controller;

import com.maveric.delivery.model.Country;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.CountryService;
import com.maveric.delivery.utils.FailedMessage;
import com.maveric.delivery.utils.SuccessMessage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.Objects;

@RestController
@RequestMapping("/v1")
@Slf4j
@RequiredArgsConstructor
public class CountryController {

    private final CountryService countryService;

    @Operation(summary = "Get All Countries")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful operation",
                    content = @Content(schema = @Schema(implementation = Country.class))),
            @ApiResponse(responseCode = "404", description = "Countries not present in DB"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @GetMapping(path = "/countries")
    public ResponseEntity<ResponseDto> getAllCountries() {
        log.debug("CountryController::getAllCountries() started");
        List<Country> countryList = countryService.getAllCountries();
        if (Objects.isNull(countryList) || countryList.isEmpty()) {
            log.debug("CountryController::getAllCountries() - Countries not present in DB");
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new ResponseDto("Success", FailedMessage.FETCH_COUNTRIES_FAILED.getCode(), FailedMessage.FETCH_COUNTRIES_FAILED.getMessage(),null, countryList));
        }
        log.debug("CountryController::getAllCountries() ended");
        return ResponseEntity.ok(new ResponseDto("Success", SuccessMessage.FETCH_COUNTRIES.getCode(), SuccessMessage.FETCH_COUNTRIES.getMessage(),null, countryList));
    }


    @GetMapping("/test/{id}")
    public ResponseEntity<Map<String, Object>> getUser(@PathVariable int id) {
        Map<String, Object> user = Map.of("id", id, "name", "Hari");
        return ResponseEntity.ok(user);
    }

}
