package com.maveric.delivery.exception;

public class BaseTypeNotFoundException extends RuntimeException {
    public BaseTypeNotFoundException(String message) {
        super(message);
    }
}