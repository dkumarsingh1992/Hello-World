package com.maveric.delivery.exception;

import lombok.Getter;

@Getter
public class PermissionDeniedException extends RuntimeException {

    private final String code;

    public PermissionDeniedException(String message, String code) {
        super(message);
        this.code = code;
    }

}
