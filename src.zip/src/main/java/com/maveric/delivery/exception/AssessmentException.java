package com.maveric.delivery.exception;

public class AssessmentException extends RuntimeException{

    public AssessmentException(String message){
        super(message);
    }
}
