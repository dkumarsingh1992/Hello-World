package com.maveric.delivery.exception;

public class DuplicateUserIdException extends RuntimeException{
    public DuplicateUserIdException(String message) {
        super(message);
    }
}
