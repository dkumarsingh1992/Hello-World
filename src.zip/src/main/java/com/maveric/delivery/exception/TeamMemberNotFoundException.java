package com.maveric.delivery.exception;

public class TeamMemberNotFoundException extends RuntimeException{
    public TeamMemberNotFoundException (String message){super(message);}
}
