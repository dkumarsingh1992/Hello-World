package com.maveric.delivery.utils;

public enum FailedMessage {
    ACCOUNT_CREATION_FAILED("E-1000", "Account creation Failed"),
    FETCH_ACCOUNTS_FAILED("E-1001", "Failed to fetch accounts"),
    FETCH_ACCOUNTS_COUNT_FAILED("E-1002", "Failed to fetch accounts count"),
    FETCH_ACCOUNT_FAILED("E-1003", "Failed to fetch account"),
    UPDATE_ACCOUNT_DETAILS_FAILED("E-1004", "Failed to update account details"),
    EXISTS_ACCOUNT("E-1005", "Account name already exists : "),
    FETCH_COUNTRIES_FAILED("E-1006", "Failed to fetch countries"),
    PROJECTTYPE_CREATED_FAILED ("E-1007","ProjectType creation failed"),
    FETCH_PROJECTTYPE_FAILED("E-1008", "Failed to fetch projectType"),
    EXISTS_PROJECTS("E-1009", "Project name already exists : "),
    DATE_PROJECTS("E-1010", "Date validation failed"),

    FETCH_BASED_TYPES_FAILED("E-1101","Failed to fetch basedTypes"),
    PROJECT_NOT_FOUND("E-1011","Project not found "),
    PROJECT_STATUS("E-1012","Status should not be null "),
    FETCHED_PROJECT_STATUS_FAILED("E-1103","Failed to fetch Project Status"),
    FETCHED_ASSESSMENT_TEMPLATES_FAILED("E-1104","Failed to fetch assessment templates"),
    LOCATION_CREATION_FAILED("E-1014","Failed to save Location"),
    PROJECTROLE_CREATION_FAILED("E-1015","Failed to save projectRole"),
    ARTIFACTTYPE_CREATION_FAILED("E-1016","Failed to save artifactType"),

    INTERNAL_SERVER_ERROR("E-2000","Internal Server Error "),
    RESOURCE_NOT_FOUND("E-2001","Resource not found "),
    ID_NOT_FOUND("E-2002"," Id Not Found Exception "),
    METHOD_ARGUMENT_NOT_VALID(" E-2003","Method Argument Not Valid Exception "),
    HTTP_MESSAGE_MESSAGE_NOT_READABLE("E-2004","Http Message Not Readable Exception "),
    ILLEGAL_ARGUMENT_EXCEPTION("E-2005","Illegal Argument Exception "),
    VALIDATION_ERROR("E-2006", "Validation error(s) "),
    USER_ROLE_EXCEPTION("E-2007","User role exception "),
    BAD_REQUEST("E-2008", "Bad Request "),
    ACCOUNT_NOT_FOUND("E-2009","Account not found "),
    TYPE_NOT_FOUND("E-2101"," Type not found"),

    USER_NOT_FOUND("E-2102"," User not found"),

    ACTIVE_PROJECT_FOUND("E-2103","Cannot delete Account, active projects exist"),

    MEMBER_NOT_FOUND("E-2104","Team Member not found"),

    CUSTOM_EXCEPTION("E-2104","Custom exception"),

    DATA_NOT_FOUND("E-2010","<DATA> not found "),

    PERMISSION_DENIED("E-3000","Permission Denied: You don't have access to this resource"),

    INVALID_TOKEN("E-3001","The provided token is invalid"),

    EXPIRED_TOKEN("E-3002","The token has expired. Please log in again."),

    DUPLICATE_KEY_EXCEPTION("E-3003","Duplicate Data"),

    ;


    private final String code;
    private final String message;

    FailedMessage(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public static FailedMessage fromCode(String code) {
        for (FailedMessage errorMessage : FailedMessage.values()) {
            if (errorMessage.code == code) {
                return errorMessage;
            }
        }
        throw new IllegalArgumentException("Invalid error code");
    }

    @Override
    public String toString() {
        return "ErrorMessage{" +
                "code=" + code +
                ", message='" + message + '\'' +
                '}';
    }
}

