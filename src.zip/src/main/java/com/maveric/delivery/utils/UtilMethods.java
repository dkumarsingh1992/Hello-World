package com.maveric.delivery.utils;

import com.maveric.delivery.exception.DuplicateUserIdException;
import com.maveric.delivery.exception.UserNotFoundException;
import com.maveric.delivery.model.AzureUsers;
import com.maveric.delivery.model.embedded.DedRoles;
import com.maveric.delivery.repository.AzureUserRepository;
import com.maveric.delivery.repository.DedRolesRepository;
import com.maveric.delivery.requestdto.PrivilegesDto;
import com.maveric.delivery.service.RolePrivilegesServiceImpl;
import com.maveric.delivery.service.UserServiceImpl;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.*;


@Service
@Slf4j
@RequiredArgsConstructor
public class  UtilMethods {

    private final DedRolesRepository dedRolesRepository;
    private final RolePrivilegesServiceImpl rolePrivilegesService;
    private final AzureUserRepository azureUserRepository;

    public List<String> getPrivilegesString(String highestRole, List<String> values) {
        List<PrivilegesDto> privilegesDtoList = rolePrivilegesService.findByName(values,highestRole);
        List<String> privileges = new ArrayList<>();
        for (PrivilegesDto privilegesDto : privilegesDtoList) {
            privileges.addAll(privilegesDto.getPrivileges());
        }
        return privileges;
    }

    public void checkValidRole(Long accountId, UUID userId, String role) {
        List<DedRoles> dedRoles = dedRolesRepository.findByAccountIdAndRoleAndProjectIdIsNull(accountId, role);
        if (dedRoles.stream()
                .noneMatch(dedRole -> dedRole.getOid().equals(userId))) {
            throw new UserNotFoundException("Invalid User Id found in the request for the role " + role);
        }
    }

    public String getDisplayName(UUID userId) {
        Optional<AzureUsers> userOptional = azureUserRepository.findById(userId);
        return userOptional.map(AzureUsers::getDisplayName).orElse("");
    }
}
