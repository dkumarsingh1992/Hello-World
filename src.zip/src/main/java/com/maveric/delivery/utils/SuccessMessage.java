package com.maveric.delivery.utils;

public enum SuccessMessage {

    ACCOUNT_CREATED ("S-1000","Account created successfully"),
    FETCH_ACCOUNTS("S-1001", "Accounts Fetched successfully"),
    FETCH_ACCOUNTS_COUNT("S-1002", "Accounts count fetched successfully"),
    FETCH_ACCOUNT("S-1003", "Account Fetched successfully"),
    UPDATE_ACCOUNT_DETAILS("S-1004", "Account details updated successfully"),
    AVAILABLE_ACCOUNT("S-1005", "Account name available : "),
    FETCH_COUNTRIES("S-1006", "Countries Fetched successfully"),

    PROJECT_TYPE_CREATED ("S-1007","ProjectType created successfully"),
    FETCH_PROJECT_TYPE("S-1008", "ProjectType Fetched successfully"),
    UPDATE_PROJECT_DETAILS("S-1004", "Project details updated successfully"),

    FETCH_PROJECT("S-1011","Project Fetched successfully"),
    PROJECT_NAME_EXIST("S-1012", "Project Name is available"),
    DUPLICATE_PROJECT_NAME("S-1013", "Project Name is already exist"),
    FETCH_TYPE("S-1101"," Type Fetched successfully"),
    FETCH_ACCOUNT_MEMBERS("S-1102","Account Members List for AccountId:"),
    FETCHED_PROJECT_STATUS("S-1103","Project Status fetched successfully"),
    FETCHED_ASSESSMENT_TEMPLATES("S-1104","Assessment Templates fetched successfully"),

    PROJECT_CREATED ("S-1009","Project created successfully"),
    PROJECT_LIST_FETCHED ("S-1010","Project List fetched successfully"),
    SAVE_PROJECT_ROLE("S-1010","ProjectRole saved successfully"),
    SAVE_ARTIFACT_TYPE("S-1011","Artifact type saved successfully"),
    SAVE_LOCATION("S-1012","Location saved successfully"),

    ARTIFACT_CREATED("S-1105","Artifact created successfully"),

    ARTIFACT_LIST_FETCHED("S-1011","Artifact list fetched successfully"),

    ARTIFACT_DELETED("S-1012","Artifact deleted successfully"),

    FETCH_ASSESSMENT("S-2001","Assessment fetched successfully"),
    USER_RESPONSE_SAVED("S-2002","User response saved successfully"),
    FETCH_ASSESSMENT_LIST("S-2003","Assessment list fetched successfully"),

    ROLE_PRIVILEGES_SAVE ("S-1020","Privileges saved successfully"),
    ROLE_PRIVILEGES_FETCHED ("S-1021","Privileges fetched successfully"),

    ROLES_FETCHED ("S-1022","Roles fetched successfully"),

    TEAM_MEMBER_CREATED("S-1030","TeamMember created successfully"),
    TEAM_MEMBER_LIST_FETCHED("S-1031","Team Member list fetched successfully"),
    FETCH_TEAM_MEMBER("S-1032", "Team Member Fetched successfully"),
    UPDATE_TEAM_MEMBER_DETAILS("S-1033", "Team Member details updated successfully"),
    ;
    private final String code;
    private final String message;

    SuccessMessage(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public static SuccessMessage fromCode(String code) {
        for (SuccessMessage successMessage : SuccessMessage.values()) {
            if (successMessage.code == code) {
                return successMessage;
            }
        }
        throw new IllegalArgumentException("Invalid error code");
    }

    @Override
    public String toString() {
        return "SuccessMessage{" +
                "code=" + code +
                ", message='" + message + '\'' +
                '}';
    }
}
