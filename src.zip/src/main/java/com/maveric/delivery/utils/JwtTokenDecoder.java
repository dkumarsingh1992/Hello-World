package com.maveric.delivery.utils;

import com.maveric.delivery.exception.PermissionDeniedException;
import com.nimbusds.jwt.JWT;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.JWTParser;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.util.Date;

import static com.maveric.delivery.utils.Constants.APP_ID;
import static com.maveric.delivery.utils.Constants.T_ID;

@Component
public class JwtTokenDecoder {
    @Value("${maveric.de-dashboard.tenantId}")
    private String tenantId;

    @Value("${maveric.de-dashboard.clientId}")
    private String clientId;

    @Value("${token.validation.enabled}")
    private boolean isTokenValidationEnabled;

    public JWTClaimsSet decodeToken(String token) {
        try {
            JWT jwt = JWTParser.parse(token);
            if(isTokenValidationEnabled)
                validateToken(jwt);
            return jwt.getJWTClaimsSet();
        } catch (ParseException e) {
            throw new PermissionDeniedException(FailedMessage.PERMISSION_DENIED.getMessage(), FailedMessage.PERMISSION_DENIED.getCode());
        }
    }

    private void validateToken(JWT jwt) throws ParseException {
        if (!StringUtils.equalsAnyIgnoreCase(tenantId,(String) jwt.getJWTClaimsSet().getClaim(T_ID)) || !StringUtils.equalsAnyIgnoreCase(clientId,(String) jwt.getJWTClaimsSet().getClaim(APP_ID))) {
            throw new PermissionDeniedException(FailedMessage.INVALID_TOKEN.getMessage(), FailedMessage.INVALID_TOKEN.getCode());
        }
        if (jwt.getJWTClaimsSet().getExpirationTime().before(new Date())) {
            throw new PermissionDeniedException(FailedMessage.EXPIRED_TOKEN.getMessage(), FailedMessage.EXPIRED_TOKEN.getCode());
        }
    }
}
