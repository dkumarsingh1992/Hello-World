package com.maveric.delivery.repository;

import com.maveric.delivery.model.Artifact;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

/**
 * @author shreyab
 */
@Repository
public interface ArtifactRepository extends MongoRepository<Artifact, Long> {
    List<Artifact> findByProjectId(Long projectId);

    List<Artifact> findByIdAndCreatedBy(Long artifactId, UUID userId);


}
