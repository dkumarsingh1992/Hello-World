package com.maveric.delivery.repository;

import com.maveric.delivery.model.RolePrivileges;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface RolePrivilegesRepository extends MongoRepository<RolePrivileges,Long> {

   //@Cacheable(value = "findByRoleId", key = "#roleId")
   Optional<RolePrivileges> findByRoleId(Long roleId);
}
