package com.maveric.delivery.repository;

import com.maveric.delivery.model.TeamMember;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface TeamMemberRepository extends MongoRepository<TeamMember,Long> {
    List<TeamMember> findByProjectId(Long projectId);
}
