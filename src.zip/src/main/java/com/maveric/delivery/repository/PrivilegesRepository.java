package com.maveric.delivery.repository;

import com.maveric.delivery.model.Privileges;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface PrivilegesRepository extends MongoRepository<Privileges,Long> {

}
