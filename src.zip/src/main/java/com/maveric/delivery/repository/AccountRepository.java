package com.maveric.delivery.repository;

import com.maveric.delivery.model.Account;
import com.maveric.delivery.responsedto.AccountResponseDto;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * @author ankushk
 */
@Repository
public interface AccountRepository extends MongoRepository<Account, Long> {

    List<Account>  findByAccountNameIgnoreCase(String accountName);

    List<Account> findByDedRoles_Oid(UUID userId);
    boolean existsByAccountName(String accountName);

    Account findByDedRoles_AccountId(Long accountId);



    @Query(value = "{'dedRoles.role': ?0}", count = true)
    long countByRoleIgnoreCase(String role);
}
