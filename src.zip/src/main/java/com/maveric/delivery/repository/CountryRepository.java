package com.maveric.delivery.repository;

import com.maveric.delivery.model.Country;
import org.springframework.data.mongodb.repository.MongoRepository;


public interface CountryRepository extends MongoRepository<Country,Long> {

}
