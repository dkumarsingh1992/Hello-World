package com.maveric.delivery.repository;

import com.maveric.delivery.model.Frequency;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface FrequencyRepository extends MongoRepository<Frequency,Long> {
}
