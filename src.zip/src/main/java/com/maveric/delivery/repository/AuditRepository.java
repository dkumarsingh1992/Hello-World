package com.maveric.delivery.repository;

import com.maveric.delivery.audit.Audit;
import lombok.RequiredArgsConstructor;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuditRepository extends MongoRepository<Audit,Long> {
}
