package com.maveric.delivery.mapper;

import com.maveric.delivery.model.RolePrivileges;
import com.maveric.delivery.requestdto.RolePrivilegesDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface RolePrivilegesMapper {

    RolePrivilegesMapper MAPPER = Mappers.getMapper(RolePrivilegesMapper.class);

    List<RolePrivileges> toEntityList(List<RolePrivilegesDto> rolePrivilegesDtoList);

    List<RolePrivilegesDto> toDtoList(List<RolePrivileges> rolePrivilegesList);

    RolePrivileges toEntity(RolePrivilegesDto rolePrivilegesDto);

    RolePrivilegesDto toDto(RolePrivileges rolePrivileges);

}
