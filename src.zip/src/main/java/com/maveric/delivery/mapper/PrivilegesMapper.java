package com.maveric.delivery.mapper;

import com.maveric.delivery.model.Privileges;
import com.maveric.delivery.requestdto.PrivilegesDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface PrivilegesMapper {
    PrivilegesMapper MAPPER = Mappers.getMapper(PrivilegesMapper.class);

    List<Privileges> toEntityList(List<PrivilegesDto> privilegesDtos);

    List<PrivilegesDto> toDtoList(List<Privileges> privileges);

    Privileges toEntity(PrivilegesDto privilegesDto);

    PrivilegesDto toDto(Privileges privileges);

}


