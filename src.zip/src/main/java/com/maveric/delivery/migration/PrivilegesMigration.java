package com.maveric.delivery.migration;

import com.maveric.delivery.model.Privileges;
import com.maveric.delivery.utils.JsonFileReader;
import io.mongock.api.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.io.IOException;
import java.util.List;

@ChangeUnit(id = "privileges", order = "001", author = "delivery-excellence", systemVersion = "1")
@Slf4j
public class PrivilegesMigration implements Migration {

    private final MongoTemplate mongoTemplate;

    private final JsonFileReader jsonFileReader;
    public PrivilegesMigration(MongoTemplate mongoTemplate, JsonFileReader jsonFileReader) {
        this.mongoTemplate = mongoTemplate;
        this.jsonFileReader = jsonFileReader;
    }

    private final String filePath = "/migration/data/privileges.json";


    @BeforeExecution
    @Override
    public void before() {
        log.info("Privileges Migration BeforeExecution");
    }

    //Note this method / annotation is Optional
    @RollbackBeforeExecution
    @Override
    public void rollbackBefore() {
        log.info("Privileges Migration RollbackBeforeExecution");
    }

    @Execution
    @Override
    public void migrationMethod() throws IOException {
        log.info("Privileges migrationMethod");
        List<Privileges> roles= jsonFileReader.readJsonFileToList(filePath, Privileges.class);
            mongoTemplate.insertAll(roles);
    }

    @RollbackExecution
    @Override
    public void rollback() {
        log.info("Privileges Migration RollbackBeforeExecution");
    }
}
