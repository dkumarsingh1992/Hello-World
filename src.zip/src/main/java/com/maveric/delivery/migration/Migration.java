package com.maveric.delivery.migration;

import java.io.IOException;

public interface Migration {

    void before();
    void rollbackBefore();
    void migrationMethod() throws IOException;
    void rollback();
}
