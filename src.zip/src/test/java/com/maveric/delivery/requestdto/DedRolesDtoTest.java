package com.maveric.delivery.requestdto;

import com.maveric.delivery.requestdto.DedRolesDto;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class DedRolesDtoTest {

    @Test
    void testConstructorAndGetters() {
        // Create test data
        UUID oid = UUID.randomUUID();
        Long accountId = 123L;
        Long projectId = 456L;
        String name = "John Doe";
        String role = "Developer";

        // Create an instance of DedRolesDto using the constructor
        DedRolesDto dedRolesDto = new DedRolesDto(oid, accountId, projectId, name, role);

        // Verify that the constructor sets the fields correctly
        assertEquals(oid, dedRolesDto.getOid());
        assertEquals(accountId, dedRolesDto.getAccountId());
        assertEquals(projectId, dedRolesDto.getProjectId());
        assertEquals(name, dedRolesDto.getName());
        assertEquals(role, dedRolesDto.getRole());
    }

    @Test
    void testSetters() {
        // Create an instance of DedRolesDto
        DedRolesDto dedRolesDto = new DedRolesDto();

        // Set values using setters
        UUID oid = UUID.randomUUID();
        Long accountId = 123L;
        Long projectId = 456L;
        String name = "John Doe";
        String role = "Developer";

        dedRolesDto.setOid(oid);
        dedRolesDto.setAccountId(accountId);
        dedRolesDto.setProjectId(projectId);
        dedRolesDto.setName(name);
        dedRolesDto.setRole(role);

        // Verify that the setters set the fields correctly
        assertEquals(oid, dedRolesDto.getOid());
        assertEquals(accountId, dedRolesDto.getAccountId());
        assertEquals(projectId, dedRolesDto.getProjectId());
        assertEquals(name, dedRolesDto.getName());
        assertEquals(role, dedRolesDto.getRole());
    }
}

