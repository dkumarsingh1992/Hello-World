package com.maveric.delivery.utils;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ConstantsTest {

    @Test
    void testConstants() {

        assertEquals("DH", Constants.DH);
        assertEquals("DP", Constants.DP);
        assertEquals("DM", Constants.DM);
        assertEquals("AP", Constants.AP);
        assertEquals("EP", Constants.EP);
     /*   assertEquals("AccountAdmin", Constants.ACCOUNT_ADMIN);
        assertEquals("ProjectAdmin", Constants.PROJECT_ADMIN);
        assertEquals("DeliveryOwner", Constants.DELIVERY_OWNER);
        assertEquals("OrgLeader", Constants.ORG_LEADER);*/
        assertEquals("Success", Constants.SUCCESS);
        assertEquals("Failed", Constants.FAILED);
        assertEquals("Delivery Head", Constants.DELIVERY_HEAD);
        assertEquals("Account Partner", Constants.ACCOUNT_PARTNER);
        assertEquals("Engagement Partner", Constants.ENGAGEMENT_PARTNER);
        assertEquals("Delivery Partner", Constants.DELIVERY_PARTNER);
        assertEquals("frequency", Constants.FREQUENCY);
        assertEquals("engagement-type", Constants.ENGAGEMENT_TYPE);
        assertEquals("business-subvertical", Constants.BUSINESS_SUB_VERTICAL);
    }
}
