package com.maveric.delivery.utils;

import com.maveric.delivery.exception.PermissionDeniedException;
import com.maveric.delivery.model.embedded.DedRoles;
import com.maveric.delivery.repository.AzureUserRepository;
import com.maveric.delivery.repository.DedRolesRepository;
import com.maveric.delivery.repository.RolesRepository;
import com.maveric.delivery.requestdto.DedRolesDto;
import com.maveric.delivery.requestdto.PrivilegesDto;
import com.maveric.delivery.requestdto.RolePrivilegesDto;
import com.maveric.delivery.requestdto.RolesDto;
import com.maveric.delivery.service.RolePrivilegesService;
import com.maveric.delivery.service.RolesService;
import com.maveric.delivery.service.UserServiceImpl;
import com.microsoft.graph.serviceclient.GraphServiceClient;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.*;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class ValidateApiAccessTest {

    @MockBean
    private RolePrivilegesService rolePrivilegesService;
    @Mock
    private UserServiceImpl userService;

    @MockBean
    private  UtilMethods utilMethods;

    @Autowired
    private ValidateApiAccess validateApiAccess;

    @MockBean
    private AzureUserRepository azureUserRepository;

    @Mock
    private  GraphServiceClient graphServiceClient;

    @MockBean
    private  DedRolesRepository dedRolesRepository;
    @MockBean
    private  RolesRepository rolesRepository;
    @MockBean
    private  RolesService rolesService;


    @Test
    void testPermissionDeniedExp() {

        DedRolesDto rolesDto = new DedRolesDto(UUID.randomUUID(), 1L, 1L, "test", "SUPER_ADMIN");
        List<DedRoles> dedRoles = new ArrayList<>();
        dedRoles.add(new DedRoles(UUID.randomUUID(), 1L, 1L, "test", "SUPER_ADMIN"));
        RolePrivilegesDto rolePrivilegesDto = new RolePrivilegesDto();
        rolePrivilegesDto.setRoleName(SUPER_ADMIN_);
        List<PrivilegesDto> privilegesDtos = new ArrayList<>();
        rolePrivilegesDto.setPrivileges(privilegesDtos);
        List<RolesDto> roles = new ArrayList<>();
        RolesDto rolesDto1 = new RolesDto();
        rolesDto1.setHierarchy(1);
        rolesDto1.setName(SUPER_ADMIN_);
        roles.add(rolesDto1);
        when(dedRolesRepository.findByOid(any(UUID.class))).thenReturn(dedRoles);
        when(dedRolesRepository.findByOidAndAccountId(any(UUID.class), any(Long.class))).thenReturn(dedRoles);
        when(dedRolesRepository.findByOidAndProjectIdAndAccountId(any(UUID.class), any(Long.class),any(Long.class))).thenReturn(dedRoles);
        when(rolesService.findByGroups(any(List.class))).thenReturn(roles);
        when(userService.getHighestRole(any(UUID.class), any(Long.class), any(Long.class))).thenReturn(SUPER_ADMIN_);
        when(rolePrivilegesService.findByName(any(String.class))).thenReturn(rolePrivilegesDto);

        assertThrows(PermissionDeniedException.class, () -> validateApiAccess.isAccessible(rolesDto, ACCOUNTS, CREATE));
    }

    @Test
    void test_supper_admin() {

        DedRolesDto rolesDto = new DedRolesDto(UUID.randomUUID(), 1L, 1L, "test", "SUPER_ADMIN");
        List<DedRoles> dedRoles = new ArrayList<>();
        dedRoles.add(new DedRoles(UUID.randomUUID(), 1L, 1L, "test", "SUPER_ADMIN"));
        RolePrivilegesDto rolePrivilegesDto = new RolePrivilegesDto();
        rolePrivilegesDto.setRoleName(SUPER_ADMIN_);
        List<PrivilegesDto> privilegesDtos = new ArrayList<>();
        privilegesDtos.add(new PrivilegesDto(ACCOUNTS, Collections.singletonList(CREATE) ));
        rolePrivilegesDto.setPrivileges(privilegesDtos);
        List<RolesDto> roles = new ArrayList<>();
        RolesDto rolesDto1 = new RolesDto();
        rolesDto1.setHierarchy(1);
        rolesDto1.setName(SUPER_ADMIN_);
        roles.add(rolesDto1);
        when(dedRolesRepository.findByOid(any(UUID.class))).thenReturn(dedRoles);
        when(dedRolesRepository.findByOidAndAccountId(any(UUID.class), any(Long.class))).thenReturn(dedRoles);
        when(dedRolesRepository.findByOidAndProjectIdAndAccountId(any(UUID.class), any(Long.class),any(Long.class))).thenReturn(dedRoles);
        when(rolesService.findByGroups(any(List.class))).thenReturn(roles);
        when(userService.getHighestRole(any(UUID.class), any(Long.class), any(Long.class))).thenReturn(SUPER_ADMIN_);
        when(rolePrivilegesService.findByName(any(String.class))).thenReturn(rolePrivilegesDto);
        assertDoesNotThrow(() -> validateApiAccess.isAccessible(rolesDto, ACCOUNTS, CREATE));

    }
    @Test
    void test_account_admin() {

        DedRolesDto rolesDto = new DedRolesDto(UUID.randomUUID(), 1L, 1L, "test", "ACCOUNT_ADMIN");
        List<DedRoles> dedRoles = new ArrayList<>();
        dedRoles.add(new DedRoles(UUID.randomUUID(), 1L, 1L, "test", "ACCOUNT_ADMIN"));
        RolePrivilegesDto rolePrivilegesDto = new RolePrivilegesDto();
        List<PrivilegesDto> privilegesDtos = new ArrayList<>();
        privilegesDtos.add(new PrivilegesDto(ACCOUNTS, Collections.singletonList(CREATE) ));
        rolePrivilegesDto.setRoleName(PROJECT_ADMIN_);
        rolePrivilegesDto.setPrivileges(privilegesDtos);
        List<RolesDto> roles = new ArrayList<>();
        RolesDto rolesDto1 = new RolesDto();
        rolesDto1.setHierarchy(2);
        rolesDto1.setName(PROJECT_ADMIN_);
        roles.add(rolesDto1);
        when(dedRolesRepository.findByOid(any(UUID.class))).thenReturn(dedRoles);
        when(dedRolesRepository.findByOidAndAccountId(any(UUID.class), any(Long.class))).thenReturn(dedRoles);
        when(dedRolesRepository.findByOidAndProjectIdAndAccountId(any(UUID.class), any(Long.class),any(Long.class))).thenReturn(dedRoles);
        when(rolesService.findByGroups(any(List.class))).thenReturn(roles);
        when(userService.getHighestRole(any(UUID.class), any(Long.class), any(Long.class))).thenReturn(ACCOUNT_ADMIN_);
        when(rolePrivilegesService.findByName(any(String.class))).thenReturn(rolePrivilegesDto);
        assertDoesNotThrow(() -> validateApiAccess.isAccessible(rolesDto, ACCOUNTS, CREATE));

    }
    @Test
    void test_project_admin() {

        DedRolesDto rolesDto = new DedRolesDto(UUID.randomUUID(), 1L, 1L, "test", "PROJECT_ADMIN");
        List<DedRoles> dedRoles = new ArrayList<>();
        dedRoles.add(new DedRoles(UUID.randomUUID(), 1L, 1L, "test", "PROJECT_ADMIN"));
        RolePrivilegesDto rolePrivilegesDto = new RolePrivilegesDto();
        List<PrivilegesDto> privilegesDtos = new ArrayList<>();
        privilegesDtos.add(new PrivilegesDto(ACCOUNTS, Collections.singletonList(CREATE) ));
        rolePrivilegesDto.setRoleName(PROJECT_ADMIN_);
        rolePrivilegesDto.setPrivileges(privilegesDtos);
        List<RolesDto> roles = new ArrayList<>();
        RolesDto rolesDto1 = new RolesDto();
        rolesDto1.setHierarchy(3);
        rolesDto1.setName(PROJECT_ADMIN_);
        roles.add(rolesDto1);
        when(dedRolesRepository.findByOid(any(UUID.class))).thenReturn(dedRoles);
        when(dedRolesRepository.findByOidAndAccountId(any(UUID.class), any(Long.class))).thenReturn(dedRoles);
        when(dedRolesRepository.findByOidAndProjectIdAndAccountId(any(UUID.class), any(Long.class),any(Long.class))).thenReturn(dedRoles);
        when(rolesService.findByGroups(any(List.class))).thenReturn(roles);
        when(userService.getHighestRole(any(UUID.class), any(Long.class), any(Long.class))).thenReturn(PROJECT_ADMIN_);
        when(rolePrivilegesService.findByName(any(String.class))).thenReturn(rolePrivilegesDto);
        assertDoesNotThrow(() -> validateApiAccess.isAccessible(rolesDto, ACCOUNTS, CREATE));

    }
    @Test
    void test_delivery_owner() {

        DedRolesDto rolesDto = new DedRolesDto(UUID.randomUUID(), 1L, 1L, "test", "DELIVERY_OWNER");
        List<DedRoles> dedRoles = new ArrayList<>();
        dedRoles.add(new DedRoles(UUID.randomUUID(), 1L, 1L, "test", "DELIVERY_OWNER"));
        RolePrivilegesDto rolePrivilegesDto = new RolePrivilegesDto();
        List<PrivilegesDto> privilegesDtos = new ArrayList<>();
        privilegesDtos.add(new PrivilegesDto(ACCOUNTS, Collections.singletonList(CREATE) ));
        rolePrivilegesDto.setRoleName(DELIVERY_OWNER_);
        rolePrivilegesDto.setPrivileges(privilegesDtos);
        List<RolesDto> roles = new ArrayList<>();
        RolesDto rolesDto1 = new RolesDto();
        rolesDto1.setHierarchy(4);
        rolesDto1.setName(DELIVERY_OWNER_);
        roles.add(rolesDto1);
        when(dedRolesRepository.findByOid(any(UUID.class))).thenReturn(dedRoles);
        when(dedRolesRepository.findByOidAndAccountId(any(UUID.class), any(Long.class))).thenReturn(dedRoles);
        when(dedRolesRepository.findByOidAndProjectIdAndAccountId(any(UUID.class), any(Long.class),any(Long.class))).thenReturn(dedRoles);
        when(rolesService.findByGroups(any(List.class))).thenReturn(roles);
        when(userService.getHighestRole(any(UUID.class), any(Long.class), any(Long.class))).thenReturn(DELIVERY_OWNER_);
        when(rolePrivilegesService.findByName(any(String.class))).thenReturn(rolePrivilegesDto);
        assertDoesNotThrow(() -> validateApiAccess.isAccessible(rolesDto, ACCOUNTS, CREATE));

    }
    @Test
    void test_organization_leader() {

        DedRolesDto rolesDto = new DedRolesDto(UUID.randomUUID(), 1L, 1L, "test", "ORGANIZATION_LEADER");
        List<DedRoles> dedRoles = new ArrayList<>();
        dedRoles.add(new DedRoles(UUID.randomUUID(), 1L, 1L, "test", "ORGANIZATION_LEADER"));
        RolePrivilegesDto rolePrivilegesDto = new RolePrivilegesDto();
        List<PrivilegesDto> privilegesDtos = new ArrayList<>();
        privilegesDtos.add(new PrivilegesDto(ACCOUNTS, Collections.singletonList(CREATE) ));
        rolePrivilegesDto.setRoleName(ORGANIZATION_LEADER_);
        rolePrivilegesDto.setPrivileges(privilegesDtos);
        List<RolesDto> roles = new ArrayList<>();
        RolesDto rolesDto1 = new RolesDto();
        rolesDto1.setHierarchy(5);
        rolesDto1.setName(ORGANIZATION_LEADER_);
        roles.add(rolesDto1);
        when(dedRolesRepository.findByOid(any(UUID.class))).thenReturn(dedRoles);
        when(dedRolesRepository.findByOidAndAccountId(any(UUID.class), any(Long.class))).thenReturn(dedRoles);
        when(dedRolesRepository.findByOidAndProjectIdAndAccountId(any(UUID.class), any(Long.class),any(Long.class))).thenReturn(dedRoles);
        when(rolesService.findByGroups(any(List.class))).thenReturn(roles);
        when(userService.getHighestRole(any(UUID.class), any(Long.class), any(Long.class))).thenReturn(ORGANIZATION_LEADER_);
        when(rolePrivilegesService.findByName(any(String.class))).thenReturn(rolePrivilegesDto);
        assertDoesNotThrow(() -> validateApiAccess.isAccessible(rolesDto, ACCOUNTS, CREATE));

    }
    @Test
    void test_team_member() {

        DedRolesDto rolesDto = new DedRolesDto(UUID.randomUUID(), 1L, 1L, "test", "TEAM_MEMBERS");
        List<DedRoles> dedRoles = new ArrayList<>();
        dedRoles.add(new DedRoles(UUID.randomUUID(), 1L, 1L, "test", "TEAM_MEMBERS"));
        RolePrivilegesDto rolePrivilegesDto = new RolePrivilegesDto();
        List<PrivilegesDto> privilegesDtos = new ArrayList<>();
        privilegesDtos.add(new PrivilegesDto(ACCOUNTS, Collections.singletonList(CREATE) ));
        rolePrivilegesDto.setRoleName(TEAM_MEMBER_);
        rolePrivilegesDto.setPrivileges(privilegesDtos);
        List<RolesDto> roles = new ArrayList<>();
        RolesDto rolesDto1 = new RolesDto();
        rolesDto1.setHierarchy(6);
        rolesDto1.setName(TEAM_MEMBER_);
        roles.add(rolesDto1);
        when(dedRolesRepository.findByOid(any(UUID.class))).thenReturn(dedRoles);
        when(dedRolesRepository.findByOidAndAccountId(any(UUID.class), any(Long.class))).thenReturn(dedRoles);
        when(dedRolesRepository.findByOidAndProjectIdAndAccountId(any(UUID.class), any(Long.class),any(Long.class))).thenReturn(dedRoles);
        when(rolesService.findByGroups(any(List.class))).thenReturn(roles);
        when(userService.getHighestRole(any(UUID.class), any(Long.class), any(Long.class))).thenReturn(TEAM_MEMBER_);
        when(rolePrivilegesService.findByName(any(String.class))).thenReturn(rolePrivilegesDto);
        assertDoesNotThrow(() -> validateApiAccess.isAccessible(rolesDto, ACCOUNTS, CREATE));

    }

}