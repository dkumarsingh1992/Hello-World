package com.maveric.delivery.service;

import com.maveric.delivery.exception.DataNotFoundException;
import com.maveric.delivery.model.Roles;
import com.maveric.delivery.repository.RolesRepository;
import com.maveric.delivery.requestdto.RolesDto;
import com.maveric.delivery.utils.FailedMessage;
import com.maveric.delivery.utils.UtilMethods;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class RolesServiceImplTest {

    @MockBean
    private RolesRepository rolesRepository;

    @Autowired
    private RolesServiceImpl rolesService;

    @MockBean
    private UtilMethods utilMethods;
    Long roleId = Long.valueOf(1);

    @Test
    void getRoleName_success() {
        Roles role = new Roles();
        role.setName("Supper Admin");
        when(rolesRepository.findById(roleId)).thenReturn(Optional.of(role));
        String roleName = rolesService.getRoleName(roleId);
        assertNotNull(roleName);
        assertEquals("Supper Admin", roleName);
    }

    @Test
    void getRoles_success() {
        Roles role = new Roles();
        role.setName("Supper Admin");
        when(rolesRepository.findAll()).thenReturn(Collections.singletonList(role));
        List<RolesDto> rolesDtos = rolesService.getRoles();
        assertNotNull(rolesDtos);
    }

    @Test
    void getRole_success() {
        Roles role = new Roles();
        role.setName("Supper Admin");
        when(rolesRepository.findById(roleId)).thenReturn(Optional.of(role));
        RolesDto rolesDto = rolesService.getRole(roleId);
        assertNotNull(rolesDto);
        assertEquals("Supper Admin", rolesDto.getName());
    }

    @Test
    void getRole_failure() {
        Roles role = new Roles();
        role.setName("Supper Admin");
        when(rolesRepository.findById(roleId)).thenThrow(new DataNotFoundException(FailedMessage.DATA_NOT_FOUND.getMessage().replace("<DATA>", "Roles"), FailedMessage.DATA_NOT_FOUND.getCode()));
        assertThrows(DataNotFoundException.class, () -> rolesService.getRole(roleId));
    }
}