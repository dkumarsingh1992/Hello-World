package com.maveric.delivery.service;

import com.maveric.delivery.audit.AuditImpl;
import com.maveric.delivery.model.ProjectType;
import com.maveric.delivery.repository.AzureUserRepository;
import com.maveric.delivery.repository.ProjectTypeRepository;
import com.maveric.delivery.responsedto.BaseDto;
import com.maveric.delivery.responsedto.ProjectTypeDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class ProjectTypeServiceTest {

    @Mock
    private ProjectTypeRepository projectTypeRepository;

    @InjectMocks
    private ProjectTypeServiceImpl projectTypeService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @MockBean
    AuditImpl auditImpl;
    @Test
    void testSaveProjectType() {

        ProjectTypeDto requestPayload = new ProjectTypeDto();
        requestPayload.setName("Example1");
        requestPayload.setDescription("Description 1");

        ProjectType savedProjectType = new ProjectType();
        savedProjectType.setId(1L);
        savedProjectType.setName(requestPayload.getName());
        savedProjectType.setDescription(requestPayload.getDescription());

        when(projectTypeRepository.save(any(ProjectType.class))).thenReturn(savedProjectType);

        ProjectType result = projectTypeService.saveProjectType(requestPayload);

        assertEquals(savedProjectType.getId(), result.getId());
        assertEquals(savedProjectType.getName(), result.getName());
        assertEquals(savedProjectType.getDescription(), result.getDescription());
        verify(projectTypeRepository, times(1)).save(any(ProjectType.class));
    }

    @Test
    void testFetchAllProjectType() {
        List<ProjectType> projectTypes = new ArrayList<>();
        projectTypes.add(new ProjectType("example1", "Description 1"));
        projectTypes.add(new ProjectType("example2", "Description 2"));

        when(projectTypeRepository.findAll()).thenReturn(projectTypes);

        List<BaseDto> result = projectTypeService.fetchAllProjectType();

        assertEquals(projectTypes.size(), result.size());
        verify(projectTypeRepository, times(1)).findAll();
    }
}

