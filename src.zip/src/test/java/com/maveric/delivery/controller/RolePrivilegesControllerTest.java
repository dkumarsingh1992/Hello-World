package com.maveric.delivery.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.delivery.audit.AuditImpl;
import com.maveric.delivery.requestdto.PrivilegesDto;
import com.maveric.delivery.requestdto.RolePrivilegesDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.RolePrivilegesService;
import com.maveric.delivery.utils.ValidateApiAccess;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(RolePrivilegesController.class)
class RolePrivilegesControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;


    @MockBean
    private RolePrivilegesService rolePrivilegesService;

    @MockBean
    private ValidateApiAccess validateApiAccess;

    @MockBean
    AuditImpl auditImpl;

    private final String oId = UUID.randomUUID().toString();

    @Test
    void save_success() throws Exception {

        List<RolePrivilegesDto> rolePrivilegesDtos = new ArrayList<>();
        RolePrivilegesDto rolePrivilegesDto = new RolePrivilegesDto();
        rolePrivilegesDto.setRoleId(1L);
        List<PrivilegesDto> privilegesDtos = new ArrayList<>();
        privilegesDtos.add(new PrivilegesDto(ACCOUNTS, Collections.singletonList(CREATE) ));
        rolePrivilegesDto.setPrivileges(privilegesDtos);
        rolePrivilegesDtos.add(rolePrivilegesDto);
        when(rolePrivilegesService.save(any(List.class))).thenReturn(rolePrivilegesDtos);

        MockHttpServletRequestBuilder requestBuilder = post("/v1/role-privileges").requestAttr(O_ID, oId)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(rolePrivilegesDtos));
        MvcResult result = mockMvc.perform(requestBuilder)
                .andExpect(status().isCreated())
                .andReturn();


        ResponseDto<List<RolePrivilegesDto>> responseDto = objectMapper.readValue(
                result.getResponse().getContentAsString(),
                new TypeReference<ResponseDto<List<RolePrivilegesDto>>>() {
                });
        assertEquals("Success", responseDto.getStatus());
        assertEquals("S-1020", responseDto.getCode());
        assertEquals("Privileges saved successfully", responseDto.getMessage());
        assertEquals(rolePrivilegesDtos, responseDto.getPayload());
    }

    @Test
    void get_success() throws Exception {

        List<RolePrivilegesDto> rolePrivilegesDtos = new ArrayList<>();
        when(rolePrivilegesService.findAll()).thenReturn(rolePrivilegesDtos);

        MockHttpServletRequestBuilder requestBuilder = get("/v1/role-privileges").requestAttr(O_ID, oId)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder)
                .andExpect(status().isOk())
                .andReturn();


        ResponseDto<List<RolePrivilegesDto>> responseDto = objectMapper.readValue(
                result.getResponse().getContentAsString(),
                new TypeReference<ResponseDto<List<RolePrivilegesDto>>>() {
                });
        assertEquals("Success", responseDto.getStatus());
        assertEquals("S-1021", responseDto.getCode());
        assertEquals("Privileges fetched successfully", responseDto.getMessage());
        assertEquals(rolePrivilegesDtos, responseDto.getPayload());
    }

    @Test
    void findByRoleId_success() throws Exception {

        RolePrivilegesDto rolePrivilegesDto = new RolePrivilegesDto();
        when(rolePrivilegesService.findByRoleId(any(Long.class))).thenReturn(rolePrivilegesDto);

        MockHttpServletRequestBuilder requestBuilder = get("/v1/role-privileges/role/1").requestAttr(O_ID, oId)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder)
                .andExpect(status().isOk())
                .andReturn();


        ResponseDto<RolePrivilegesDto> responseDto = objectMapper.readValue(
                result.getResponse().getContentAsString(),
                new TypeReference<ResponseDto<RolePrivilegesDto>>() {
                });
        assertEquals("Success", responseDto.getStatus());
        assertEquals("S-1021", responseDto.getCode());
        assertEquals("Privileges fetched successfully", responseDto.getMessage());
        assertEquals(rolePrivilegesDto, responseDto.getPayload());
    }
}