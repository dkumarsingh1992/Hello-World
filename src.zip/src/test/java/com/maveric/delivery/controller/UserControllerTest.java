package com.maveric.delivery.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.delivery.audit.AuditImpl;
import com.maveric.delivery.requestdto.UserPrivilegesDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.UserService;
import com.maveric.delivery.utils.ValidateApiAccess;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.util.UUID;

import static com.maveric.delivery.utils.Constants.O_ID;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(UserController.class)
@AutoConfigureMockMvc
class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private UserService userService;

    @MockBean
    private ValidateApiAccess validateApiAccess;

    @MockBean
    AuditImpl auditImpl;

    String oId = UUID.randomUUID().toString();

    @Test
    void userPrivileges() throws Exception {
        UserPrivilegesDto userPrivilegesDto = new UserPrivilegesDto();
        when(userService.getPrivileges(any(UUID.class))).thenReturn(userPrivilegesDto);

        MockHttpServletRequestBuilder requestBuilder = get("/v1/users/privileges").requestAttr(O_ID, oId)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
        .requestAttr(O_ID, oId);
        MvcResult result = mockMvc.perform(requestBuilder)
                .andExpect(status().isOk())
                .andReturn();

        ResponseDto<UserPrivilegesDto> responseDto = objectMapper.readValue(
                result.getResponse().getContentAsString(),

                new TypeReference<ResponseDto<UserPrivilegesDto>>() {
                });
        assertEquals("Success", responseDto.getStatus());
        assertEquals("S-1021", responseDto.getCode());
        assertEquals("Privileges fetched successfully", responseDto.getMessage());
        assertEquals(userPrivilegesDto, responseDto.getPayload());

    }

}