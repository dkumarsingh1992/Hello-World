package com.maveric.delivery.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.delivery.audit.AuditImpl;
import com.maveric.delivery.model.Account;
import com.maveric.delivery.model.embedded.*;
import com.maveric.delivery.repository.AuditRepository;
import com.maveric.delivery.repository.AzureUserRepository;
import com.maveric.delivery.requestdto.*;
import com.maveric.delivery.responsedto.AccountMemberDto;
import com.maveric.delivery.responsedto.AccountNamesResponseDto;
import com.maveric.delivery.responsedto.AccountResponseDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.AccountServiceImpl;
import com.maveric.delivery.utils.ValidateApiAccess;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.Test;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.*;

import static com.maveric.delivery.utils.Constants.O_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(AccountController.class)
@AutoConfigureMockMvc
public class AccountControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private AccountServiceImpl accountService;

    @MockBean
    private AzureUserRepository azureUserRepository;

    @MockBean
    AuditImpl auditImpl;

    @MockBean
    private AuditRepository auditRepository;

    @MockBean
    private ValidateApiAccess validateApiAccess;

    private final String oId ="d4682ac9-3e2c-49dd-bca4-ea784aa0eb4e";


    @Test
    public void testSaveAccount_ValidInput_Success() throws Exception {
        AccountRequestDto requestDto = createValidAccountRequestDto();
        AccountResponseDto createdAccount = new AccountResponseDto();
        when(accountService.createAccount(any(AccountRequestDto.class))).thenReturn(createdAccount);
        MockHttpServletRequestBuilder requestBuilder = post("/v1/accounts").requestAttr(O_ID, oId)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(requestDto));
        MvcResult result = mockMvc.perform(requestBuilder)
                .andExpect(status().isCreated())
                .andReturn();


        ResponseDto<AccountResponseDto> responseDto = objectMapper.readValue(
                result.getResponse().getContentAsString(),
                new TypeReference<ResponseDto<AccountResponseDto>>() {
                });
        assertEquals("Success", responseDto.getStatus());
        assertEquals("S-1000", responseDto.getCode());
        assertEquals("Account created successfully", responseDto.getMessage());
        assertEquals(createdAccount, responseDto.getPayload());
    }


    @Test
    public void testGetAllAccountsByOid_SuccessfulWithAccounts() throws Exception {
        UUID userId = UUID.fromString("d4682ac9-3e2c-49dd-bca4-ea784aa0eb4e");
        List<AccountSummaryDto> accounts = Collections.singletonList(new AccountSummaryDto(1L, "Account1", "John Doe", "Delivery Partner", "Account Partner", "Engagement Partner", 1709116800000l, AccountType.Internal, 2L, 5L, AccountStatus.Active));

        when(accountService.getAllAccountsByUserId(userId)).thenReturn(accounts);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/v1/accounts/userId/{userId}", userId).requestAttr(O_ID, oId)
                        .header("userId", userId.toString())
                        .contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        int statusCode = result.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), statusCode);

        ResponseDto<?> responseDto = objectMapper.readValue(
                result.getResponse().getContentAsString(),
                new TypeReference<ResponseDto<List<AccountSummaryDto>>>() {
                });
        assertEquals("S-1001", responseDto.getCode());
        List<AccountSummaryDto> returnedAccounts = (List<AccountSummaryDto>) responseDto.getPayload();
        assertNotNull(returnedAccounts);
        assertFalse(returnedAccounts.isEmpty());
        assertEquals(accounts.size(), returnedAccounts.size());
    }

    @Test
    public void testGetAccountById_AccountFound_Success() throws Exception {

        AccountResponseDto accountResponseDto = new AccountResponseDto();
        accountResponseDto.setAccountId(1L);
        UUID oid = UUID.fromString(oId);
        when(accountService.getAccountById(1L, oid)).thenReturn(accountResponseDto);
        MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get("http://localhost:8080/v1/accounts/1").header("userId", oid).requestAttr(O_ID, oId)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();
        String responseBody = result.getResponse().getContentAsString();
        ResponseDto<AccountResponseDto> responseDto = objectMapper.readValue(responseBody, ResponseDto.class);
        assertEquals("S-1003", responseDto.getCode());
        assertEquals("Account Fetched successfully", responseDto.getMessage());
        assertNotNull(responseDto.getPayload());
    }


    @Test
    public void testGetSummaryCounts_AccountsFound_Success() throws Exception {
        UUID userId = UUID.randomUUID(); // Assuming a random UUID for testing
        AccountSummaryCountDto summaryCountDto = new AccountSummaryCountDto();
        summaryCountDto.setAccounts(5);
        summaryCountDto.setAssessmentCompleted(0);
        summaryCountDto.setProjects(0);
        summaryCountDto.setArtifacts(0);
        summaryCountDto.setProjects(0);
        summaryCountDto.setTeamMembers(0);// Assuming there are 5 accounts for the specified OID
        when(accountService.getCountOfAccountByuserId(UUID.fromString(oId))).thenReturn(summaryCountDto);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/v1/accounts/summaryCount/userId/{userId}", oId).requestAttr(O_ID, oId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andReturn();
        int statusCode = result.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), statusCode);

        ResponseDto<AccountSummaryCountDto> responseDto = objectMapper.readValue(
                result.getResponse().getContentAsString(),
                new TypeReference<ResponseDto<AccountSummaryCountDto>>() {
                });

        assertEquals("S-1002", responseDto.getCode());
        assertEquals("Accounts count fetched successfully", responseDto.getMessage());
        assertEquals(summaryCountDto, responseDto.getPayload());
    }

    @Test
    public void testEditAccount_AccountEditedSuccessfully() throws Exception {
        Long accountId = 1L;
        AccountRequestDto accountRequestDto = createValidAccountRequestDto();
        AccountResponseDto editedAccount = new AccountResponseDto();
        editedAccount.setAccountId(accountId);
        editedAccount.setAccountName("changed Name");
        BeanUtils.copyProperties(accountRequestDto, editedAccount);
        when(accountService.editAccount(eq(accountRequestDto), eq(accountId))).thenReturn(editedAccount);
        MockHttpServletRequestBuilder request = MockMvcRequestBuilders.put("/v1/accounts/{accountId}", accountId).requestAttr(O_ID, oId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(accountRequestDto));
        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();
        String responseBody = result.getResponse().getContentAsString();
        ResponseDto<AccountResponseDto> responseDto = objectMapper.readValue(responseBody, ResponseDto.class);
        assertEquals("S-1004", responseDto.getCode());
        assertEquals("Account details updated successfully", responseDto.getMessage());
        assertNotNull(responseDto.getPayload());
    }

    @Test
    public void testDuplicateAccountName_AccountNameIsDuplicate() throws Exception {

        String accountName = "Sample Account";
        when(accountService.duplicateAccountName(accountName)).thenReturn(true);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/v1/accounts/duplicate/{accountName}", accountName).requestAttr(O_ID, oId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andReturn();


        int statusCode = result.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), statusCode);

        ResponseDto<?> responseDto = objectMapper.readValue(
                result.getResponse().getContentAsString(),
                new TypeReference<ResponseDto<?>>() {
                });

        assertNotNull(responseDto);
        assertEquals("E-1005", responseDto.getCode());
        assertEquals("Account name already exists : ".concat(accountName), responseDto.getMessage());
        assertNull(responseDto.getPayload());
    }

    @Test
    public void testDuplicateAccountName_AccountNameIsNotDuplicate() throws Exception {
        String accountName = "New Sample Account";
        when(accountService.duplicateAccountName(accountName)).thenReturn(false);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/v1/accounts/duplicate/{accountName}", accountName).requestAttr(O_ID, oId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        int statusCode = result.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), statusCode);

        ResponseDto<?> responseDto = objectMapper.readValue(
                result.getResponse().getContentAsString(),
                new TypeReference<ResponseDto<?>>() {
                });

        assertNotNull(responseDto);
        assertEquals("S-1005", responseDto.getCode());
        assertEquals("Account name available : ".concat(accountName), responseDto.getMessage());
        assertNull(responseDto.getPayload());
    }

    public static AccountRequestDto createValidAccountRequestDto() {
        AccountRequestDto dto = new AccountRequestDto();
        dto.setAccountName("Sample Account");
        List<String> tags = new ArrayList<>();
        tags.add("tag1");
        tags.add("tag2");
        tags.add("tag3");
        dto.setTags(tags);
        dto.setAccountType(AccountType.Internal);
        List<DedRoles> dedRolesList = new ArrayList<>();
        DedRoles role1 = new DedRoles(UUID.randomUUID(), 1L, 1L, "SampleName", "Role1");
        dedRolesList.add(role1);
        AccountRoles deliveryHeads = new AccountRoles(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa1"), "Test DH1");
        dto.setDeliveryHead(Collections.singletonList(deliveryHeads));
        List<AccountRoles> accountPartners = Arrays.asList(
                new AccountRoles(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa4"), "Test AP1")
        );
        dto.setAccountPartners(accountPartners);
        List<AccountRoles> engagementPartners = Arrays.asList(
                new AccountRoles(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa5"), "Test EP1")
        );
        dto.setEngagementPartners(engagementPartners);
        List<AccountRoles> deliveryPartners = Arrays.asList(
                new AccountRoles(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa6"), "Test DP1")
        );
        dto.setDeliveryPartners(deliveryPartners);
        dto.setDateOnboarded(1709116800000l);
        dto.setStatus(AccountStatus.Active);

        dto.setExternalId("EXT123");

        ClientInformation clientInfo = getClientInformation();
        dto.setClientInfo(clientInfo);
        return dto;
    }

    @NotNull
    private static ClientInformation getClientInformation() {
        ClientInformation clientInfo = new ClientInformation();
        clientInfo.setClientName("Example Client");
        clientInfo.setClientDescription("Tech company providing solutions");
        clientInfo.setBusinessAddressLineOne("123 Main St");
        clientInfo.setBusinessAddressLineTwo("Suite 200");
        clientInfo.setBusinessCity("San Francisco");
        clientInfo.setBusinessState("CA");
        clientInfo.setBusinessCountry("United States");
        List<ClientContacts> clientContactsList = new ArrayList<>();
        ClientContacts contact1 = new ClientContacts("John Doe", "Manager", "john@example.com", "+1234567890");
        ClientContacts contact2 = new ClientContacts("Jane Smith", "Director", "jane@example.com", "+1987654321");
        clientContactsList.add(contact1);
        clientContactsList.add(contact2);
        clientInfo.setContactsList(clientContactsList);
        return clientInfo;
    }

    private static List<DedRoles> createMockDedRoles() {
        List<DedRoles> dedRoles = new ArrayList<>();
        dedRoles.add(new DedRoles(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa3"), null, 0L, "Barani", "DH"));
        dedRoles.add(new DedRoles(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa4"), null, 0L, "Sham", "DP"));
        dedRoles.add(new DedRoles(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa5"), null, 0L, "Krishna", "AP"));
        dedRoles.add(new DedRoles(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa6"), null, 0L, "Barani", "EP"));
        dedRoles.add(new DedRoles(UUID.fromString("3fa85f64-5717-4562-b3fc-2c963f66afa7"), null, 0L, "Ankush", "SuperAdmin"));
        return dedRoles;
    }

    public static Account mapDtoToAccount(AccountRequestDto dto) {
        Account account = new Account();

        account.setAccountName(dto.getAccountName());
        account.setAccountType(dto.getAccountType());
        account.setDedRoles(createMockDedRoles());
        account.setStatus(dto.getStatus());
        account.setExternalId(dto.getExternalId());
        account.setClientInfo(dto.getClientInfo());
        account.setDateOnboarded(System.currentTimeMillis());
        account.setCreatedBy(UUID.randomUUID());
        account.setCreatedAt(System.currentTimeMillis());
        account.setUpdatedBy(UUID.randomUUID());
        account.setUpdatedAt(System.currentTimeMillis());

        return account;
    }

    @Test
    public void testGetAccountsListByUserId() throws Exception {
        UUID oid = UUID.fromString(oId);
        AccountNamesResponseDto accountNamesResponseDto = new AccountNamesResponseDto();
        List<AccountListDto> accounts = Collections.singletonList(new AccountListDto(991740250L, "newtest"));
        accountNamesResponseDto.setAccountListDtoList(accounts);
        when(accountService.getAccountsList(oid)).thenReturn(accountNamesResponseDto);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/v1/accounts/names", oid).requestAttr(O_ID, oId)
                        .header("userId", oid.toString())
                        .contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        int statusCode = result.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), statusCode);

        ResponseDto<?> responseDto = objectMapper.readValue(
                result.getResponse().getContentAsString(),
                new TypeReference<ResponseDto<AccountNamesResponseDto>>() {
                });
        assertEquals("S-1001", responseDto.getCode());
        AccountNamesResponseDto returnedAccounts = (AccountNamesResponseDto) responseDto.getPayload();
        assertNotNull(returnedAccounts);
        assertFalse(returnedAccounts.getAccountListDtoList().isEmpty());
        assertEquals(accounts.size(), returnedAccounts.getAccountListDtoList().size());
    }

    @Test
    public void testGetAccountMembers() throws Exception {
        AccountMemberDto accountMemberDto = new AccountMemberDto();
        List<AccountRoles> accountRoles = new ArrayList<>();
        accountRoles.add(new AccountRoles("9e200b5e-d5cc-4171-bc4e-a6aaf519be9f", "Aachis Rishidev Iyappan"));
        accountMemberDto.setAccountPartners(accountRoles);
        Long accountId = 101L;

        when(accountService.getAccountMembers(accountId)).thenReturn(accountMemberDto);

        MvcResult mvcResult = mockMvc.perform(get("/v1/accounts/{accountId}/members", accountId).requestAttr(O_ID, oId)).andReturn();
        ResponseDto responseDto = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), ResponseDto.class);

        assertEquals("Success", responseDto.getStatus());
        verify(accountService, times(1)).getAccountMembers(accountId);
    }
}



