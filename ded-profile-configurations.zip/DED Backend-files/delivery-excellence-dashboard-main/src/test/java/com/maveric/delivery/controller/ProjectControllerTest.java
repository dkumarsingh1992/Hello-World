package com.maveric.delivery.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.delivery.audit.AuditImpl;
import com.maveric.delivery.repository.AuditRepository;
import com.maveric.delivery.repository.DedRolesRepository;
import com.maveric.delivery.requestdto.ProjectRequestDto;
import com.maveric.delivery.requestdto.ProjectsListDto;
import com.maveric.delivery.responsedto.AccountResponseDto;
import com.maveric.delivery.responsedto.ProjectListResponseDto;
import com.maveric.delivery.responsedto.ProjectResponseDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.ProjectService;
import com.maveric.delivery.service.ProjectServiceImpl;
import com.maveric.delivery.service.ProjectServiceImplTest;
import com.maveric.delivery.utils.Constants;
import com.maveric.delivery.utils.SuccessMessage;
import com.maveric.delivery.utils.ValidateApiAccess;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.Collections;
import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.O_ID;
import static com.maveric.delivery.utils.Constants.SUCCESS;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * @author ankushk
 */

@WebMvcTest(ProjectController.class)
@AutoConfigureMockMvc

public class ProjectControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;
    @MockBean
    private ProjectServiceImpl projectService;

    @Mock
    private ProjectService projectService1;

   /* @InjectMocks
    private ProjectController projectController;*/

    @MockBean
    AuditImpl auditImpl;

    @MockBean
    private AuditRepository auditRepository;

    @MockBean
    DedRolesRepository dedRolesRepository;

    @MockBean
    private ValidateApiAccess validateApiAccess;

    private final String oId = UUID.randomUUID().toString();


    @Test
    public void testGetAccountById_AccountFound_Success() throws Exception {

        ProjectResponseDto projectResponseDto = new ProjectResponseDto();
        projectResponseDto.setAccountId(1L);
        when(projectService.getProjectById(1L, UUID.randomUUID() )).thenReturn(projectResponseDto);
        MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get("/v1/projects/1").requestAttr(O_ID, oId)
                .header("userId", UUID.randomUUID())
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();
        String responseBody = result.getResponse().getContentAsString();
        ResponseDto<AccountResponseDto> responseDto = objectMapper.readValue(responseBody, ResponseDto.class);
        assertEquals("S-1011", responseDto.getCode());
        assertEquals("Project Fetched successfully", responseDto.getMessage());
        // assertNotNull(responseDto.getPayload());
    }

    @Test
    public void testSaveProject_Success() throws Exception {
        ProjectRequestDto requestDto = ProjectServiceImplTest.createSampleProjectRequestDto();
        ProjectResponseDto createdProject =new ProjectResponseDto();
        BeanUtils.copyProperties(requestDto,createdProject);
        createdProject.setProjectId(1L);

        when(projectService.saveProject(any(ProjectRequestDto.class))).thenReturn(createdProject);
        MockHttpServletRequestBuilder request = MockMvcRequestBuilders.post("/v1/projects").requestAttr(O_ID, oId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(ProjectServiceImplTest.createSampleProjectRequestDto()));
        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isCreated())
                .andReturn();
        String responseBody = result.getResponse().getContentAsString();
        ResponseDto<ProjectResponseDto> responseDto = objectMapper.readValue(responseBody, ResponseDto.class);
        assertEquals(SUCCESS, responseDto.getStatus());
        assertEquals("S-1009", responseDto.getCode());
        assertEquals("Project created successfully", responseDto.getMessage());
        verify(projectService, times(1)).saveProject(any(ProjectRequestDto.class));
    }



    @Test
    void testGetProjectList() throws Exception {
        // Mocking
        Long accountId = 123L;
        ProjectsListDto projectsListDto=new ProjectsListDto();
        List<ProjectListResponseDto> mockProjectList = Collections.singletonList(new ProjectListResponseDto());
        projectsListDto.setProjectListResponseDtos(mockProjectList);

        when(projectService.getProjectDetailsList(UUID.fromString(oId), accountId)).thenReturn(projectsListDto);

        MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get("/v1/projects").requestAttr(O_ID, oId)
                .header("userId", UUID.randomUUID())
                .param("accountId",accountId.toString())
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();
        String responseBody = result.getResponse().getContentAsString();
        ResponseDto<AccountResponseDto> responseDto = objectMapper.readValue(responseBody, ResponseDto.class);

        assertEquals(Constants.SUCCESS, responseDto.getStatus());
        assertEquals(SuccessMessage.PROJECT_LIST_FETCHED.getCode(), responseDto.getCode());
        assertEquals(SuccessMessage.PROJECT_LIST_FETCHED.getMessage(), responseDto.getMessage());


}
}


