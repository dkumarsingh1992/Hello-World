package com.maveric.delivery.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.delivery.audit.AuditImpl;
import com.maveric.delivery.model.Country;
import com.maveric.delivery.repository.AuditRepository;
import com.maveric.delivery.repository.AzureUserRepository;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.CountryService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

@WebMvcTest(CountryController.class)
@ExtendWith(SpringExtension.class)
class CountryControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private CountryController countryController;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private CountryService countryService;
    @MockBean
    private AuditRepository auditRepository;

    @MockBean
    private AzureUserRepository azureUserRepository;

    @MockBean
    AuditImpl auditImpl;


    @Test
    void testGetAllCountries() throws Exception {
        List<Country> countries = new ArrayList<>();
        countries.add(new Country("India", "IN"));
        countries.add(new Country("Canada", "CAN"));

        when(countryService.getAllCountries()).thenReturn(countries);

        MvcResult mvcResult = mockMvc.perform(get("/v1/countries")).andReturn();
        ResponseDto responseDto = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), ResponseDto.class);

        assertEquals("Success", responseDto.getStatus());
        verify(countryService, times(1)).getAllCountries();
    }

    @Test
    void testGetAllCountriesEmptyList() throws Exception {
        when(countryService.getAllCountries()).thenReturn(Collections.emptyList());

        MvcResult mvcResult = mockMvc.perform(get("/v1/countries")).andReturn();
        ResponseDto responseDto = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), ResponseDto.class);

        assertEquals("Success", responseDto.getStatus());
        assertEquals(Collections.emptyList(), responseDto.getPayload());
    }
}
