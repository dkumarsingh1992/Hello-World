package com.maveric.delivery.service;

import com.maveric.delivery.model.Roles;
import com.maveric.delivery.model.embedded.DedRoles;
import com.maveric.delivery.repository.AzureUserRepository;
import com.maveric.delivery.repository.DedRolesRepository;
import com.maveric.delivery.repository.RolesRepository;
import com.maveric.delivery.requestdto.RolePrivilegesDto;
import com.maveric.delivery.utils.UtilMethods;
import com.microsoft.graph.serviceclient.GraphServiceClient;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class UserServiceImplTest {

    @MockBean
    private DedRolesRepository dedRolesRepository;
    @MockBean
    private AzureUserRepository azureUserRepository;
    @MockBean
    private GraphServiceClient graphServiceClient;
    @MockBean
    private RolesRepository rolesRepository;
    @MockBean
    private RolePrivilegesService rolePrivilegesService;

    @Autowired
    private UserServiceImpl userService;

    @MockBean
    private UtilMethods utilMethods;

    private UUID oId = UUID.randomUUID();

    @Test
    void getPrivileges_success() {

        RolePrivilegesDto rolePrivilegesDto = new RolePrivilegesDto();
        List<DedRoles> dedRolesList = new ArrayList<>();
        DedRoles dedRoles = new DedRoles();
        dedRoles.setOid(oId);
        dedRoles.setRole("DH");
        dedRolesList.add(dedRoles);
        Roles roles = new Roles();
        roles.setName("Super Admin");
        when(dedRolesRepository.findByOid(any(UUID.class))).thenReturn(dedRolesList);
        when(rolesRepository.findByGroupContaining(any(String.class))).thenReturn(roles);
        when( rolePrivilegesService.findByRoleId(any(Long.class))).thenReturn(rolePrivilegesDto);
        assertNotNull(userService.getPrivileges(oId));
    }

    @Test
    void getPrivileges_success_null() {

        when(dedRolesRepository.findByOid(any(UUID.class))).thenReturn(Collections.emptyList());
        when(rolesRepository.findByGroupContaining(any(String.class))).thenReturn(null);
        when( rolePrivilegesService.findByRoleId(any(Long.class))).thenReturn(null);
        assertNotNull(userService.getPrivileges(oId));
    }

    @Test
    void getRolesName_success() {
        RolePrivilegesDto rolePrivilegesDto = new RolePrivilegesDto();
        List<DedRoles> dedRolesList = new ArrayList<>();
        DedRoles dedRoles = new DedRoles();
        dedRoles.setOid(oId);
        dedRoles.setRole("DH");
        dedRolesList.add(dedRoles);
        Roles roles = new Roles();
        roles.setName("Super Admin");
        when(dedRolesRepository.findByOid(any(UUID.class))).thenReturn(dedRolesList);
        when(rolesRepository.findByGroupContaining(any(String.class))).thenReturn(roles);
        when( rolePrivilegesService.findByRoleId(any(Long.class))).thenReturn(rolePrivilegesDto);
        assertNotNull(userService.getRolesName(oId));
    }
}