package com.maveric.delivery.service;

import com.maveric.delivery.model.Privileges;
import com.maveric.delivery.model.RolePrivileges;
import com.maveric.delivery.model.Roles;
import com.maveric.delivery.repository.RolePrivilegesRepository;
import com.maveric.delivery.repository.RolesRepository;
import com.maveric.delivery.requestdto.RolePrivilegesDto;
import com.maveric.delivery.utils.UtilMethods;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class RolePrivilegesServiceImplTest {

    @MockBean
    private RolePrivilegesRepository rolePrivilegesRepository;

    @MockBean
    private RolesRepository rolesRepository;

    @Autowired
    private RolePrivilegesService rolePrivilegesService;

    @MockBean
    private UtilMethods utilMethods;

    Long roleId = Long.valueOf(1);

    @Test
    void save_success() {
        List<RolePrivilegesDto> rolePrivilegesDtos = new ArrayList<>();
        RolePrivileges privileges = new RolePrivileges();
        when(rolePrivilegesRepository.findByRoleId(null)).thenReturn(Optional.of(privileges));
        when(rolePrivilegesRepository.save(privileges)).thenReturn(privileges);
        rolePrivilegesDtos =  rolePrivilegesService.save(rolePrivilegesDtos);
        assertNotNull(rolePrivilegesDtos);
    }

    @Test
    void update_success() {
        List<RolePrivilegesDto> rolePrivilegesDtos = new ArrayList<>();
        RolePrivileges privileges = new RolePrivileges();
        privileges.setId(roleId);
        when(rolePrivilegesRepository.findByRoleId(roleId)).thenReturn(Optional.of(privileges));
        when(rolePrivilegesRepository.save(privileges)).thenReturn(privileges);
        rolePrivilegesDtos =  rolePrivilegesService.save(rolePrivilegesDtos);
        assertNotNull(rolePrivilegesDtos);
    }

    @Test
    void findAll_success() {
        List<RolePrivileges> privileges = Collections.singletonList(mock(RolePrivileges.class));
        when(rolePrivilegesRepository.findAll()).thenReturn(privileges);
        assertNotNull(rolePrivilegesService.findAll());
    }

    @Test
    void findByRoleId_success() {
        RolePrivileges privileges = new RolePrivileges();
        when(rolePrivilegesRepository.findByRoleId(roleId)).thenReturn(Optional.of(privileges));
        assertNotNull(rolePrivilegesService.findByRoleId(roleId));
    }

    @Test
    void findByRoleId_success_null() {
        RolePrivileges privileges = mock(RolePrivileges.class);
        when(rolePrivilegesRepository.findByRoleId(roleId)).thenReturn(Optional.ofNullable(privileges));
        assertNotNull(rolePrivilegesService.findByRoleId(roleId));
    }

    @Test
    void findByName_success() {
        List<String> module =  Collections.singletonList("Accounts");
        String name = "Account Admin";
        Roles roles = mock(Roles.class);
        RolePrivileges rolePrivileges = new RolePrivileges();
        List<Privileges> privilegesList = new ArrayList<>();
        Privileges privileges = new Privileges();
        privileges.setName("Accounts");
        privileges.setPrivileges(Collections.singletonList("Add"));
        privilegesList.add(privileges);
        rolePrivileges.setPrivileges(privilegesList);
        when(rolesRepository.findByName(any(String.class))).thenReturn(roles);
        when(rolePrivilegesRepository.findByRoleId(any(Long.class))).thenReturn(Optional.of(rolePrivileges));
        assertNotNull(rolePrivilegesService.findByName(module,name));
    }

    @Test
    void findByName_success_null() {
        List<String> module =  Collections.singletonList("Accounts");
        String name = "Account Admin";
        Roles roles = mock(Roles.class);
        RolePrivileges rolePrivileges = new RolePrivileges();
        when(rolesRepository.findByName(any(String.class))).thenReturn(roles);
        when(rolePrivilegesRepository.findByRoleId(any(Long.class))).thenReturn(Optional.of(rolePrivileges));
        assertNotNull(rolePrivilegesService.findByName(module,name));
    }

    @Test
    void testfindByName_success() {

        String name = "Account Admin";
        Roles roles = mock(Roles.class);
        RolePrivileges rolePrivileges = new RolePrivileges();
        List<Privileges> privilegesList = new ArrayList<>();
        Privileges privileges = new Privileges();
        privileges.setName("Accounts");
        privileges.setPrivileges(Collections.singletonList("Add"));
        privilegesList.add(privileges);
        rolePrivileges.setPrivileges(privilegesList);
        when(rolesRepository.findByName(any(String.class))).thenReturn(roles);
        when(rolePrivilegesRepository.findByRoleId(any(Long.class))).thenReturn(Optional.of(rolePrivileges));
        assertNotNull(rolePrivilegesService.findByName(name));
    }

    @Test
    void testfindByName_success_null() {

        String name = "Account Admin";
        Roles roles = mock(Roles.class);
        RolePrivileges rolePrivileges = new RolePrivileges();
        when(rolesRepository.findByName(any(String.class))).thenReturn(roles);
        when(rolePrivilegesRepository.findByRoleId(any(Long.class))).thenReturn(Optional.of(rolePrivileges));
        assertNotNull(rolePrivilegesService.findByName(name));
    }
}