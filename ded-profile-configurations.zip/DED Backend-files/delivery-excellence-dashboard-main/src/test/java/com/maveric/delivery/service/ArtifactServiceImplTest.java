package com.maveric.delivery.service;

import com.maveric.delivery.model.Artifact;
import com.maveric.delivery.model.Attachment;
import com.maveric.delivery.model.AzureUsers;
import com.maveric.delivery.repository.ArtifactRepository;
import com.maveric.delivery.repository.AzureUserRepository;
import com.maveric.delivery.requestdto.ArtifactDto;
import com.maveric.delivery.requestdto.UserDto;
import com.maveric.delivery.responsedto.ArtifactListDto;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class ArtifactServiceImplTest {

    @Mock
    private ArtifactRepository artifactRepository;

    @Mock
    private AzureUserRepository azureUserRepository;

    @InjectMocks
    private ArtifactServiceImpl artifactService;
    @Mock
    private UserServiceImpl userService;

    public ArtifactServiceImplTest() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllArtifacts() {
        UUID userId = UUID.fromString("45c94afc-dd88-4576-953a-0a2b8c577b52");
        Long projectId = 123L;


        Artifact dto=new Artifact();
        Attachment attachment=new Attachment();
        attachment.setLink("ArtifactLink");
        attachment.setName("ArtifactName");
        dto.setName("artifactName");
        dto.setType("artifactType");
        dto.setAttachment(attachment);
        dto.setLink("artifactLink");
        dto.setComments("artifactComments");
        dto.setCreatedAt(3456789L);
        dto.setCreatorName("CreatorName");
        dto.setCreatedBy(userId);

        List<Artifact> list=new ArrayList<>();
        list.add(dto);

        AzureUsers azureUser = new AzureUsers();
        azureUser.setId(userId);
        azureUser.setDisplayName("i am here");

        when(artifactRepository.findByProjectId(projectId)).thenReturn(list);
        when(azureUserRepository.findById(userId)).thenReturn(Optional.of(azureUser));


        List<ArtifactListDto> result = artifactService.getAllArtifacts(userId, projectId);
        assertEquals(1, result.size());
        verify(artifactRepository, times(1)).findByProjectId(projectId);
    }

    @Test
    public void testGetAllArtifactsWithNonEmptyList() {
        UUID userId = UUID.randomUUID();
        Long projectId = 123L;
        AzureUsers azureUser = new AzureUsers();
        azureUser.setId(userId);
        azureUser.setDisplayName("i am here");
        when(artifactRepository.findByProjectId(projectId)).thenReturn(new ArrayList<>());
        when(azureUserRepository.findById(userId)).thenReturn(Optional.of(azureUser));
        List<ArtifactListDto> result = artifactService.getAllArtifacts(userId, projectId);
        assertEquals(0, result.size());
        verify(artifactRepository, times(1)).findByProjectId(projectId);
    }


//    @Test
//    public void testDeleteArtifact() {
//        UUID userId = UUID.randomUUID();
//        Long artifactId = 123L;
//        AzureUsers azureUser = new AzureUsers();
//        azureUser.setId(userId);
//        azureUser.setDisplayName("i am here");
//
//        Artifact dto=new Artifact();
//        Attachment attachment=new Attachment();
//        attachment.setLink("ArtifactLink");
//        attachment.setName("ArtifactName");
//        dto.setName("artifactName");
//        dto.setId(artifactId);
//        dto.setType("artifactType");
//        dto.setAttachment(attachment);
//        dto.setLink("artifactLink");
//        dto.setComments("artifactComments");
//        dto.setCreatedAt(3456789L);
//        dto.setCreatedBy(userId);
//        dto.setCreatorName("artifactUploadedBy");
//        List<Artifact> artifactList = new ArrayList<>();
//        artifactList.add(dto);
//
//        when(artifactRepository.findByIdAndUploadedById(artifactId,userId)).thenReturn(artifactList);
//        when(azureUserRepository.findById(userId)).thenReturn(Optional.of(azureUser));
//        artifactService.deleteArtifact(userId, artifactId);
//        verify(artifactRepository, times(1)).deleteById(artifactId);
//        verify(artifactRepository, times(1)).findByIdAndUploadedById(artifactId, userId);
//
//    }
//
//
//    @Test
//    void testSaveArtifact_ValidInput_Success() {
//
//        UUID oid = UUID.fromString("45c94afc-dd88-4576-953a-0a2b8c577b52");
//        ArtifactDto artifactDto = new ArtifactDto();
//        artifactDto.setAttachment("attachment");
//
//        List<UserDto> userDtoList = new ArrayList<>();
//        UserDto userDto = new UserDto();
//        userDto.setOid(oid);
//        userDto.setName("testUser");
//        userDtoList.add(userDto);
//        when(userService.getAllUsers()).thenReturn(userDtoList);
//
//        when(azureUserRepository.findById(oid)).thenReturn(Optional.of(new AzureUsers(oid,"abc","pqr","abc@com","str","qrs","sop","mnp","HH")));
//        Artifact savedArtifact = new Artifact();
//        when(artifactRepository.save(any())).thenReturn(savedArtifact);
//        when(userService.getAllUsers()).thenReturn(userDtoList);
//
//        ArtifactDto result = artifactService.saveArtifact(artifactDto, oid);
//
//        assertNotNull(result);
//
//    }
//
//
//
//
//    @Test
//    void testIsValidInput() {
//
//        ArtifactDto artifactDto = new ArtifactDto();
//        artifactDto.setAttachment("attachment");
//
//        boolean result = artifactService.isValidInput(artifactDto);
//
//        assertTrue(result);
//
//    }
//
//
//
//    @Test
//    void testGetUserName() {
//
//        UUID oid = UUID.fromString("45c94afc-dd88-4576-953a-0a2b8c577b52");
//        List<UserDto> userDtoList = new ArrayList<>();
//        UserDto userDto = new UserDto();
//        userDto.setOid(oid);
//        userDto.setName("testUser");
//        userDtoList.add(userDto);
//        when(userService.getAllUsers()).thenReturn(userDtoList);
//
//        String result = artifactService.getUserName(oid);
//
//        Assertions.assertNotNull(result);
//
//    }
//
//    @Test
//    void testGetDisplayName() {
//
//        UUID oid = UUID.randomUUID();
//        when(azureUserRepository.findById(oid)).thenReturn(Optional.of(new AzureUsers(oid,"abc","pqr","abc@com","str","qrs","sop","mnp","HH")));
//
//        String result = artifactService.getDisplayName(oid);
//
//
//        assertNotNull(result);
//
//    }
//
//    @Test
//    void testCheckUserAuthenticity() {
//
//        UUID oid = UUID.randomUUID();
//        when(azureUserRepository.findById(oid)).thenReturn(Optional.of(new AzureUsers(oid,"abc","pqr","abc@com","str","qrs","sop","mnp","HH")));
//
//        assertDoesNotThrow(() -> artifactService.checkUserAuthenticity(oid));
//    }
}
