package com.maveric.delivery.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.delivery.audit.AuditImpl;
import com.maveric.delivery.requestdto.RolesDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.RolesService;
import com.maveric.delivery.utils.ValidateApiAccess;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.O_ID;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(RolesController.class)
@AutoConfigureMockMvc
class RolesControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;


    @MockBean
    private RolesService rolesService;

    @MockBean
    private ValidateApiAccess validateApiAccess;

    @MockBean
    AuditImpl auditImpl;


    private final String oId = UUID.randomUUID().toString();



    @Test
    void getRoles_Success() throws Exception {


        List<RolesDto> rolesDtos = new ArrayList<>();
        when(rolesService.getRoles()).thenReturn(rolesDtos);

        MockHttpServletRequestBuilder requestBuilder = get("/v1/roles").requestAttr(O_ID, oId)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder)
                .andExpect(status().isOk())
                .andReturn();


        ResponseDto<List<RolesDto>> responseDto = objectMapper.readValue(
                result.getResponse().getContentAsString(),
                new TypeReference<ResponseDto<List<RolesDto>>>() {
                });
        assertEquals("Success", responseDto.getStatus());
        assertEquals("S-1022", responseDto.getCode());
        assertEquals("Roles fetched successfully", responseDto.getMessage());
        assertEquals(rolesDtos, responseDto.getPayload());
    }

    @Test
    void findByRoleId() throws Exception {
        RolesDto rolesDto = new RolesDto();
        when(rolesService.getRole(any(Long.class))).thenReturn(rolesDto);

        MockHttpServletRequestBuilder requestBuilder = get("/v1/roles/1").requestAttr(O_ID, oId)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder)
                .andExpect(status().isOk())
                .andReturn();


        ResponseDto<RolesDto> responseDto = objectMapper.readValue(
                result.getResponse().getContentAsString(),
                new TypeReference<ResponseDto<RolesDto>>() {
                });
        assertEquals("Success", responseDto.getStatus());
        assertEquals("S-1022", responseDto.getCode());
        assertEquals("Roles fetched successfully", responseDto.getMessage());
        assertEquals(rolesDto, responseDto.getPayload());
    }
}