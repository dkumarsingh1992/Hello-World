package com.maveric.delivery.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.delivery.requestdto.ArtifactDto;
import com.maveric.delivery.responsedto.ArtifactListDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.ArtifactService;
import com.maveric.delivery.utils.Constants;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import javax.naming.directory.InvalidAttributesException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


class ArtifactControllerTest {

    private MockMvc mockMvc;

    @Mock
    private ArtifactService artifactService;

    @InjectMocks
    private ArtifactController artifactController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(artifactController).build();
    }


    @Test
    void testFetchAllArtifacts() throws Exception {
        UUID userId = UUID.randomUUID();
        Long projectId = 123L;
        List<ArtifactListDto> artifacts = new ArrayList<>();
        when(artifactService.getAllArtifacts(userId, projectId)).thenReturn(artifacts);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/v1/artifacts")
                        .param("projectId", String.valueOf(projectId))
                        .requestAttr("oid", userId.toString())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        ObjectMapper objectMapper = new ObjectMapper();
        ResponseDto responseDto = objectMapper.readValue(content, ResponseDto.class);
        assertEquals("Success", responseDto.getStatus());
        verify(artifactService, times(1)).getAllArtifacts(userId, projectId);
    }


//    @Test
//    void testDeleteArtifact() throws Exception {
//        UUID userId = UUID.randomUUID();
//        Long artifactId = 123L;
//        List<ArtifactListDto> artifacts = new ArrayList<>();
//        when(artifactService.getAllArtifacts(userId, artifactId)).thenReturn(artifacts);
//        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.delete("/v1/artifacts")
//                        .header("userId", userId.toString())
//                        .param("artifactId", artifactId.toString())
//                        .contentType(MediaType.APPLICATION_JSON))
//                .andReturn();
//
//        String content = result.getResponse().getContentAsString();
//        ObjectMapper objectMapper=new ObjectMapper();
//        ResponseDto responseDto = objectMapper.readValue(content, ResponseDto.class);
//        Assert.assertEquals("Success", responseDto.getStatus());
//        verify(artifactService, times(1)).deleteArtifact(userId, artifactId);
//    }

   /* @Test
    public void testSaveArtifact_Success() throws InvalidAttributesException {

        ArtifactDto artifactDto = new ArtifactDto();
        UUID oid = UUID.randomUUID();


        when(artifactService.saveArtifact(any(ArtifactDto.class), any(UUID.class)))
                .thenReturn(artifactDto);


        ResponseEntity<ResponseDto> response = artifactController.saveArtifact(artifactDto, oid);


        verify(artifactService).saveArtifact(artifactDto, oid);

        assertNotNull(response);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(Constants.SUCCESS, response.getBody().getStatus());

    }*/

}
