package com.maveric.delivery.service;

import com.maveric.delivery.model.AssessmentTemplate;
import com.maveric.delivery.repository.AssessmentTemplateRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import java.util.ArrayList;
import java.util.List;
import static org.mockito.Mockito.when;

public class AssessmentTemplateServiceTest {

    private MockMvc mockMvc;

    @Mock
    private AssessmentTemplateRepository assessmentTemplateRepository;

    @InjectMocks
    private AssessmentTemplateServiceImpl assessmentTemplateService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFetchAllTemplates_Success() throws Exception {
        List<AssessmentTemplate> assessmentTemplates = new ArrayList<>();
        assessmentTemplates.add(new AssessmentTemplate(1L, "Template1"));
        when(assessmentTemplateRepository.findAll()).thenReturn(assessmentTemplates);
        List<AssessmentTemplate> result = assessmentTemplateService.getAllTemplates("delivery");
        Assertions.assertEquals(assessmentTemplates.size(), result.size());
    }
}
