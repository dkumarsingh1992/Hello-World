package com.maveric.delivery.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.delivery.model.AssessmentTemplate;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.AssessmentTemplateService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;


import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class AssessmentTemplateControllerTest {

    private MockMvc mockMvc;

    @Mock
    private AssessmentTemplateService assessmentTemplateService;

    @InjectMocks
    private AssessmentTemplateController assessmentTemplateController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(assessmentTemplateController).build();
    }

    @Test
    public void testFetchAllTemplates_Success() throws Exception {
        List<AssessmentTemplate> assessmentTemplates = new ArrayList<>();
        assessmentTemplates.add(new AssessmentTemplate(1L, "Template1"));
        when(assessmentTemplateService.getAllTemplates("delivery")).thenReturn(assessmentTemplates);
        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/v1/assessments/templates?type=delivery")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andReturn();
        String content = result.getResponse().getContentAsString();
        ObjectMapper objectMapper = new ObjectMapper();
        ResponseDto responseDto = objectMapper.readValue(content, ResponseDto.class);
        assertEquals("Success", responseDto.getStatus());
    }

    @Test
    public void testFetchAllTemplates_Failed() throws Exception {
        List<AssessmentTemplate> assessmentTemplates = new ArrayList<>();
        when(assessmentTemplateService.getAllTemplates("delivery")).thenReturn(assessmentTemplates);
        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/v1/assessments/templates?type=delivery")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andReturn();
        String content = result.getResponse().getContentAsString();
        ObjectMapper objectMapper = new ObjectMapper();
        ResponseDto responseDto = objectMapper.readValue(content, ResponseDto.class);
        assertEquals("Failed", responseDto.getStatus());
    }
}

