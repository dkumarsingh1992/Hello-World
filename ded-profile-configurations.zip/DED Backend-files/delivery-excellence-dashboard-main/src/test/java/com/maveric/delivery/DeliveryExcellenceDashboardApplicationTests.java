package com.maveric.delivery;

import com.maveric.delivery.utils.UtilMethods;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

@SpringBootTest
class DeliveryExcellenceDashboardApplicationTests {

	@MockBean
	private UtilMethods utilMethods;
	@Test
	void contextLoads() {
	}

}
