package com.maveric.delivery.repository;

import com.maveric.delivery.model.EngagementType;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface EngagementTypeRepository extends MongoRepository<EngagementType,Long> {
}
