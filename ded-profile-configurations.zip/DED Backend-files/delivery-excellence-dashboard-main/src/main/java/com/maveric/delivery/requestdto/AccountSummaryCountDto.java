package com.maveric.delivery.requestdto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author ankushk
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountSummaryCountDto {

    private long accounts;
    private long projects;
    private long teamMembers;
    private long artifacts;
    private long assessmentCompleted;
    private List<String> privileges;
}
