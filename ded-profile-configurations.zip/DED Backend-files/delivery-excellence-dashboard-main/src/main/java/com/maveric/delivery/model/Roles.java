package com.maveric.delivery.model;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@Document(collection = "roles")
public class Roles extends IdentifiedEntity{
    private String name;
    private List<String> group;
    private int hierarchy;
}
