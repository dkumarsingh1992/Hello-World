package com.maveric.delivery.controller;

import com.maveric.delivery.model.Account;
import com.maveric.delivery.requestdto.AccountRequestDto;
import com.maveric.delivery.requestdto.AccountSummaryCountDto;
import com.maveric.delivery.requestdto.AccountSummaryDto;
import com.maveric.delivery.requestdto.DedRolesDto;
import com.maveric.delivery.responsedto.AccountMemberDto;
import com.maveric.delivery.responsedto.AccountNamesResponseDto;
import com.maveric.delivery.responsedto.AccountResponseDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.AccountServiceImpl;
import com.maveric.delivery.utils.Constants;
import com.maveric.delivery.utils.FailedMessage;
import com.maveric.delivery.utils.SuccessMessage;
import com.maveric.delivery.utils.ValidateApiAccess;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.*;


@RestController
@RequestMapping("/v1")
@Slf4j
@RequiredArgsConstructor
public class AccountController {

    private final AccountServiceImpl accountServiceImpl;
    private final ValidateApiAccess validateApiAccess;

    private static final Logger logger = LoggerFactory.getLogger(AccountController.class);

    @Operation(summary = "Save Account")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Account created successfully",
                    content = @Content(schema = @Schema(implementation = Account.class))),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(path = "/accounts")
    public ResponseEntity<ResponseDto> saveAccount(HttpServletRequest servletRequest, @Valid @RequestBody AccountRequestDto accountRequestDto) {
        logger.info("AccountController::Saving account: {}", accountRequestDto);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, ACCOUNTS, CREATE);
        AccountResponseDto createdAccount = accountServiceImpl.createAccount(accountRequestDto);
        logger.info("Account created successfully");
        return ResponseEntity.status(HttpStatus.CREATED).body(new ResponseDto(SUCCESS, SuccessMessage.ACCOUNT_CREATED.getCode(), SuccessMessage.ACCOUNT_CREATED.getMessage(), null, createdAccount));
    }

    @Operation(summary = "Get All Accounts")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", content = @Content(schema = @Schema(implementation = AccountRequestDto.class))),
            @ApiResponse(responseCode = "404", description = "Not found")})
    @GetMapping(path = "/accounts/userId/{userId}")
    public ResponseEntity<ResponseDto> getAllAccountsByuserId(HttpServletRequest servletRequest, @PathVariable UUID userId) throws Exception {
        logger.info("AccountController::Fetching all accounts by userId: {}", userId);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, ACCOUNTS, VIEW_ALL,VIEW_ASSOCIATED);
        List<AccountSummaryDto> accounts = accountServiceImpl.getAllAccountsByUserId(rolesDto.getOid());
        logger.info("Accounts retrieved successfully");
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto(SUCCESS, SuccessMessage.FETCH_ACCOUNTS.getCode(), SuccessMessage.FETCH_ACCOUNTS.getMessage(), null, accounts));
    }

    @Operation(summary = "Get All Accounts counts")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", content = @Content(schema = @Schema(implementation = AccountRequestDto.class))),
            @ApiResponse(responseCode = "404", description = "Not found")})
    @GetMapping(path = "/accounts/summaryCount/userId/{userId}")
    public ResponseEntity<ResponseDto> getSummaryCounts(HttpServletRequest servletRequest, @PathVariable UUID userId) throws Exception {
        logger.info("AccountController::Fetching summary counts for userId: {}", userId);
        String userId1 = (String) servletRequest.getAttribute("oid");
        AccountSummaryCountDto accounts = accountServiceImpl.getCountOfAccountByuserId(UUID.fromString(userId1));
        logger.info("Summary counts retrieved successfully");
        return ResponseEntity.status(HttpStatus.OK)
                .body(new ResponseDto(SUCCESS, SuccessMessage.FETCH_ACCOUNTS_COUNT.getCode(), SuccessMessage.FETCH_ACCOUNTS_COUNT.getMessage(), null, accounts));
    }

    @Operation(summary = "Get By Account Id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Account found by ID",
                    content = @Content(schema = @Schema(implementation = Account.class))),
            @ApiResponse(responseCode = "404", description = "Account not found for the given ID")
    })
    @GetMapping(path = "/accounts/{accountId}")
    public ResponseEntity<ResponseDto> getAccountById(HttpServletRequest servletRequest, @RequestHeader("userId") UUID userId, @PathVariable Long accountId) {
        logger.info("AccountController::Fetching account by ID: {}", accountId);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).accountId(accountId).build();
        validateApiAccess.isAccessible(rolesDto, ACCOUNTS, VIEW_ASSOCIATED);
        AccountResponseDto accountOptional = accountServiceImpl.getAccountById(accountId, rolesDto.getOid());
        logger.info("Account retrieved successfully");
        return ResponseEntity.status(HttpStatus.OK)
                .body(new ResponseDto(SUCCESS, SuccessMessage.FETCH_ACCOUNT.getCode(), SuccessMessage.FETCH_ACCOUNT.getMessage(), null, accountOptional));

    }

    @Operation(summary = "Edit Account")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Account edited successfully",
                    content = @Content(schema = @Schema(implementation = Account.class))),
            @ApiResponse(responseCode = "404", description = "Account not found for the given ID"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PutMapping(path = "/accounts/{accountId}")
    public ResponseEntity<ResponseDto> editAccount(HttpServletRequest servletRequest, @RequestBody AccountRequestDto accountRequestDto, @PathVariable Long accountId) {
        logger.info("AccountController::Editing account with ID: {}, {}", accountId, accountRequestDto);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).accountId(accountId).build();
        validateApiAccess.isAccessible(rolesDto, ACCOUNTS, EDIT);
        AccountResponseDto editedAccount = accountServiceImpl.editAccount(accountRequestDto, accountId);
        logger.info("Account edited successfully");
        return ResponseEntity.status(HttpStatus.OK)
                .body(new ResponseDto(SUCCESS, SuccessMessage.UPDATE_ACCOUNT_DETAILS.getCode(), SuccessMessage.UPDATE_ACCOUNT_DETAILS.getMessage(), null, editedAccount));
    }

    @Operation(summary = "Duplicate Account Name")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Check if account name is duplicate",
                    content = @Content(schema = @Schema(implementation = Boolean.class))),
            @ApiResponse(responseCode = "409", description = "Duplicate account name"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/accounts/duplicate/{accountName}")
    public ResponseEntity<ResponseDto> duplicateAccountName(HttpServletRequest servletRequest, @PathVariable String accountName) {
        logger.info("AccountController::Checking duplicate account name: {}", accountName);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, ACCOUNTS, CREATE,EDIT);
        boolean isDuplicate = accountServiceImpl.duplicateAccountName(accountName);
        if (isDuplicate) {
            logger.warn("Duplicate account name found: {}", accountName);
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto("Successfully", FailedMessage.EXISTS_ACCOUNT.getCode(), FailedMessage.EXISTS_ACCOUNT.getMessage().concat(accountName), null, null));
        } else {
            logger.info("Account name is not a duplicate: {}", accountName);
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new ResponseDto("Successfully", SuccessMessage.AVAILABLE_ACCOUNT.getCode(), SuccessMessage.AVAILABLE_ACCOUNT.getMessage().concat(accountName), null, null));
        }
    }

    @Operation(summary = "Get Account Members By Account Id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Account Members found by AccountID",
                    content = @Content(schema = @Schema(implementation = Account.class))),
            @ApiResponse(responseCode = "404", description = "Account Members Not found for given AccountID ")
    })
    @GetMapping(path = "/accounts/{accountId}/members")
    public ResponseEntity<ResponseDto> getAccountMembers(HttpServletRequest servletRequest, @PathVariable Long accountId) {
        log.info("AccountController::getAccountMembers() ::start");
        AccountMemberDto accountMemberDto = accountServiceImpl.getAccountMembers(accountId);
        log.info("AccountController::getAccountMembers() ::End");
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto(SUCCESS, SuccessMessage.FETCH_ACCOUNT_MEMBERS.getCode(), SuccessMessage.FETCH_ACCOUNT_MEMBERS.getMessage() + accountId, null, accountMemberDto));

    }

    @Operation(summary = "Get All AccountName as per userId")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", content = @Content(schema = @Schema(implementation = AccountRequestDto.class))),
            @ApiResponse(responseCode = "404", description = "Not found")})
    @GetMapping(path = "/accounts/names")
    public ResponseEntity<ResponseDto> getAccountsListByuserId(HttpServletRequest servletRequest, @RequestHeader UUID userId) throws Exception {
        logger.info("AccountController::Fetching all accounts by userId: {}", userId);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, ACCOUNTS, CREATE,EDIT);
        AccountNamesResponseDto accountsNames = accountServiceImpl.getAccountsList(rolesDto.getOid());
        logger.info("Accounts retrieved successfully");
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto(Constants.SUCCESS, SuccessMessage.FETCH_ACCOUNTS.getCode(), SuccessMessage.FETCH_ACCOUNTS.getMessage(), null, accountsNames));

    }

}


