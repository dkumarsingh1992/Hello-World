package com.maveric.delivery.audit;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import java.util.UUID;

import static com.maveric.delivery.utils.Constants.O_ID;

@Slf4j
@RequiredArgsConstructor
@Component
public class AuditInterceptor implements HandlerInterceptor {
    private final AuditImpl auditImpl;

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        Audit audit = new Audit();
        if (handler instanceof HandlerMethod handlerMethod) {
            audit.setMethodName(handlerMethod.getMethod().getName());
        }
        audit.setAuditEntity(request.getRequestURI().split("/")[2]);
        audit.setRequestUrl(String.valueOf(request.getRequestURL()));
        UUID userId = request.getAttribute(O_ID) != null ? UUID.fromString((String) request.getAttribute(O_ID)) :null;
        audit.setOid(userId);
        audit.setAction(request.getMethod().concat(" ").concat(request.getRequestURI()));
        audit.setStatus(String.valueOf(response.getStatus()));

        auditImpl.log(audit);
    }


}
