package com.maveric.delivery.responsedto;

import com.maveric.delivery.requestdto.AttachmentDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ArtifactListDto {
    private Long id;
    private String name;
    private String type;
    private AttachmentDto attachment;//name
    private String link;
    private String comments;
    private Long createdAt;
    private UUID createdBy;
    private String creatorName;
    private Boolean isDelete;

}
