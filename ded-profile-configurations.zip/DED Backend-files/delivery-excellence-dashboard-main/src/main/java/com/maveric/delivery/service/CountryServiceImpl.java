package com.maveric.delivery.service;

import com.maveric.delivery.model.Country;
import com.maveric.delivery.repository.CountryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
@Slf4j
@RequiredArgsConstructor
public class CountryServiceImpl implements CountryService{

    private final CountryRepository countryRepository;
    @Override
    public List<Country> getAllCountries() {
        log.debug("CountryServiceImpl::getAllCountries() call started");
        List<Country> countries = countryRepository.findAll();
        log.debug("CountryServiceImpl::getAllCountries() data::{}", countries.size());
        log.debug("CountryServiceImpl::getAllCountries() call end");
        return countries;
    }
}
