package com.maveric.delivery.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document(value="projectStatus")
public class ProjectStatus extends IdentifiedEntity{
    private String name;

    public ProjectStatus(long l, String name) {
        super();
    }
}
