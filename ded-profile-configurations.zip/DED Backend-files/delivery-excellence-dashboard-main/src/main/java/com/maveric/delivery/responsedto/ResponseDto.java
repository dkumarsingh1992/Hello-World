package com.maveric.delivery.responsedto;

import com.maveric.delivery.model.embedded.ErrorMessage;
import com.maveric.delivery.requestdto.RolePrivilegesDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

import java.io.Serializable;
import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseDto <T> implements Serializable {
    private static final long serialVersionUID = 1L;
    private String status;
    private String code;
    private String message;
    private List<ErrorMessage> errorMessage;
    private T payload = null;


}

