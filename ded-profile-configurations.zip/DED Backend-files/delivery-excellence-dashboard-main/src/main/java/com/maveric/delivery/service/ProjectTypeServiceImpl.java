package com.maveric.delivery.service;

import com.maveric.delivery.model.ProjectType;
import com.maveric.delivery.repository.ProjectTypeRepository;
import com.maveric.delivery.responsedto.BaseDto;
import com.maveric.delivery.responsedto.ProjectTypeDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class ProjectTypeServiceImpl implements ProjectTypeService {


    private final ProjectTypeRepository projectTypeRepository;
    @Override
    public ProjectType saveProjectType(ProjectTypeDto requestPayload) {
        log.debug("ProjectTypeService::saveProjectType()::started");
        ProjectType project = new ProjectType();
        project.setName(requestPayload.getName());
        project.setDescription(requestPayload.getDescription());
        return projectTypeRepository.save(project);

    }

    @Override
    public List<BaseDto> fetchAllProjectType() {
        log.debug("ProjectTypeService::FetchAllProjectType()::started");
        List<ProjectType> projectTypeList=projectTypeRepository.findAll();
        log.debug("ProjectTypeService::FetchAllProjectType()::started");
        return toProjectType(projectTypeList);
    }
    public BaseDto toBaseDto(ProjectType projectType){
        BaseDto baseDto=new BaseDto();
        baseDto.setId(projectType.getId());
        baseDto.setName(projectType.getName());
        return baseDto;
    }

    public List<BaseDto> toProjectType(List<ProjectType> projectTypeList) {
       return projectTypeList.stream()
                .map(this::toBaseDto)
                .toList();
    }
}
