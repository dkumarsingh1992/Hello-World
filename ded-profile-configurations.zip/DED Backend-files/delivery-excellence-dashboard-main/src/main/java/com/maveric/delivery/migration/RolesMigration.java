package com.maveric.delivery.migration;

import com.maveric.delivery.model.Roles;
import com.maveric.delivery.model.embedded.DedRoles;
import com.maveric.delivery.utils.JsonFileReader;
import io.mongock.api.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

@ChangeUnit(id = "Roles", order = "001", author = "delivery-excellence", systemVersion = "1")
@Slf4j
public class RolesMigration implements Migration {

    private final MongoTemplate mongoTemplate;

    private final JsonFileReader jsonFileReader;
    public RolesMigration(MongoTemplate mongoTemplate, JsonFileReader jsonFileReader) {
        this.mongoTemplate = mongoTemplate;
        this.jsonFileReader = jsonFileReader;
    }

    private final String filePath = "/migration/data/roles.json";


    @BeforeExecution
    @Override
    public void before() {
        log.info("Roles Migration BeforeExecution");
    }

    //Note this method / annotation is Optional
    @RollbackBeforeExecution
    @Override
    public void rollbackBefore() {
        log.info("Roles Migration RollbackBeforeExecution");
    }

    @Execution
    @Override
    public void migrationMethod() throws IOException {
        log.info("mongock migrationMethod");
        List<Roles> roles= jsonFileReader.readJsonFileToList(filePath, Roles.class);
            mongoTemplate.insertAll(roles);
    }

    @RollbackExecution
    @Override
    public void rollback() {
        log.info("Roles Migration RollbackBeforeExecution");
    }
}
