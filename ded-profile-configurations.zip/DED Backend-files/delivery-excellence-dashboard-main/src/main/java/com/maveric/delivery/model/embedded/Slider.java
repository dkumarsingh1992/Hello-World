package com.maveric.delivery.model.embedded;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Slider {

    private Integer min;
    private Integer max;
    private Integer increment;
    @NotNull(message = "value is required")
    private Double value;
    private List<Range> range;
}
