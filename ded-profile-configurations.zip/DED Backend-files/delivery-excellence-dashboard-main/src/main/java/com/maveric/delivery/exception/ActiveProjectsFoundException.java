package com.maveric.delivery.exception;

public class ActiveProjectsFoundException extends RuntimeException {

    public ActiveProjectsFoundException(String message) {
        super(message);
    }
}
