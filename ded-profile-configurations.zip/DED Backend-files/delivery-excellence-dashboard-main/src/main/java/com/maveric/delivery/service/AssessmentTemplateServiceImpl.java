package com.maveric.delivery.service;

import com.maveric.delivery.model.AssessmentTemplate;
import com.maveric.delivery.repository.AssessmentTemplateRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class AssessmentTemplateServiceImpl implements AssessmentTemplateService {
    private final AssessmentTemplateRepository assessmentTemplateRepository;
    @Override
    public List<AssessmentTemplate> getAllTemplates(String type) {
        log.info("AssessmentTemplateServiceImpl::getAllTemplates::started");
        List<AssessmentTemplate> templates=assessmentTemplateRepository.findAll();
        log.info("AssessmentTemplateServiceImpl::getAllTemplates::end");
        return templates;
    }
}
