package com.maveric.delivery.repository;

import com.maveric.delivery.model.Roles;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface RolesRepository extends MongoRepository<Roles,Long> {

   // @Cacheable(value = "findByGroupContaining", key = "#group")
    Roles findByGroupContaining(String group);

    List<Roles> findByGroupIn(List<String> groups);

    @Cacheable(value = "findByName", key = "#name")
    Roles findByName(String name);
}
