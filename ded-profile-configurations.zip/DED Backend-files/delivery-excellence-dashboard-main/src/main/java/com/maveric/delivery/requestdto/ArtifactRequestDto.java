package com.maveric.delivery.requestdto;


import jakarta.validation.constraints.NotBlank;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@Data
@AllArgsConstructor
@NoArgsConstructor
public class ArtifactRequestDto {
    @NotBlank(message = "Artifact name is required")
    @Size(min=3,max = 50, message = "Minimum of 3 and maximum of 50 char are allowed")
    @Pattern(regexp = "^[a-zA-Z0-9,\\.\\&\\- ]+$", message = "Name can only contain alphabets, numbers, comma, dot, & and hyphen")
    private String name;
    @NotBlank(message = "Artifact name is required")
    private String type;
    @Size(min=3,max = 500, message = "Minimum of 3 and maximum of 500 char are allowed")
    private String link;

    @Size(min=3, max = 100, message = "Minimum of 3 and maximum of 100 char are allowed")
    @Pattern(regexp = "^[a-zA-Z0-9,\\.\\&\\(\\)\\- ]+$", message = "Comments can only contain alphabets, numbers, comma, dot, &, (), and hyphen")
    private String comments;
   private AttachmentDto attachment;



}
