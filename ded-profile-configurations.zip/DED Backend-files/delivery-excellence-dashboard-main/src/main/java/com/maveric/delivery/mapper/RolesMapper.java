package com.maveric.delivery.mapper;

import com.maveric.delivery.model.Roles;
import com.maveric.delivery.requestdto.RolesDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface RolesMapper {

    RolesMapper MAPPER = Mappers.getMapper(RolesMapper.class);

    List<Roles> toEntityList(List<RolesDto> rolesDtos);

    List<RolesDto> toDtoList(List<Roles> rolesList);

    Roles toEntity(RolesDto rolesDto);

    RolesDto toDto(Roles roles);

}
