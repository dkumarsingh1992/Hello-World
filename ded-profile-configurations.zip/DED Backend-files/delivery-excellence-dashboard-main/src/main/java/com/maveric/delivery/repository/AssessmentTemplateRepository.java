package com.maveric.delivery.repository;

import com.maveric.delivery.model.AssessmentTemplate;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface AssessmentTemplateRepository extends MongoRepository<AssessmentTemplate,Long> {
}
