package com.maveric.delivery.repository;

import com.maveric.delivery.model.Assessment;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.UUID;

public interface AssessmentRepository extends MongoRepository<Assessment,Long> {

    List<Assessment> findByUserId(UUID userId);

    List<Assessment> findByReviewerId(UUID reviewerId);
}
