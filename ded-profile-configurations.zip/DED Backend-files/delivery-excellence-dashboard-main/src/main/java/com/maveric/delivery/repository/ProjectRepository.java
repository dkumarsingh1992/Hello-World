package com.maveric.delivery.repository;

import com.maveric.delivery.model.Project;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Repository
public interface ProjectRepository extends MongoRepository<Project,Long> {
    boolean existsByProjectName(String accountName);
    List<Project> findByAccountId(Long accountId);
    List<Project> findByAccountIdAndStatus(Long accountId, String status);

    Optional<Project> findByIdAndAccountId(Long Id,Long accountId);
    List<Project> findByIdIn(Set<Long> list);


}
