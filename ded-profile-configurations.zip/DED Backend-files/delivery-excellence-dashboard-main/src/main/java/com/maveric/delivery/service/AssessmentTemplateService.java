package com.maveric.delivery.service;

import com.maveric.delivery.model.AssessmentTemplate;

import java.util.List;

public interface AssessmentTemplateService {
    List<AssessmentTemplate> getAllTemplates(String type);
}
