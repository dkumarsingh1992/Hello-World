package com.maveric.delivery.model.embedded;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Numerical {

    private Integer min;
    private Integer max;
    @NotNull(message = "value is required")
    private Double value;
    private List<Range> range;
}
