package com.maveric.delivery.model.embedded;


import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectClientInfo {
    @Size(min = 3, max = 500, message = "Client Notes must be between 3 and 500 characters")
    private String clientNotes;
    @Valid
    @Size(max = 5,message = "The number of client contacts cannot exceed 5")
    private List<ClientContacts> clientContacts;

    public void setClientContacts(List<ClientContacts> contactsList){
        List<ClientContacts> clientContacts = new ArrayList<>();
        if(null == contactsList ||contactsList.isEmpty()){
            this.clientContacts = contactsList;
        }else {
            for(ClientContacts contacts : contactsList){
                if(contacts.getContactName() == null && contacts.getContactNumber() == null
                        && contacts.getDesignation() == null && contacts.getEmailId() == null){
                    clientContacts.add(contacts);
                } else if (contacts.getContactName() == null || contacts.getContactNumber() == null
                        || contacts.getDesignation() == null || contacts.getEmailId() == null) {
                    throw new IllegalArgumentException("Invalid contact list");
                }
            }
            contactsList.removeAll(clientContacts);
            this.clientContacts = contactsList;
        }
    }
}
