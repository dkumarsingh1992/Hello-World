package com.maveric.delivery.model.embedded;

import jakarta.validation.Valid;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OtherInformation {

    @Size(min = 2, max = 50, message = "TimeSheet Id must be between 2 and 50 characters")
    @Pattern(regexp = "^[a-zA-Z0-9,.\\s]*$", message = "TimeSheet Id can only contain alphabets, numbers, white space, dot, and comma")
    private String timeSheetId;
    @Size(max = 5,message = "The number of externalSystemInfo cannot exceed 5")
    @Valid
    private List<ExternalSystemInfo> externalSystemInfo;

}
