package com.maveric.delivery.repository;

import com.maveric.delivery.model.ArtifactType;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ArtifactTypeRepository extends MongoRepository<ArtifactType,Long> {
}
