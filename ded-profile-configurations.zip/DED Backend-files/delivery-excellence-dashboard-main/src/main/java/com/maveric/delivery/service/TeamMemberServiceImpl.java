package com.maveric.delivery.service;

import com.maveric.delivery.exception.*;
import com.maveric.delivery.model.Project;
import com.maveric.delivery.model.TeamMember;
import com.maveric.delivery.model.embedded.TeamMemberStatus;
import com.maveric.delivery.repository.ProjectRepository;
import com.maveric.delivery.repository.TeamMemberRepository;
import com.maveric.delivery.requestdto.TeamMemberDto;
import com.maveric.delivery.responsedto.TeamMemberResponseDto;
import com.maveric.delivery.responsedto.TeamMemberResponseListDto;
import com.maveric.delivery.utils.UtilMethods;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class TeamMemberServiceImpl implements TeamMemberService {
    private final UtilMethods utilMethods;
    private final TeamMemberRepository teamMemberRepository;
    private final ProjectRepository projectRepository;

    @Override
    public TeamMemberResponseDto saveTeamMember(TeamMemberDto teamMemberDto, UUID userId, Long projectId) {
        log.info("TeamMemberServiceImpl:: saveTeamMember:: started");
        checkUserAuthenticity(userId);
        Optional<Project> project = projectRepository.findById(projectId);
        if (project.isEmpty()) {
            log.error("TeamMemberServiceImpl:: saveTeamMember:: Project id not found");
            throw new ProjectNotFoundException("Project with ID " + projectId + " not found");
        }

        startAndEndDateValidator(teamMemberDto.getStartDate(), project.get().getStartDate(), teamMemberDto.getEndDate(), project.get().getEndDate());

        TeamMember teamMember = new TeamMember();
        BeanUtils.copyProperties(teamMemberDto, teamMember);
        teamMember.setProjectId(projectId);
        teamMember.setStatus(TeamMemberStatus.Active);
        teamMember.setCreatedBy(utilMethods.getDisplayName(userId));
        teamMember.setCreatedAt(System.currentTimeMillis());
        teamMember.setUpdatedBy(utilMethods.getDisplayName(userId));
        teamMember.setUpdatedAt(System.currentTimeMillis());

        TeamMemberResponseDto responseDto = new TeamMemberResponseDto();
        TeamMember response = teamMemberRepository.save(teamMember);
        BeanUtils.copyProperties(response, responseDto);
        log.info("TeamMemberServiceImpl:: saveTeamMember:: ended");
        return responseDto;
    }

    @Override
    public List<TeamMemberResponseListDto> getAllTeamMembers(Long projectId) {
        log.info("TeamMemberServiceImpl:: getAllTeamMembers:: started");
        List<TeamMember> teamMemberList = teamMemberRepository.findByProjectId(projectId);
        List<TeamMemberResponseListDto> responseDto = toTeamMemberDtoList(teamMemberList);
        log.info("TeamMemberServiceImpl:: getAllTeamMembers:: ended");
        return responseDto;
    }

    @Override
    public TeamMemberResponseListDto getTeamMemberById(Long teamMemberId) {
        log.info("TeamMemberServiceImpl:: getTeamMemberById:: started");
        Optional<TeamMember> teamMember = teamMemberRepository.findById(teamMemberId);
        if (teamMember.isPresent()) {
            Optional<Project> project=projectRepository.findById(teamMember.get().getProjectId());
            TeamMemberResponseListDto responseDto = toTeamMemberDto(teamMember.get(),project.get().getProjectName(),project.get().getAccountName());
            log.info("TeamMemberServiceImpl:: getTeamMemberById:: ended");
            return responseDto;
        }
        else {
            log.error("TeamMemberServiceImpl:: getTeamMemberById:: No id found");
            throw new TeamMemberNotFoundException("Team Member with ID " + teamMemberId + " not found");
        }
    }

    @Override
    public TeamMemberResponseDto editTeamMember(TeamMemberDto teamMemberDto, UUID userId, Long teamMemberId) {
        log.info("TeamMemberServiceImpl:: editTeamMember:: started");
        checkUserAuthenticity(userId);
        Optional<TeamMember> teamMember = teamMemberRepository.findById(teamMemberId);
        if (teamMember.isPresent()) {
            String teamMemberName = teamMember.get().getName();
            TeamMemberStatus teamMemberStatus = teamMember.get().getStatus();
            TeamMember existingMember = teamMember.get();
            Optional<Project> project = projectRepository.findById(teamMember.get().getProjectId());

            startAndEndDateValidator(teamMemberDto.getStartDate(), project.get().getStartDate(), teamMemberDto.getEndDate(), project.get().getEndDate());

            BeanUtils.copyProperties(teamMemberDto, existingMember);
            existingMember.setName(teamMemberName);
            existingMember.setUpdatedBy(utilMethods.getDisplayName(userId));
            existingMember.setUpdatedAt(System.currentTimeMillis());
            existingMember.setStatus(teamMemberStatus);

            if (teamMemberDto.getStatus() != null && teamMemberDto.getStatus().equals(TeamMemberStatus.Released))
                existingMember.setStatus(teamMemberDto.getStatus());
            TeamMemberResponseDto responseDto = new TeamMemberResponseDto();
            TeamMember response = teamMemberRepository.save(existingMember);
            BeanUtils.copyProperties(response, responseDto);
            log.info("TeamMemberServiceImpl:: editTeamMember:: ended");
            return responseDto;
        } else {
            log.error("TeamMemberServiceImpl:: editTeamMember:: No id found");
            throw new TeamMemberNotFoundException("Team Member with ID " + teamMemberId + " not found");
        }
    }

    void startAndEndDateValidator(Long memberStartDate, Long projectStartDate, Long memberEndDate, Long projectEndDate) {
        LocalDate startDate = Instant.ofEpochMilli(memberStartDate)
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
        if (startDate.isAfter(LocalDate.now())) {
            log.error("TeamMemberServiceImpl::saveTeamMember::error");
            throw new ProjectDateException("Future date is not allowed: start date must be a past or current date");
        } else if (memberStartDate <= projectStartDate) {
            log.error("TeamMemberServiceImpl::saveTeamMember:: startDate error");
            throw new ProjectDateException("Member start date must be after Project start date");
        }

        if (memberEndDate != null) {
            LocalDate endDate = Instant.ofEpochMilli(memberEndDate)
                    .atZone(ZoneId.systemDefault())
                    .toLocalDate();
            if (startDate.isAfter(endDate)) {
                log.error("TeamMemberServiceImpl::saveTeamMember::error");
                throw new ProjectDateException("End date must be a after start date");
            } else if (projectEndDate!=null && memberEndDate >= projectEndDate) {
                log.error("TeamMemberServiceImpl::saveTeamMember:: EndDate error");
                throw new ProjectDateException("Member End date Must be before Project end date");
            }
        }
    }


    private List<TeamMemberResponseListDto> toTeamMemberDtoList(List<TeamMember> teamMember) {
        return teamMember.stream()
                .map(teamMembers -> toTeamMemberResponseDto(teamMembers))
                .toList();
    }

    private TeamMemberResponseListDto toTeamMemberResponseDto(TeamMember teamMember) {
        TeamMemberResponseListDto teamMemberResponseDto = new TeamMemberResponseListDto();
        BeanUtils.copyProperties(teamMember, teamMemberResponseDto);
        return teamMemberResponseDto;
    }
    private TeamMemberResponseListDto toTeamMemberDto(TeamMember teamMember, String projectName,String accountName) {
        TeamMemberResponseListDto teamMemberResponseDto = new TeamMemberResponseListDto();
        BeanUtils.copyProperties(teamMember, teamMemberResponseDto);
        teamMemberResponseDto.setProjectName(projectName);
        teamMemberResponseDto.setAccountName(accountName);
        return teamMemberResponseDto;
    }

    void checkUserAuthenticity(UUID userId) {
        String userName = utilMethods.getDisplayName(userId);
        if (null == userName
                || userName.isEmpty()) {
            log.error("TeamMemberServiceImpl::User not found");
            throw new UserNotFoundException(":User not found " + userId);
        }
    }
}
