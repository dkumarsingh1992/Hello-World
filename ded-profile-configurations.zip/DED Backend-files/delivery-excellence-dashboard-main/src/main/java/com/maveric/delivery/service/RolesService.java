package com.maveric.delivery.service;

import com.maveric.delivery.requestdto.RolesDto;

import java.util.List;

public interface RolesService {

    String getRoleName(Long roleId);

    List<RolesDto> getRoles();

    RolesDto getRole(Long roleId);

    List<RolesDto> findByGroups(List<String> userGroupList);
}
