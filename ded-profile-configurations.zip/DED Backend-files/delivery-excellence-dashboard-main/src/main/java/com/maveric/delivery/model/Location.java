package com.maveric.delivery.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(value = "location")
@NoArgsConstructor
@AllArgsConstructor
public class Location extends IdentifiedEntity{
    private String name;

    public Location(long l, String location1) {
        super();
    }
}
