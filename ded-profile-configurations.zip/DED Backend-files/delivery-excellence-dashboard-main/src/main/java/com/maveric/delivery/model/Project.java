package com.maveric.delivery.model;

import com.maveric.delivery.model.embedded.*;
import com.maveric.delivery.model.embedded.ProjectStatus;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.List;

@Data
@Document(collection = "projects")
public class Project extends IdentifiedEntity {
    private Long accountId;
    private String accountName;
    private String projectName;
    private String customerLOB;
    private String engagementType;
    private List<String> tags;
    private String businessSubVertical;
    private Long startDate;
    private Long endDate;
    private ProjectStatus status;
    private Boolean isBillable;
    private String description;
    private DeliveryInformation deliveryInfo;
    private List<DedRoles> dedRoles;
    @Valid
    private ProjectClientInfo clientInformation;
    private OtherInformation otherInformation;
    private String createdBy;
    private Long createdAt;
    private String updateBy;
    private Long updatedAt;
}
