package com.maveric.delivery.model.embedded;

/**
 * @author ankushk
 */
public enum AccountStatus {
    Inactive, Active, Delete

}
