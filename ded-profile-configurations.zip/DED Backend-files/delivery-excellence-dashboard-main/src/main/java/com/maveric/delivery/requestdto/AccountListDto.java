package com.maveric.delivery.requestdto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.maveric.delivery.model.embedded.AccountStatus;
import com.maveric.delivery.model.embedded.AccountType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonPropertyOrder({"id","name"})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountListDto {
    private Long id;
    private String name;


}
