package com.maveric.delivery.controller;


import com.maveric.delivery.model.Project;
import com.maveric.delivery.requestdto.DedRolesDto;
import com.maveric.delivery.requestdto.ProjectRequestDto;
import com.maveric.delivery.requestdto.ProjectsListDto;
import com.maveric.delivery.responsedto.ProjectListResponseDto;
import com.maveric.delivery.responsedto.ProjectResponseDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.ProjectService;
import com.maveric.delivery.utils.Constants;
import com.maveric.delivery.utils.SuccessMessage;
import com.maveric.delivery.utils.ValidateApiAccess;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.*;

@RestController
@RequestMapping("/v1")
@Slf4j
@RequiredArgsConstructor
public class ProjectController {
    private final ProjectService projectService;
    private final ValidateApiAccess validateApiAccess;

    @Operation(summary = "Save Projects")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Projects created successfully",
                    content = @Content(schema = @Schema(implementation = Project.class))),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(path = "/projects")
    public ResponseEntity<ResponseDto> saveProject(HttpServletRequest servletRequest, @Valid @RequestBody ProjectRequestDto projectRequestDto) {
        log.info("ProjectController::Saving projects: {}", projectRequestDto);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).accountId(projectRequestDto.getAccountId()).build();
        validateApiAccess.isAccessible(rolesDto, PROJECTS, CREATE);
        ProjectResponseDto createdProject = projectService.saveProject(projectRequestDto);
        log.info("Project created successfully");
        return ResponseEntity.status(HttpStatus.CREATED).body(new ResponseDto(Constants.SUCCESS, SuccessMessage.PROJECT_CREATED.getCode(), SuccessMessage.PROJECT_CREATED.getMessage(), null, createdProject));
    }

    @Operation(summary = "Edit Projects")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Projects created successfully",
                    content = @Content(schema = @Schema(implementation = Project.class))),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PutMapping(path = "/projects/{projectId}")
    public ResponseEntity<ResponseDto> editProject(HttpServletRequest servletRequest,@Valid @RequestBody ProjectRequestDto projectRequestDto, @PathVariable Long projectId) {
        log.info("ProjectController::Edit projects: {}", projectRequestDto);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).accountId(projectRequestDto.getAccountId()).projectId(projectId).build();
        validateApiAccess.isAccessible(rolesDto, PROJECTS, EDIT);
        ProjectResponseDto createdProject = projectService.editProject(projectRequestDto, projectId);
        log.info("Project updated successfully");
        return ResponseEntity.status(HttpStatus.CREATED).body(new ResponseDto(Constants.SUCCESS, SuccessMessage.UPDATE_PROJECT_DETAILS.getCode(), SuccessMessage.UPDATE_PROJECT_DETAILS.getMessage(), null, createdProject));
    }
    @Operation(summary = "Get By project Id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "project found by ID",
                    content = @Content(schema = @Schema(implementation = Project.class))),
            @ApiResponse(responseCode = "404", description = "project not found for the given ID")
    })
    @GetMapping(path = "/projects/{projectId}")
    public ResponseEntity<ResponseDto> getProjectById(HttpServletRequest servletRequest,@PathVariable Long projectId,@RequestHeader UUID userId) {
        log.info("ProjectController::Fetching project by ID: {}", projectId);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).projectId(projectId).build();
        validateApiAccess.isAccessible(rolesDto, PROJECTS,VIEW_ASSOCIATED,VIEW_ALL );
        ProjectResponseDto project = projectService.getProjectById(projectId,rolesDto.getOid());
        log.info("Project retrieved successfully");
        return ResponseEntity.status(HttpStatus.OK)
                .body(new ResponseDto(Constants.SUCCESS, SuccessMessage.FETCH_PROJECT.getCode(), SuccessMessage.FETCH_PROJECT.getMessage(), null, project));
    }

    @Operation(summary = "Validate project name")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Project Name is available"),
            @ApiResponse(responseCode = "404", description = "Project Name is already exit"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @GetMapping(path = "/projects/validate")
    public ResponseEntity<ResponseDto> validateProjectName(HttpServletRequest servletRequest,@RequestParam Long accountId,@RequestParam String field,

                                                           @RequestParam String value) {
        boolean payload = projectService.validateProjectName(accountId, value);
        return ResponseEntity.status(HttpStatus.OK)
                .body(new ResponseDto<>(Constants.SUCCESS,payload ? SuccessMessage.PROJECT_NAME_EXIST.getCode() : SuccessMessage.DUPLICATE_PROJECT_NAME.getCode()
                        , payload ? SuccessMessage.PROJECT_NAME_EXIST.getMessage() : SuccessMessage.DUPLICATE_PROJECT_NAME.getMessage(),null,payload ));
    }

    @Operation(summary = "Get Projects")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Projects List retrived successfully",
                    content = @Content(schema = @Schema(implementation = Project.class))),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/projects")
    public ResponseEntity<ResponseDto> getProjectList(HttpServletRequest servletRequest,@RequestParam(value = "accountId",required=false,defaultValue = "0") Long accountId,@RequestHeader UUID userId ) {
        log.info("ProjectController::Project List: {}", accountId);
        DedRolesDto rolesDto = DedRolesDto.builder().oid(UUID.fromString((String) servletRequest.getAttribute(O_ID))).build();
        validateApiAccess.isAccessible(rolesDto, PROJECTS,VIEW_ALL,VIEW_ASSOCIATED );
        ProjectsListDto projectList = projectService.getProjectDetailsList(rolesDto.getOid(), accountId);
        log.info("Project list retrieved successfully");

        return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto(Constants.SUCCESS, SuccessMessage.PROJECT_LIST_FETCHED.getCode(), SuccessMessage.PROJECT_LIST_FETCHED.getMessage(), null, projectList));

    }

}
