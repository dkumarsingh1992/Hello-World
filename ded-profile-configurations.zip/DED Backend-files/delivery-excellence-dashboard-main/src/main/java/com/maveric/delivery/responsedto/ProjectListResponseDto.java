package com.maveric.delivery.responsedto;

import com.maveric.delivery.model.embedded.ProjectStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectListResponseDto {
    private Long id;
    private String name;
    private String customerLOB;
    private Long startDate;
    private Long endDate;
    private String  deliveryManager;
    private String  deliveryPartner;
    private String  accountPartner;
    private String  engagementPartner;
    private String isBillable;
    private ProjectStatus status;
}
