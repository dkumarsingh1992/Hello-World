package com.maveric.delivery.requestdto;

import com.maveric.delivery.responsedto.BaseDto;
import lombok.Data;

import java.util.List;

@Data
public class RolesDto extends BaseDto {
    private List<String> group;
    private int hierarchy;
}
