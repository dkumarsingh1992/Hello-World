package com.maveric.delivery.exception;

public class AccountTransactionException extends RuntimeException {
    public AccountTransactionException(String message) {
        super(message);
    }
}