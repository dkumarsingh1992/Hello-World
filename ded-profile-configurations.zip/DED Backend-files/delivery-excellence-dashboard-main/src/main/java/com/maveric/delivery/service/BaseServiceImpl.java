package com.maveric.delivery.service;

import com.maveric.delivery.exception.BaseTypeNotFoundException;
import com.maveric.delivery.model.RolePrivileges;
import com.maveric.delivery.model.Roles;
import com.maveric.delivery.model.embedded.DedRoles;
import com.maveric.delivery.model.ArtifactType;
import com.maveric.delivery.model.Location;
import com.maveric.delivery.model.ProjectRole;
import com.maveric.delivery.repository.*;
import com.maveric.delivery.requestdto.RolePrivilegesDto;
import com.maveric.delivery.requestdto.UserPrivilegesDto;
import com.maveric.delivery.responsedto.BaseDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import static com.maveric.delivery.utils.Constants.*;
import static com.maveric.delivery.utils.Constants.ARTIFACT_TYPE;

@Service
@Slf4j
@RequiredArgsConstructor
public class BaseServiceImpl implements BaseService {
    private final FrequencyRepository frequencyRepository;
    private final BusinessSubverticalRepository businessSubverticalRepository;
    private final EngagementTypeRepository engagementTypeRepository;
    private final ProjectStatusRepository projectStatusRepository;

    private final LocationRepository locationRepository;
    private final ProjectRoleRepository  projectRoleRepository;
    private final ArtifactTypeRepository artifactTypeRepository;
    @Override
    public List<BaseDto> fetchAllTypes(String type) {
        log.info("BaseServiceImpl:: fetchAllTypes() started");
        List<BaseDto> baseDtoList;
        switch (type) {
            case FREQUENCY:
                baseDtoList=mapEntitiesToBaseDto(frequencyRepository.findAll());
                break;
            case ENGAGEMENT_TYPE:
                baseDtoList=mapEntitiesToBaseDto(engagementTypeRepository.findAll());
                break;
            case BUSINESS_SUB_VERTICAL:
                baseDtoList= mapEntitiesToBaseDto(businessSubverticalRepository.findAll());
                break;
            case LOCATION:
                baseDtoList= mapEntitiesToBaseDto(locationRepository.findAll());
                break;
            case PROJECT_ROLE:
                baseDtoList= mapEntitiesToBaseDto(projectRoleRepository.findAll());
                break;
            case ARTIFACT_TYPE:
                baseDtoList= mapEntitiesToBaseDto(artifactTypeRepository.findAll());
                break;
            default:
                throw new BaseTypeNotFoundException(type + " not found");
        }
        log.info("BaseServiceImpl:: fetchAllTypes() ended");
        return baseDtoList;
    }

    @Override
    public List<BaseDto> fetchAllProjectStatus() {
        log.info("BaseServiceImpl:: fetchAllProjectStatus() started");
        List<BaseDto> baseDtoList=mapEntitiesToBaseDto(projectStatusRepository.findAll());
        log.info("BaseServiceImpl:: fetchAllProjectStatus() ended");
        return baseDtoList;
    }
    private <T> List<BaseDto> mapEntitiesToBaseDto(List<T> entities) {
        return entities.stream()
                .filter(Objects::nonNull)
                .map(entity->{
                    BaseDto baseDto=new BaseDto();
                    BeanUtils.copyProperties(entity, baseDto);
                    return baseDto;})
                .collect(Collectors.toList());
    }
    @Override
    public BaseDto saveLocation(String name) {
        log.info("BaseServiceImpl:: saveLocation() started");
        Location location = new Location();
        location.setName(name);
        BaseDto baseDto = new BaseDto();
        BeanUtils.copyProperties(location, baseDto);
        Location savedLocation = locationRepository.save(location);
        baseDto.setId(savedLocation.getId());
        log.info("BaseServiceImpl:: saveLocation() ended");
        return baseDto;
    }

    @Override
    public BaseDto saveProjectRole(String name) {
        log.info("BaseServiceImpl:: saveProjectRole() started");
        ProjectRole projectRole = new ProjectRole();
        projectRole.setName(name);
        BaseDto baseDto = new BaseDto();
        BeanUtils.copyProperties(projectRole, baseDto);
        ProjectRole savedLocation = projectRoleRepository.save(projectRole);
        baseDto.setId(savedLocation.getId());
        log.info("BaseServiceImpl:: saveProjectRole() ended");
        return baseDto;
    }

    @Override
    public BaseDto saveArtifactType(String name) {
        log.info("BaseServiceImpl:: saveArtifactType() started");
        ArtifactType artifactType = new ArtifactType();
        artifactType.setName(name);
        BaseDto baseDto = new BaseDto();
        BeanUtils.copyProperties(artifactType, baseDto);
        ArtifactType savedLocation = artifactTypeRepository.save(artifactType);
        baseDto.setId(savedLocation.getId());
        log.info("BaseServiceImpl:: saveArtifactType() ended");
        return baseDto;
    }
}
