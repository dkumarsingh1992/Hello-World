package com.maveric.delivery.repository;

import com.maveric.delivery.model.BusinessSubvertical;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface BusinessSubverticalRepository extends MongoRepository<BusinessSubvertical,Long> {
}
