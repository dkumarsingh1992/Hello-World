package com.maveric.delivery.responsedto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProjectTypeDto {
    @NotNull(message = "ProjectTypeName should not be Empty")
    private String name;
    @NotNull(message = "ProjectTypeName should not be Empty")
    private String description;
}
