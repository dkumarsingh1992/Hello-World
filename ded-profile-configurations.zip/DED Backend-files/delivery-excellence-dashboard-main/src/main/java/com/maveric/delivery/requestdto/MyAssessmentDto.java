package com.maveric.delivery.requestdto;

import com.maveric.delivery.responsedto.AssessmentResponseDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MyAssessmentDto {
    private List<AssessmentResponseDto> assessmentResponseDtoList;
    private Boolean showReviewAssessmentTab;
}
