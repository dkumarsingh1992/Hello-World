package com.maveric.delivery.controller;


import com.maveric.delivery.model.Account;
import com.maveric.delivery.requestdto.UserPrivilegesDto;
import com.maveric.delivery.responsedto.BaseDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.BaseService;
import com.maveric.delivery.utils.FailedMessage;
import com.maveric.delivery.utils.SuccessMessage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.maveric.delivery.utils.Constants.FAILED;
import static com.maveric.delivery.utils.Constants.SUCCESS;
import static com.maveric.delivery.utils.SuccessMessage.FETCHED_PROJECT_STATUS;
import static com.maveric.delivery.utils.SuccessMessage.ROLE_PRIVILEGES_FETCHED;
import static com.maveric.delivery.utils.FailedMessage.*;
import static com.maveric.delivery.utils.FailedMessage.ARTIFACTTYPE_CREATION_FAILED;
import static com.maveric.delivery.utils.SuccessMessage.*;
import static com.maveric.delivery.utils.SuccessMessage.SAVE_ARTIFACT_TYPE;

@RestController
@RequestMapping("/v1")
@Slf4j
@RequiredArgsConstructor
public class BaseController {

    private final BaseService basedService;

    @Operation(summary = "Fetch All BasedTypes")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful operation",
                    content = @Content(schema = @Schema(implementation = BaseDto.class))),
            @ApiResponse(responseCode = "404", description = "Types not Present in DB"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/types/{typeName}")
    public ResponseEntity<ResponseDto> fetchAllType(@PathVariable String typeName) {
        log.info("BasedController::FetchAllType() started");
        List<BaseDto> baseDtoList = basedService.fetchAllTypes(typeName);
        if (CollectionUtils.isEmpty(baseDtoList)) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new ResponseDto(FAILED, FailedMessage.TYPE_NOT_FOUND.getCode(), FailedMessage.TYPE_NOT_FOUND.getMessage().replaceAll("Type", typeName), null, baseDtoList));
        }
        log.info("BasedController::FetchAllType() ended");
        return ResponseEntity.ok(new ResponseDto(SUCCESS, SuccessMessage.FETCH_TYPE.getCode(), typeName + SuccessMessage.FETCH_TYPE.getMessage(), null, baseDtoList));
    }

    @Operation(summary = "Fetch All Project Status")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful operation",
                    content = @Content(schema = @Schema(implementation = BaseDto.class))),
            @ApiResponse(responseCode = "404", description = "Project Status not Present in DB"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })

    @GetMapping(path = "/types/project-status")
    public ResponseEntity<ResponseDto> fetchAllProjectStatus() {
        log.info("BasedController::fetchAllProjectStatus() started");
        List<BaseDto> baseDtoList = basedService.fetchAllProjectStatus();
        if (CollectionUtils.isEmpty(baseDtoList)) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new ResponseDto(FAILED, FailedMessage.FETCHED_PROJECT_STATUS_FAILED.getCode(), FailedMessage.FETCHED_PROJECT_STATUS_FAILED.getMessage(), null, baseDtoList));
        }
        log.info("BasedController::fetchAllProjectStatus() ended");
        return ResponseEntity.ok(new ResponseDto(SUCCESS, FETCHED_PROJECT_STATUS.getCode(), FETCHED_PROJECT_STATUS.getMessage(), null, baseDtoList));
    }
    @Operation(summary = "Save Location")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful operation",
                    content = @Content(schema = @Schema(implementation = BaseDto.class))),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping (path = "/types/location/{location}")
    public ResponseEntity<ResponseDto> saveLocation(@PathVariable("location") String name) {
        log.info("BasedController::saveLocation() started");
        BaseDto saveLocation = basedService.saveLocation(name);
        if (saveLocation == null) {
            return ResponseEntity.ok(new ResponseDto(FAILED, LOCATION_CREATION_FAILED.getCode(), LOCATION_CREATION_FAILED.getMessage(), null, null));
        }
        log.info("BasedController::saveLocation() ended");
        return ResponseEntity.status(HttpStatus.CREATED).body(new ResponseDto(SUCCESS, SAVE_LOCATION.getCode(), SAVE_LOCATION.getMessage(), null, saveLocation));
    }
    @Operation(summary = "Save ProjectRole")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful operation",
                    content = @Content(schema = @Schema(implementation = BaseDto.class))),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping (path = "/types/projectRole/{projectRole}")
    public ResponseEntity<ResponseDto> saveProjectRole(@PathVariable("projectRole") String name) {
        log.info("BasedController::saveProjectRole() started");
        BaseDto projectRole = basedService.saveProjectRole(name);
        if (projectRole == null) {
            return ResponseEntity.ok(new ResponseDto(FAILED, PROJECTROLE_CREATION_FAILED.getCode(), PROJECTROLE_CREATION_FAILED.getMessage(), null, null));
        }
        log.info("BasedController::saveProjectRole() ended");
        return ResponseEntity.status(HttpStatus.CREATED).body(new ResponseDto(SUCCESS, SAVE_PROJECT_ROLE.getCode(), SAVE_PROJECT_ROLE.getMessage(), null, projectRole));
    }
    @Operation(summary = "Save ArtifactType")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful operation",
                    content = @Content(schema = @Schema(implementation = BaseDto.class))),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping (path = "/types/artifactType/{artifactType}")
    public ResponseEntity<ResponseDto> saveArtifactType(@PathVariable("artifactType") String name) {
        log.info("BasedController::saveArtifactType() started");
        BaseDto artifactType= basedService.saveArtifactType(name);
        if (artifactType == null) {
            return ResponseEntity.ok(new ResponseDto(FAILED, ARTIFACTTYPE_CREATION_FAILED.getCode(), ARTIFACTTYPE_CREATION_FAILED.getMessage(), null, null));
        }
        log.info("BasedController::saveArtifactType() ended");
        return ResponseEntity.status(HttpStatus.CREATED).body(new ResponseDto(SUCCESS, SAVE_ARTIFACT_TYPE.getCode(), SAVE_ARTIFACT_TYPE.getMessage(), null, artifactType));
    }
}
