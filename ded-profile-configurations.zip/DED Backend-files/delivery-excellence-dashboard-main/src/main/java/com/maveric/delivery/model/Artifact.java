package com.maveric.delivery.model;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.UUID;


/**
 * @author shreyab
 */
@Data
@Document(collection = "artifact")
public class Artifact extends IdentifiedEntity{
  private Long projectId;
  private String name;
  private String type;
  private String link;
  private String comments;
  private Attachment attachment;
  private Long createdAt;
  private String creatorName;
  private UUID createdBy;


}
