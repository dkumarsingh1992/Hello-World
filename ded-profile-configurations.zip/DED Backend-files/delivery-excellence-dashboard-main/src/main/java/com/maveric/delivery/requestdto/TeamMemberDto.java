package com.maveric.delivery.requestdto;

import com.maveric.delivery.model.embedded.TeamMemberStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TeamMemberDto {

    @NotBlank(message = "Team Member name is required")
    @Pattern(regexp = "^[a-zA-Z.]+$", message = "Team Member name can only contain alphabets and dots.")
    private String name;
    @NotBlank(message = "Project Role is required")
    private String projectRole;
    private String location;
    @Size(max = 5, message = "A maximum of 5 skills are allowed")
    private List<String> skillSet;
    @NotNull(message = "Billable is required")
    private Boolean isBillable;
    @NotNull(message = "Start Date is required")
    private Long startDate;
    private Long endDate;
    @NotNull(message = "Allocation is required")
    private Long allocation;
    private TeamMemberStatus status;
}
