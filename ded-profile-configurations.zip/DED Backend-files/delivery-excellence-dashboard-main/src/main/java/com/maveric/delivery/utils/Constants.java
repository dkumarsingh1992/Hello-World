package com.maveric.delivery.utils;

public class Constants {


    public static final String DH = "DH";
    public static final String DP = "DP";
    public static final String DM = "DM";
    public static final String AP = "AP";
    public static final String EP = "EP";

    public static final String SUCCESS = "Success";
    public static final String FAILED = "Failed";
    public static final String DELIVERY_HEAD = "Delivery Head";
    public static final String ACCOUNT_PARTNER = "Account Partner";
    public static final String ENGAGEMENT_PARTNER = "Engagement Partner";
    public static final String DELIVERY_PARTNER = "Delivery Partner";

    public static final String DELIVERY_MANAGER = "Delivery Manager";
    public static final String FREQUENCY = "frequency";
    public static final String ENGAGEMENT_TYPE = "engagement-type";
    public static final String BUSINESS_SUB_VERTICAL = "business-subvertical";

    public static final String LOCATION = "Location";
    public static final String PROJECT_ROLE = "Project-Role";
    public static final String ARTIFACT_TYPE = "Artifact-Type";
    public static final String ACCOUNTS = "Accounts";
    public static final String PROJECTS = "Projects";
    public static final String FULL_ACCESS = "FULL_ACCESS";
    public static final String NO_ACCESS = "NO_ACCESS";
    public static final String ACCOUNTS_VIEW_ALL = "ACCOUNTS_VIEW_ALL";
    public static final String ACCOUNTS_VIEW_ASSOCIATED = "ACCOUNTS_VIEW_ASSOCIATED";
    public static final String ACCOUNTS_CREATE = "ACCOUNTS_CREATE";
    public static final String ACCOUNTS_EDIT = "ACCOUNTS_EDIT";
    public static final String ACCOUNTS_DELETE = "ACCOUNTS_DELETE";
    public static final String PROJECTS_VIEW_ALL = "PROJECTS_VIEW_ALL";
    public static final String PROJECTS_VIEW_ASSOCIATED = "PROJECTS_VIEW_ASSOCIATED";
    public static final String PROJECTS_CREATE = "PROJECTS_CREATE";
    public static final String PROJECTS_EDIT = "PROJECTS_EDIT";
    public static final String PROJECTS_DELETE = "PROJECTS_DELETE";
    public static final String ASSESSMENTS_VIEW_ALL = "ASSESSMENTS_VIEW_ALL";
    public static final String ASSESSMENTS_VIEW_ASSOCIATED = "ASSESSMENTS_VIEW_ASSOCIATED";
    public static final String DASHBOARD_VIEW = "DASHBOARD_VIEW";


    public static final String YES = "Yes";
    public static final String NO = "No";


    public static final String SUPER_ADMIN_ = "Super Admin";
    public static final String ACCOUNT_ADMIN_ = "Account Admin";
    public static final String PROJECT_ADMIN_ = "Project Admin";
    public static final String DELIVERY_OWNER_ = "Delivery Owner";
    public static final String ORGANIZATION_LEADER_ = "Organization Leader";
    public static final String TEAM_MEMBER_ = "Team Member";

    public static final String HIERARCHY = "hierarchy";

    public static final String ARTIFACTS = "Artifacts";
    public static final String TEAM_MEMBERS = "Team Members";

    public static final String ASSESSMENTS = "Assessments";
    public static final String USER_PROFILES = "User Profiles";
    public static final String DASHBOARD = "Dashboard";

    public static final String ROLE_PERMISSIONS = "Role Permissions";

    public static final String ASSESSMENT_TEMPLATES = "Assessment Templates";
    public static final String USER_ROLES = "User Roles";
    public static final String FULL_ACCESS_TO = "Full Access To";

    public static final String CREATE = "Create";
    public static final String EDIT = "Edit";
    public static final String VIEW_ALL = "View_All";
    public static final String VIEW_ASSOCIATED = "View_Associated";

    public static final String AUTHORIZATION = "Authorization";
    public static final String BEARER = "Bearer ";
    public static final String T_ID = "tid";
    public static final String APP_ID = "appid";
    public static final String O_ID = "oid";
    public static final String SHOW_ACCOUNTS_TAB = "SHOW_ACCOUNTS_TAB";
    public static final String SHOW_PROJECTS_TAB = "SHOW_PROJECTS_TAB";
    public static final String SHOW_ASSESSMENTS_TAB = "SHOW_ASSESSMENTS_TAB";
    public static final String SHOW_DASHBOARD_TAB = "SHOW_DASHBOARD_TAB";
    public static final String ALL = "ALL";

    public Constants() {
    }
}
