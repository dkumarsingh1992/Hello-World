package com.maveric.delivery.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.UUID;

@Document(collection = "users")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AzureUsers {
    private UUID id;
    private String displayName;
    private String givenName;
    private String mail;
    private String surname;
    private String userPrincipalName;
    private String jobTitle;
    private String dedRole;
    private String userType;
}
