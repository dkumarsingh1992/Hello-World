package com.maveric.delivery.service;

import com.maveric.delivery.exception.CustomException;
import com.maveric.delivery.exception.DuplicateUserIdException;
import com.maveric.delivery.exception.UserNotFoundException;
import com.maveric.delivery.model.AzureUsers;
import com.maveric.delivery.model.Privileges;
import com.maveric.delivery.model.Roles;
import com.maveric.delivery.model.embedded.DedRoles;
import com.maveric.delivery.repository.AzureUserRepository;
import com.maveric.delivery.repository.DedRolesRepository;
import com.maveric.delivery.repository.RolesRepository;
import com.maveric.delivery.requestdto.*;
import com.maveric.delivery.responsedto.AccountResponseDto;
import com.maveric.delivery.responsedto.ProjectResponseDto;
import com.maveric.delivery.utils.Constants;
import com.maveric.delivery.utils.UtilMethods;
import com.microsoft.graph.models.User;
import com.microsoft.graph.models.UserCollectionResponse;
import com.microsoft.graph.serviceclient.GraphServiceClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;

import static com.maveric.delivery.utils.Constants.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {
    private final DedRolesRepository dedRolesRepository;
    private final AzureUserRepository azureUserRepository;
    private final GraphServiceClient graphServiceClient;

    private final RolesRepository rolesRepository;
    private final RolePrivilegesService rolePrivilegesService;
    private final RolesService rolesService;
    private final UtilMethods utilMethods;

    @Override
    public String getHighestRole(UUID oid, Long accountId, Long projectId) {
        log.info("UserServiceImpl::getHighestRole:: call started");
        if (oid == null) {
            throw new CustomException("Invalid request,oid cannot be null", HttpStatus.BAD_REQUEST);
        }

        List<DedRoles> rolesList = dedRolesRepository.findByOid(oid);

        if (SUPER_ADMIN_.equalsIgnoreCase(getRole(rolesList))) {
            return getRole(rolesList);
        }
        if (accountId == null && projectId == null) {
            return CollectionUtils.isEmpty(rolesList) ? "" : getRole(rolesList);
        }
        if (projectId == null) {
            rolesList = dedRolesRepository.findByOidAndAccountId(oid, accountId);
            return CollectionUtils.isEmpty(rolesList) ? "" : getRole(rolesList);
        }
        if ( accountId != null && projectId != null){

            rolesList = dedRolesRepository.findByOidAndProjectIdAndAccountId(oid, projectId, accountId);
        }
        log.info("UserServiceImpl::getHighestRole:: call ended");
        return CollectionUtils.isEmpty(rolesList) ? "" : getRole(rolesList);
    }


    @Override
    public DedRoles saveUser(DedRolesDto json) {
        DedRoles dedRoles = new DedRoles();
        BeanUtils.copyProperties(json, dedRoles);
        return dedRolesRepository.save(dedRoles);
    }

    public String getRole(List<DedRoles> rolesList) {
        log.info("getHighestRole:: getRole:: call started");
        List<String> userGroups = rolesList.stream().map(DedRoles::getRole).toList();
        List<RolesDto> roles = rolesService.findByGroups(userGroups);
        log.info("getHighestRole:: getRole:: call ended");
        return roles.stream().filter(Objects::nonNull).min(Comparator.comparingInt(RolesDto::getHierarchy)).map(RolesDto::getName).orElse(null);
    }

    public List<UserDto> getAllUsers() {
        log.info("UserServiceImpl::getAllUsers:: call started");
        List<AzureUsers> azureUsersList = azureUserRepository.findAll();
        log.info(" {} users fetched from azureUsers DB", azureUsersList.size());
        List<UserDto> userDtoList = azureUsersList.stream()
                .map(azureUser -> new UserDto(azureUser.getId(), azureUser.getDisplayName()))
                .toList();
        log.info("UserServiceImpl::getAllUsers:: call ended");
        return userDtoList;
    }

    public void refreshUsers() throws ReflectiveOperationException {
        userWithUrl();
    }

    private void userWithUrl() {

        UserCollectionResponse result = graphServiceClient.users().get(requestConfiguration -> {
//            requestConfiguration.queryParameters.top = 999;
            requestConfiguration.queryParameters.count = true;
        });
        updateUser(result.getValue());
        checkNextData(result);

    }

    private void checkNextData(UserCollectionResponse userCollectionResponse) {
        String nextLink = userCollectionResponse.getOdataNextLink();
        UserCollectionResponse result = graphServiceClient.users().withUrl(nextLink).get(requestConfiguration -> {
            requestConfiguration.queryParameters.count = true;
        });
        updateUser(result.getValue());
        if (StringUtils.isNotBlank(result.getOdataNextLink())) {
            checkNextData(result);
        }

    }

    private void updateUser(List<User> result) {
        List<AzureUsers> userList = new ArrayList<>();
        result.stream().forEach(user -> {
                    AzureUsers user1 = new AzureUsers();
                    user1.setId(UUID.fromString(user.getId()));
                    user1.setDisplayName(user.getDisplayName());
                    user1.setMail(user.getMail());
                    user1.setUserPrincipalName(user.getUserPrincipalName());
                    user1.setSurname(user.getSurname());
                    user1.setGivenName(user.getGivenName());
                    user1.setUserType(user.getUserType());
                    user1.setJobTitle(user.getJobTitle());
                    userList.add(user1);
                }
        );
        azureUserRepository.saveAll(userList);

    }

    public <T> void saveRole(T dto) {
        if (dto instanceof AccountResponseDto) {
            List<DedRoles> dedRolesList = new ArrayList<>();
            AccountResponseDto accountResponseDto = (AccountResponseDto) dto;
            dedRolesList.add(new DedRoles(accountResponseDto.getDeliveryHead().getUserId(), accountResponseDto.getAccountId(), null, getDisplayName(accountResponseDto.getDeliveryHead().getUserId()), "DH"));
            for (AccountRoles role : accountResponseDto.getAccountPartners()) {
                dedRolesList.add(new DedRoles(role.getUserId(), accountResponseDto.getAccountId(), null, getDisplayName(role.getUserId()), "AP"));
            }
            for (AccountRoles role : accountResponseDto.getDeliveryPartners()) {
                dedRolesList.add(new DedRoles(role.getUserId(), accountResponseDto.getAccountId(), null, getDisplayName(role.getUserId()), "DP"));
            }
            for (AccountRoles role : accountResponseDto.getEngagementPartners()) {
                dedRolesList.add(new DedRoles(role.getUserId(), accountResponseDto.getAccountId(), null, getDisplayName(role.getUserId()), "EP"));
            }
            dedRolesRepository.saveAll(dedRolesList);
        } else if (dto instanceof ProjectResponseDto) {
            List<DedRoles> dedRolesList = new ArrayList<>();
            ProjectResponseDto projectResponseDto = (ProjectResponseDto) dto;
            dedRolesList.add(new DedRoles(projectResponseDto.getDeliveryInfo().getDeliveryManager().getUserId(), projectResponseDto.getAccountId(),
                    projectResponseDto.getProjectId(),
                    getDisplayName(projectResponseDto.getDeliveryInfo().getDeliveryManager().getUserId()),
                    "DM"));
            dedRolesList.add(new DedRoles(projectResponseDto.getDeliveryInfo().getAccountPartner().getUserId(), projectResponseDto.getAccountId(), projectResponseDto.getProjectId(), getDisplayName(projectResponseDto.getDeliveryInfo().getAccountPartner().getUserId()), "AP"));
            dedRolesList.add(new DedRoles(projectResponseDto.getDeliveryInfo().getDeliveryPartner().getUserId(), projectResponseDto.getAccountId(), projectResponseDto.getProjectId(), getDisplayName(projectResponseDto.getDeliveryInfo().getDeliveryPartner().getUserId()), "DP"));
            dedRolesList.add(new DedRoles(projectResponseDto.getDeliveryInfo().getEngagementPartner().getUserId(), projectResponseDto.getAccountId(), projectResponseDto.getProjectId(), getDisplayName(projectResponseDto.getDeliveryInfo().getEngagementPartner().getUserId()), "EP"));
            dedRolesRepository.saveAll(dedRolesList);
        } else {
            // For team member
        }
    }

    @Override
    public UserPrivilegesDto getPrivileges(UUID userId) {

        List<RolePrivilegesDto> rolePrivileges = getRolePrivileges(userId);
        UserPrivilegesDto userPrivilegesDto = new UserPrivilegesDto();
        List<String> rolesList = rolePrivileges.stream().filter(Objects::nonNull).map(RolePrivilegesDto::getRoleName).toList().stream().distinct().toList();
        userPrivilegesDto.setRoles(rolesList);
        userPrivilegesDto.setHighestRole(rolePrivileges.stream().filter(Objects::nonNull).min(Comparator.comparingInt(RolePrivilegesDto::getHierarchy)).map(RolePrivilegesDto::getRoleName).orElse(null));
        userPrivilegesDto.setSuperAdmin(rolesList.contains(Constants.SUPER_ADMIN_));
        userPrivilegesDto.setPrivileges(rolePrivileges);

        return userPrivilegesDto;
    }

    @Override
    public List<String> getRolesName(UUID userId) {
        List<RolePrivilegesDto> rolePrivileges = getRolePrivileges(userId);
        return rolePrivileges.stream().filter(Objects::nonNull).map(RolePrivilegesDto::getRoleName).toList().stream().distinct().toList();
    }

    private List<RolePrivilegesDto> getRolePrivileges(UUID userId) {
        List<DedRoles> dedRoles = dedRolesRepository.findByOid(userId);
        List<Roles> roles = dedRoles.stream().filter(Objects::nonNull).map(dedRoles1 ->
                rolesRepository.findByGroupContaining(dedRoles1.getRole())
        ).toList().stream().distinct().toList();

        return roles.stream().filter(Objects::nonNull).map(roles1 ->
                rolePrivilegesService.findByRoleId(roles1.getId())
        ).toList();
    }


    public String getDisplayName(UUID oid) {
        Optional<AzureUsers> userOptional = azureUserRepository.findById(oid);
        return userOptional.map(AzureUsers::getDisplayName).orElse("");
    }


    public List<String> getPrivilegesForNavBar(UUID oid) {
        List<String> navPrivilegesList = new ArrayList<>();
        String highestRole = getHighestRole(oid, null, null);
        if (highestRole.equalsIgnoreCase("")) {
            navPrivilegesList.add(NO_ACCESS);
            return navPrivilegesList;
        }
        if (highestRole.equalsIgnoreCase(SUPER_ADMIN_)) {
            navPrivilegesList.add(FULL_ACCESS);
            return navPrivilegesList;
        }
        List<String> privileges = utilMethods.getPrivilegesString(highestRole, List.of(ALL));
        if (isPrivilegeMatch(privileges, ACCOUNTS_VIEW_ALL, ACCOUNTS_VIEW_ASSOCIATED)) {
            navPrivilegesList.add(SHOW_ACCOUNTS_TAB);
        }
        if (isPrivilegeMatch(privileges, PROJECTS_VIEW_ALL, PROJECTS_VIEW_ASSOCIATED)) {
            navPrivilegesList.add(SHOW_PROJECTS_TAB);
        }
        if (isPrivilegeMatch(privileges, ASSESSMENTS_VIEW_ALL, ASSESSMENTS_VIEW_ASSOCIATED)) {
            navPrivilegesList.add(SHOW_ASSESSMENTS_TAB);
        }
        if (isPrivilegeMatch(privileges, DASHBOARD_VIEW)) {
            navPrivilegesList.add(SHOW_DASHBOARD_TAB);
        }
        if (navPrivilegesList.isEmpty()) {
            navPrivilegesList.add(NO_ACCESS);
            return navPrivilegesList;
        }
        return navPrivilegesList;
    }


    public static boolean isPrivilegeMatch(List<String> privileges, String... values) {
        return Arrays.stream(values).anyMatch(value -> privileges.stream()
                .anyMatch(privilege -> privilege.equalsIgnoreCase(value)));
    }

    public Set<String> checkAndAddUserId(Set<String> existingUserIds, String userId) {
        if (null == getDisplayName(UUID.fromString(userId))
                ||getDisplayName(UUID.fromString(userId)).isEmpty()) {
            log.error("ProjectServiceImpl::User not found");
            throw new UserNotFoundException("User not found " + userId);
        }

        if (existingUserIds.contains(userId)) {
            log.error("ProjectServiceImpl::existsByAccountName::error");
            throw new DuplicateUserIdException("Multiple roles found for userID " + userId);
        } else {
            existingUserIds.add(userId);
        }

        return existingUserIds;
    }


}
