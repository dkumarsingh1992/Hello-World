package com.maveric.delivery.model.embedded;

import com.maveric.delivery.model.IdentifiedEntity;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "dedRoles")
public class DedRoles extends IdentifiedEntity {

    @NotNull
    private UUID oid;
    private Long accountId;
    private Long projectId;
    private String name;
    @NotNull
    private String role;
}
