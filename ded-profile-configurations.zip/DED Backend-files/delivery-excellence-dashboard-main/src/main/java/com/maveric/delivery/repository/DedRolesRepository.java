package com.maveric.delivery.repository;

import com.maveric.delivery.model.embedded.DedRoles;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface DedRolesRepository extends MongoRepository<DedRoles,Long> {
    List<DedRoles> findByOidAndProjectIdAndAccountId(UUID oid, Long projectId, Long accountId);
    List<DedRoles> findByOid(UUID oid);
    List<DedRoles> findByOidAndAccountId(UUID oid, Long accountId);
    List<DedRoles> findByAccountId(Long accountId);
    List<DedRoles> findByAccountIdAndProjectIdIsNull(Long accountId);
    List<DedRoles> findByAccountIdAndProjectIdIsNotNull(Long accountId);

    List<DedRoles> findByAccountIdAndRoleAndProjectIdIsNull(Long accountId, String role);
    void deleteByAccountIdAndProjectId(Long accountId,Long projectId);
    void deleteByAccountIdAndProjectIdIsNull(Long accountId);


    List<DedRoles> findByOidAndAccountIdAndProjectId(UUID oid, Long accountId, Long projectId);

    Boolean existsByOidAndRole(UUID oid, String role);
}
