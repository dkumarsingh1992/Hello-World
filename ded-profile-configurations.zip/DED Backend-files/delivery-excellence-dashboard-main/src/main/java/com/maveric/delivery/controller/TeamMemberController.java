package com.maveric.delivery.controller;

import com.maveric.delivery.model.Account;
import com.maveric.delivery.model.TeamMember;
import com.maveric.delivery.requestdto.TeamMemberDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.responsedto.TeamMemberResponseDto;
import com.maveric.delivery.responsedto.TeamMemberResponseListDto;
import com.maveric.delivery.service.TeamMemberService;
import com.maveric.delivery.utils.Constants;
import com.maveric.delivery.utils.SuccessMessage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.SUCCESS;


@RestController
@RequestMapping("/v1")
@Slf4j
@RequiredArgsConstructor
public class TeamMemberController {

    private final TeamMemberService teamMemberService;
    @Operation(summary = "Save Team Member")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Saved team member successfully",
                    content = @Content(schema = @Schema(implementation = TeamMember.class))),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(path = "/teamMembers")
    public ResponseEntity<ResponseDto> saveTeamMember(@Valid @RequestBody TeamMemberDto teamMemberDto, HttpServletRequest servletRequest,@RequestParam("projectId") Long projectId) {
        log.info("TeamMemberController::Saving teamMember: {}", teamMemberDto);
        String oid = (String) servletRequest.getAttribute(Constants.O_ID);
        TeamMemberResponseDto createdTeamMember = teamMemberService.saveTeamMember(teamMemberDto,UUID.fromString(oid),projectId);
        log.info("TeamMember saved successfully");
        return ResponseEntity.status(HttpStatus.CREATED).body(new ResponseDto(Constants.SUCCESS, SuccessMessage.TEAM_MEMBER_CREATED.getCode(), SuccessMessage.TEAM_MEMBER_CREATED.getMessage(), null, createdTeamMember));
    }

    @Operation(summary = "Fetch All Team Members")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Fetch team members Successfully",
                    content = @Content(schema = @Schema(implementation = TeamMember.class))),
            @ApiResponse(responseCode = "404", description = "Team Members not Present in DB"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/teamMembers")
    public ResponseEntity<ResponseDto> fetchAllTeamMembers(@RequestParam("projectId") Long projectId,HttpServletRequest servletRequest) {
        log.info("TeamMemberController::fetchAllTeamMembers() started");
        List<TeamMemberResponseListDto> teamMemberList=teamMemberService.getAllTeamMembers(projectId);
        log.info("TeamMemberController::fetchAllTeamMembers() ended");
        return ResponseEntity.ok(new ResponseDto(Constants.SUCCESS, SuccessMessage.TEAM_MEMBER_LIST_FETCHED.getCode(), SuccessMessage.TEAM_MEMBER_LIST_FETCHED.getMessage(),null, teamMemberList));
    }
    @Operation(summary = "Get By Team Member Id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Team Member found by ID",
                    content = @Content(schema = @Schema(implementation = TeamMember.class))),
            @ApiResponse(responseCode = "404", description = "TeamMember not found for the given ID")
    })
    @GetMapping(path = "/teamMembers/{teamMemberId}")
    public ResponseEntity<ResponseDto> getTeamMemberById(HttpServletRequest servletRequest, @PathVariable Long teamMemberId) {
        log.info("TeamMemberController::Fetching TeamMember by ID: {}", teamMemberId);
        TeamMemberResponseListDto teamMemberResponse = teamMemberService.getTeamMemberById(teamMemberId);
        log.info("TeamMemberController::getTeamMemberById::Ended");
        return ResponseEntity.status(HttpStatus.OK)
                .body(new ResponseDto(SUCCESS, SuccessMessage.FETCH_TEAM_MEMBER.getCode(),SuccessMessage.FETCH_TEAM_MEMBER.getMessage(), null, teamMemberResponse));

    }


    @Operation(summary = "Edit Team Member")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Team Member edited successfully",
                    content = @Content(schema = @Schema(implementation = Account.class))),
            @ApiResponse(responseCode = "404", description = "Team Member not found for the given ID"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PutMapping(path = "/teamMembers/{teamMemberId}")
    public ResponseEntity<ResponseDto> editTeamMember(HttpServletRequest servletRequest, @RequestBody TeamMemberDto teamMemberDto, @PathVariable Long teamMemberId) {
        log.info("TeamMemberController::Editing teamMember with ID: {}, {}", teamMemberId, teamMemberDto);
        String oid = (String) servletRequest.getAttribute(Constants.O_ID);
        TeamMemberResponseDto editTeamMember = teamMemberService.editTeamMember(teamMemberDto,UUID.fromString(oid),teamMemberId);
        log.info("teamMember edited successfully");
        return ResponseEntity.status(HttpStatus.OK)
                .body(new ResponseDto(Constants.SUCCESS, SuccessMessage.UPDATE_TEAM_MEMBER_DETAILS.getCode(),SuccessMessage.UPDATE_TEAM_MEMBER_DETAILS.getMessage(), null, editTeamMember));
    }
}
