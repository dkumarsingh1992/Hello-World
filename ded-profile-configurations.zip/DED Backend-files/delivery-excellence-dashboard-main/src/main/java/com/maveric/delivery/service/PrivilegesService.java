package com.maveric.delivery.service;

import com.maveric.delivery.requestdto.PrivilegesDto;

import java.util.List;

public interface PrivilegesService {

    List<PrivilegesDto> getPrivileges();
}
