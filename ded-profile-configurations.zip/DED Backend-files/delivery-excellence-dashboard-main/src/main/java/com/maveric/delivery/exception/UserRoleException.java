package com.maveric.delivery.exception;

public class UserRoleException extends RuntimeException {
    public UserRoleException(String message) {
        super(message);
    }
}
