package com.maveric.delivery.service;

import com.maveric.delivery.requestdto.PrivilegesDto;
import com.maveric.delivery.requestdto.RolePrivilegesDto;
import jakarta.validation.Valid;

import java.util.List;

public interface RolePrivilegesService {

    List<RolePrivilegesDto> save(@Valid List<RolePrivilegesDto> rolePrivilegesDto);

    List<RolePrivilegesDto> findAll();

    RolePrivilegesDto findByRoleId(Long roleId);

    List<PrivilegesDto> findByGroup(List<String> type, String userGroup);

    RolePrivilegesDto  findByName(String name);

    List<PrivilegesDto> findByName(List<String> type, String name);

}
