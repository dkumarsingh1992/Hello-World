package com.maveric.delivery.utils;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;

public class CustomAuthToken extends AbstractAuthenticationToken {

    private final Object credentials;

    public CustomAuthToken(Object credentials){
        super(null);
        this.credentials = credentials;
        this.setAuthenticated(false);
    }
    public CustomAuthToken(Object credentials, Collection<? extends GrantedAuthority> authorities){
        super(authorities);
        this.credentials = credentials;
        this.setAuthenticated(true);
    }
    @Override
    public Object getCredentials() {
        return credentials;
    }

    @Override
    public Object getPrincipal() {
        return null;
    }


}
