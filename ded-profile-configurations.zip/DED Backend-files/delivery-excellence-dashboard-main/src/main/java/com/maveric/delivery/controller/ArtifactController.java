package com.maveric.delivery.controller;


import com.maveric.delivery.model.Artifact;
import com.maveric.delivery.requestdto.ArtifactDto;
import com.maveric.delivery.requestdto.ArtifactRequestDto;
import com.maveric.delivery.responsedto.ArtifactDownloadDto;
import com.maveric.delivery.responsedto.ArtifactListDto;
import com.maveric.delivery.responsedto.BaseDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.ArtifactService;
import com.maveric.delivery.utils.Constants;
import com.maveric.delivery.utils.SuccessMessage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.naming.directory.InvalidAttributesException;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.maveric.delivery.utils.Constants.SUCCESS;

@RestController
@RequestMapping("/v1")
@Slf4j
@RequiredArgsConstructor
public class ArtifactController {
    private final ArtifactService artifactService;

    @Operation(summary = "Fetch All Artifacts")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Fetch Artifacts Successfully",
                    content = @Content(schema = @Schema(implementation = BaseDto.class))),
            @ApiResponse(responseCode = "404", description = "Artifacts not Present in DB"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "/artifacts")
    public ResponseEntity<ResponseDto> fetchAllArtifacts(HttpServletRequest servletRequest, @RequestParam("projectId") Long projectId) {
        log.info("ArtifactController::FetchAllArtifacts() started");
        String oid = (String) servletRequest.getAttribute("oid");
        List<ArtifactListDto> artifactListList=artifactService.getAllArtifacts(UUID.fromString(oid),projectId);
        log.info("ArtifactController::FetchAllArtifacts() ended");
        return ResponseEntity.ok(new ResponseDto(SUCCESS, SuccessMessage.ARTIFACT_LIST_FETCHED.getCode(), SuccessMessage.ARTIFACT_LIST_FETCHED.getMessage(),null, artifactListList));
    }

    @Operation(summary = "Delete Artifact")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Artifact deleted successfully",
                    content = @Content(schema = @Schema(implementation = Artifact.class))),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @DeleteMapping(path = "/artifacts")
    public ResponseEntity<ResponseDto> deleteArtifact( @RequestParam("artifactId") Long artifactId,@RequestParam("attachmentId")Long attachmentId) {
        log.info("ArtifactController::deleteArtifact() started");
        UUID userId=UUID.fromString("9d7a0f89-113a-4878-830a-d50c4595888b");
        artifactService.deleteArtifact(userId,artifactId);
        log.info("ArtifactController::deleteArtifact() ended");
        return ResponseEntity.ok(new ResponseDto(SUCCESS, SuccessMessage.ARTIFACT_DELETED.getCode(), SuccessMessage.ARTIFACT_DELETED.getMessage(),null, null));
    }

    @Operation(summary = "Save Artifact")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Saved artifact successfully",
                    content = @Content(schema = @Schema(implementation = Artifact.class))),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @PostMapping(path = "/artifacts")
    public ResponseEntity<ResponseDto> saveArtifact(HttpServletRequest servletRequest,@Valid @RequestBody ArtifactRequestDto artifactRequestDto,@RequestParam("projectId") Long projectId) throws InvalidAttributesException, IOException {
        log.info("ArtifactController::Saving artifacts: {}");
        String oid = (String) servletRequest.getAttribute("oid");
        ArtifactListDto createdArtifact = artifactService.saveArtifact(artifactRequestDto,UUID.fromString(oid),projectId);
        log.info("Artifact saved successfully");
        return ResponseEntity.status(HttpStatus.CREATED).body(new ResponseDto(Constants.SUCCESS, SuccessMessage.ARTIFACT_CREATED.getCode(), SuccessMessage.ARTIFACT_CREATED.getMessage(), null, createdArtifact));
    }
    @Operation(summary = "Download Artifact")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Artifact downloaded successfully",
                    content = @Content(schema = @Schema(implementation = Artifact.class))),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "artifacts/{artifactId}/attachment-download")
    public ResponseEntity<Resource> downloadArtifact(HttpServletRequest servletRequest, @PathVariable("artifactId") Long artifactId) throws InvalidAttributesException, IOException {
        log.info("ArtifactController::Download artifacts: {}");
        ArtifactDownloadDto downloadedArtifact = artifactService.getAttachmentDetails(artifactId);
        log.info("Artifact download successfully");
        return ResponseEntity.ok().contentType(MediaType.valueOf(downloadedArtifact.getType())).header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + downloadedArtifact.getName() + "\"") .body((new InputStreamResource(downloadedArtifact.getDownloadedInputStream()) ));
    }


    @Operation(summary = "Delete Artifact")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Artifact deleted successfully",
                    content = @Content(schema = @Schema(implementation = Artifact.class))),
            @ApiResponse(responseCode = "400", description = "Validation error"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "artifacts/{artifactId}/attachment-delete")
    public ResponseEntity<ResponseDto> deleteArtifact(HttpServletRequest servletRequest, @PathVariable("artifactId") Long artifactId) throws InvalidAttributesException, IOException {
        log.info("ArtifactController::Download artifacts: {}");
        ArtifactListDto deletedAttachment = artifactService.checkAndDeleteAttachment(artifactId);
        log.info("Artifact download successfully");
        return ResponseEntity.status(HttpStatus.CREATED).body(new ResponseDto(Constants.SUCCESS, SuccessMessage.ARTIFACT_DELETED.getCode(), SuccessMessage.ARTIFACT_DELETED.getMessage(), null, deletedAttachment));
    }

}
