package com.maveric.delivery.service;

import com.maveric.delivery.requestdto.ProjectRequestDto;
import com.maveric.delivery.requestdto.ProjectsListDto;
import com.maveric.delivery.responsedto.ProjectListResponseDto;
import com.maveric.delivery.responsedto.ProjectResponseDto;

import java.util.List;
import java.util.UUID;

public interface ProjectService {
  ProjectResponseDto saveProject(ProjectRequestDto projectDto);
  ProjectResponseDto editProject(ProjectRequestDto projectDto,Long projectId);
  ProjectResponseDto getProjectById(Long projectId,UUID oid);
  boolean validateProjectName(Long accountId,String value);

  ProjectsListDto getProjectDetailsList(UUID oid, Long accountId);

}
