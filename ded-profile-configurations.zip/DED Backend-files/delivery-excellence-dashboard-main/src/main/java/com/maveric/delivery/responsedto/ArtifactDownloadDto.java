package com.maveric.delivery.responsedto;

import com.maveric.delivery.model.embedded.AccountStatus;
import com.maveric.delivery.model.embedded.AccountType;
import com.maveric.delivery.model.embedded.ClientInformation;
import com.maveric.delivery.requestdto.AccountRoles;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.InputStream;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ArtifactDownloadDto {
    private String name;
    private String type;
    private InputStream downloadedInputStream;
}
