package com.maveric.delivery.service;

import com.maveric.delivery.exception.AssessmentException;
import com.maveric.delivery.exception.CustomException;
import com.maveric.delivery.model.Assessment;
import com.maveric.delivery.model.embedded.*;
import com.maveric.delivery.repository.AssessmentRepository;
import com.maveric.delivery.repository.DedRolesRepository;
import com.maveric.delivery.requestdto.AssessmentSectionWiseRequestDto;
import com.maveric.delivery.requestdto.MyAssessmentDto;
import com.maveric.delivery.responsedto.AssessmentResponseDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;

import static com.maveric.delivery.utils.Constants.DP;

@Service
@RequiredArgsConstructor
@Slf4j
public class AssessmentService {

    private final AssessmentRepository assessmentRepository;
    private final DedRolesRepository dedRolesRepository;

    public TemplateCategory saveAssessment(AssessmentSectionWiseRequestDto sectionWiseRequestDto,Long assessmentId,Long projectId){
        Optional<Assessment> assessmentOptional =assessmentRepository.findById(assessmentId);
        if(assessmentOptional.isPresent()){
            Assessment assessment = assessmentOptional.get();
            if(validateAssessmentStatus(assessment.getStatus())) {
                TemplateCategory templateCategory = new TemplateCategory();
                BeanUtils.copyProperties(sectionWiseRequestDto, templateCategory);
                List<TemplateCategory> templateCategoryList = assessment.getTemplateCategory();
                for (TemplateCategory category : templateCategoryList) {
                    if (category.getName().equals(sectionWiseRequestDto.getName())) {
                        //validate questions
                        validateAndUpdateTemplateCategory(category, templateCategoryList, templateCategory);
                        break;
                    }
                }
                assessment.setTemplateCategory(templateCategoryList);
                if(sectionWiseRequestDto.getSubmitAssessment()){
                    long epochMilli = LocalDate.now().atStartOfDay(ZoneId.systemDefault())
                                            .toInstant().toEpochMilli();
                    assessment.setSubmittedOn(epochMilli);
                    assessment.setStatus(AssessmentStatus.SUBMITTED);
                }
                assessmentRepository.save(assessment);
                log.info("User response saved successfully for - " + sectionWiseRequestDto.getName());
                return templateCategory;
            }else {
                throw new CustomException("Assessment status is not valid for edit ",HttpStatus.FORBIDDEN);
            }
        }
        else {
            throw new CustomException("Assessment Id not Found", HttpStatus.NOT_FOUND);
        }
    }

    private void validateAndUpdateTemplateCategory(TemplateCategory category,
                                                   List<TemplateCategory> templateCategoryList,
                                                   TemplateCategory templateCategory) {
        log.info("Question level validation started");
        if(category.getQuestions().size() != templateCategory.getQuestions().size()){
            throw new AssessmentException("Request question size is not matching with assessment question");
        }else {
            category.getQuestions().sort(Comparator.comparing(Question::getNumber));
            templateCategory.getQuestions().sort(Comparator.comparing(Question::getNumber));
            for (int i = 0; i < category.getQuestions().size(); i++) {
                String text1 = category.getQuestions().get(i).getQuestionText().trim();
                String text2 = templateCategory.getQuestions().get(i).getQuestionText().trim();
                if(!text1.equals(text2)){
                    throw new AssessmentException("Question text is not matching with assessment question");
                } else if (!category.getQuestions().get(i).getType().
                        equals(templateCategory.getQuestions().get(i).getType())) {
                    throw new AssessmentException("Question type is not matching with assessment question");
                }
                validateUserResponse(templateCategory.getQuestions().get(i));
            }
        }
        templateCategoryList.remove(category);
        templateCategoryList.add(templateCategory);
        log.info("Question level validation completed");
    }

    private void validateUserResponse(Question question){
        if(question.getType().equals(QuestionType.CHECK_BOX) || question.getType().equals(QuestionType.RADIO_BUTTON)){
            List<Option> optionList = question.getType().equals(QuestionType.CHECK_BOX) ?
                    question.getCheckBoxOptions().getOptions() :question.getRadioOptions().getOptions();
            boolean userResponded = false;
            for(Option option : optionList){
                userResponded = option.isSelected();
                if(userResponded){
                    break;
                }
            }
            if(!userResponded){
                throw new AssessmentException("User should select any one of the option");
            }
        }else if(question.getType().equals(QuestionType.NUMERICAL)){
            Numerical response = question.getNumerical();
            validateNumericalResponse(response.getMax(), response.getMin(), response.getValue());
        }else {
            Slider response = question.getSlider();
            validateNumericalResponse(response.getMax(), response.getMin(), response.getValue());
        }

        validateAttachment(question);
    }

    private void validateNumericalResponse(Integer max,Integer min,Double value) {
        if(value> max || value < min){
            throw new AssessmentException("User responded value is not acceptable");
        }
    }

    private void validateAttachment(Question question){
        if(question.isAttachmentRequired()){
            if(question.getAttachmentPath().isBlank() || question.getFileName().isBlank()
                    || question.getDocumentId() == null){

                throw new AssessmentException("Attached documents details are missing");
            }
        }
    }

    public AssessmentResponseDto fetchAssessment(Long assessmentId,Long projectId){
        Optional<Assessment> assessmentOptional =assessmentRepository.findById(assessmentId);
        if(assessmentOptional.isPresent()){
            AssessmentResponseDto assessmentResponseDto = new AssessmentResponseDto();
            BeanUtils.copyProperties(assessmentOptional.get(),assessmentResponseDto);
            assessmentResponseDto.setAssessmentId(assessmentId);
            return assessmentResponseDto;
        }else {
            throw new CustomException("Assessment Id not Found", HttpStatus.NOT_FOUND);
        }
    }

    public MyAssessmentDto fetchMyAssessment(UUID userId){
        MyAssessmentDto myAssessmentDto=new MyAssessmentDto();
        List<Assessment> assessmentList = assessmentRepository.findByUserId(userId);
        List<AssessmentResponseDto> assessmentResponseDtoList = new ArrayList<>();
        if(!assessmentList.isEmpty()){
            AssessmentResponseDto assessmentResponseDto;
            for(Assessment assessment : assessmentList){
                assessmentResponseDto = new AssessmentResponseDto();
                BeanUtils.copyProperties(assessment,assessmentResponseDto);
                assessmentResponseDto.setTemplateCategory(null);
                assessmentResponseDto.setAssessmentId(assessment.getId());
                assessmentResponseDtoList.add(assessmentResponseDto);
            }
        }
        myAssessmentDto.setAssessmentResponseDtoList(assessmentResponseDtoList);
        myAssessmentDto.setShowReviewAssessmentTab(dedRolesRepository.existsByOidAndRole(userId,DP));
        return myAssessmentDto;
    }

    public List<AssessmentResponseDto> fetchReviewerAssessment(UUID userId){
        List<Assessment> assessmentList = assessmentRepository.findByReviewerId(userId);
        List<AssessmentResponseDto> assessmentResponseDtoList = new ArrayList<>();
        if(!assessmentList.isEmpty()){
            AssessmentResponseDto assessmentResponseDto;
            for(Assessment assessment : assessmentList){
                if(assessment.getStatus().equals(AssessmentStatus.REVIEWED)|| assessment.getStatus().equals(AssessmentStatus.SUBMITTED)){
                    assessmentResponseDto = new AssessmentResponseDto();
                    BeanUtils.copyProperties(assessment,assessmentResponseDto);
                    assessmentResponseDto.setTemplateCategory(null);
                    assessmentResponseDto.setAssessmentId(assessment.getId());
                    assessmentResponseDtoList.add(assessmentResponseDto);
                }
            }
        }
        return assessmentResponseDtoList;
    }

    public List<AssessmentResponseDto> fetchAllAssessment(UUID userId){
        List<Assessment> assessmentList = assessmentRepository.findAll();
        List<AssessmentResponseDto> assessmentResponseDtoList = new ArrayList<>();
        if(!assessmentList.isEmpty()){
            AssessmentResponseDto assessmentResponseDto ;
            for(Assessment assessment : assessmentList){
                assessmentResponseDto = new AssessmentResponseDto();
                BeanUtils.copyProperties(assessment,assessmentResponseDto);
                assessmentResponseDto.setTemplateCategory(null);
                assessmentResponseDto.setAssessmentId(assessment.getId());
                assessmentResponseDtoList.add(assessmentResponseDto);
            }
        }
        return assessmentResponseDtoList;
    }

    public boolean validateAssessmentStatus(AssessmentStatus assessmentStatus){
        return assessmentStatus.equals(AssessmentStatus.IN_PROGRESS) ||
                assessmentStatus.equals(AssessmentStatus.PENDING) || assessmentStatus.equals(AssessmentStatus.OVERDUE);

    }

}
