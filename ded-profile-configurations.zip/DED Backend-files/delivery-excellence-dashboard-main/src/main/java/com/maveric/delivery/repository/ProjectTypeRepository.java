package com.maveric.delivery.repository;

import com.maveric.delivery.model.ProjectType;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProjectTypeRepository extends MongoRepository<ProjectType,Long> {


}
