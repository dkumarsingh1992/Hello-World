package com.maveric.delivery.repository;

import com.maveric.delivery.model.ProjectStatus;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProjectStatusRepository extends MongoRepository<ProjectStatus,Long> {
}
