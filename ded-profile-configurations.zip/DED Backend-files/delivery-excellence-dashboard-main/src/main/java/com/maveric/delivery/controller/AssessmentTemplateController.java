package com.maveric.delivery.controller;

import com.maveric.delivery.model.AssessmentTemplate;
import com.maveric.delivery.responsedto.BaseDto;
import com.maveric.delivery.responsedto.ResponseDto;
import com.maveric.delivery.service.AssessmentTemplateService;
import com.maveric.delivery.utils.FailedMessage;
import com.maveric.delivery.utils.SuccessMessage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.websocket.server.PathParam;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static com.maveric.delivery.utils.Constants.FAILED;
import static com.maveric.delivery.utils.Constants.SUCCESS;

@RestController
@RequestMapping("/v1")
@Slf4j
@RequiredArgsConstructor
public class AssessmentTemplateController {

    private final AssessmentTemplateService assessmentTemplateService;
    @Operation(summary = "Fetch All Assessment Templates")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Template fetched successfully",
                    content = @Content(schema = @Schema(implementation = BaseDto.class))),
            @ApiResponse(responseCode = "404", description = "Templates Present not Available"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping(path = "assessments/templates")
    public ResponseEntity<ResponseDto> fetchAllTemplates(@PathParam("type") String type) {
        log.info("AssessmentTemplateController::FetchAllTemplates() started");
        List<AssessmentTemplate> assessmentTemplates=assessmentTemplateService.getAllTemplates(type);
        if (CollectionUtils.isEmpty(assessmentTemplates)) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new ResponseDto(FAILED, FailedMessage.FETCHED_ASSESSMENT_TEMPLATES_FAILED.getCode(), FailedMessage.FETCHED_ASSESSMENT_TEMPLATES_FAILED.getMessage(),null, assessmentTemplates));
        }
        log.info("BasedController::FetchAllType() ended");
        return ResponseEntity.ok(new ResponseDto(SUCCESS, SuccessMessage.FETCHED_ASSESSMENT_TEMPLATES.getCode(), SuccessMessage.FETCHED_ASSESSMENT_TEMPLATES.getMessage(),null, assessmentTemplates));
    }
}
