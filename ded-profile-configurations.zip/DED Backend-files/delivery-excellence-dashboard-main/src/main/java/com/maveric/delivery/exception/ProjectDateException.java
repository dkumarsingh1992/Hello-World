package com.maveric.delivery.exception;

public class ProjectDateException extends RuntimeException{
    public ProjectDateException(String message) {
        super(message);
    }
}
