package com.maveric.delivery.service;

import com.fasterxml.jackson.core.JsonProcessingException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.delivery.exception.ArtifactNotFoundException;
import com.maveric.delivery.exception.UserNotFoundException;
import com.maveric.delivery.model.Artifact;
import com.maveric.delivery.model.Attachment;
import com.maveric.delivery.model.AzureUsers;
import com.maveric.delivery.repository.AccountRepository;
import com.maveric.delivery.repository.ArtifactRepository;
import com.maveric.delivery.repository.AzureUserRepository;
import com.maveric.delivery.requestdto.*;
import com.maveric.delivery.responsedto.ArtifactDownloadDto;
import com.maveric.delivery.responsedto.ArtifactListDto;

import com.maveric.delivery.utils.SharepointUtils;
import com.microsoft.graph.models.DriveItem;
import com.microsoft.graph.models.Sharepoint;
import com.microsoft.graph.serviceclient.GraphServiceClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class ArtifactServiceImpl implements ArtifactService {

    private final ArtifactRepository artifactRepository;
    private final AzureUserRepository azureUserRepository;
    private final UserServiceImpl userService;
   private final SharepointUtils sharepointUtils;


    @Override
    public ArtifactListDto saveArtifact( ArtifactRequestDto artifactRequestDto,UUID oid,Long projectId) throws IOException {
        log.info("ArtifactServiceImpl::saveArtifact:: call started");
        isValidInput(artifactRequestDto);
        checkUserAuthenticity(oid);
        if(StringUtils.isNotBlank(artifactRequestDto.getLink())){
            log.info("ArtifactServiceImpl::saveArtifact:: call ended");
            return setPropertiesForLink(artifactRequestDto,oid,projectId);
        }


        int index=artifactRequestDto.getAttachment().getName().lastIndexOf('.');
        String fileName=artifactRequestDto.getName()+"_"+System.currentTimeMillis()+artifactRequestDto.getAttachment().getName().substring(index,artifactRequestDto.getAttachment().getName().length());
        ResponseEntity<DriveItem> response =sharepointUtils.uploadFile(artifactRequestDto.getAttachment().getType(),fileName,artifactRequestDto.getAttachment().getMultipartFile());
        if(response.getStatusCode().is2xxSuccessful()){
            Artifact artifact = new Artifact();
            Attachment attachment=new Attachment();

            attachment.setName(artifactRequestDto.getAttachment().getName());
            attachment.setType(artifactRequestDto.getAttachment().getType());
            attachment.setSharepointId(response.getBody().getId());
            artifact.setCreatedAt(System.currentTimeMillis());
            artifact.setCreatorName(getUserName(oid));
            artifact.setCreatedBy(oid);
            artifact.setName(artifactRequestDto.getName());
            artifact.setType(artifactRequestDto.getType());
            artifact.setAttachment(attachment);
            artifact.setProjectId(projectId);
            artifact.setComments(artifactRequestDto.getComments());

            Artifact artifactResponse;
            ArtifactListDto responseDto=new ArtifactListDto();
            artifactResponse=artifactRepository.save(artifact);
            responseDto= setResponse(artifactResponse,responseDto);
            log.info("ArtifactServiceImpl::saveArtifact:: call ended");
            return responseDto;
        }
        else throw new FileNotFoundException("File not saved");



    }

    void isValidInput(ArtifactRequestDto artifactDto){
        if (artifactDto.getLink() == null && ((artifactDto.getAttachment().getType() == null)||(artifactDto.getAttachment().getMultipartFile() == null)||(artifactDto.getAttachment().getName() == null))) {
            throw new IllegalArgumentException("Either attachment or link should be available in the request ");
        }
        if (artifactDto.getLink() != null && artifactDto.getAttachment()!= null){
            throw new IllegalArgumentException("Either attachment or link should be available in the request ");
        }


    }




    String getUserName(UUID oid)  {
        log.info("ArtifactServiceImpl::getUserName:: call started");
        String username=null;
        List<UserDto> userDtoList=userService.getAllUsers();
        for(UserDto user:userDtoList){
            if(user.getOid().equals(oid)){
                username=user.getName();
                break;
            }
        }
        if(username==null){
            throw  new IllegalArgumentException("No data for given UserId");
        }
        return  username;
    }

    @Override
    public List<ArtifactListDto> getAllArtifacts(UUID userId,Long projectId) {
        log.info("ArtifactServiceImpl::getAllArtifacts:: call started");
        checkUserAuthenticity(userId);
        List<Artifact> artifactList=artifactRepository.findByProjectId(projectId);
        log.info("ArtifactServiceImpl::getAllArtifacts:: call ended");
        List<ArtifactListDto> artifactListDto=toArtifactListDtosList(artifactList,userId);
        return artifactListDto;

    }

    public String getDisplayName(UUID oid) {
        Optional<AzureUsers> userOptional = azureUserRepository.findById(oid);
        return userOptional.map(AzureUsers::getDisplayName).orElse("");
    }

    void checkUserAuthenticity(UUID userId) {
        String userName = getDisplayName(userId);
        if (null == userName
                || userName.isEmpty()) {
            log.error("ArtifactServiceImpl::User not found");
            throw new UserNotFoundException(":User not found " + userId);
        }
    }
    @Override
    public void deleteArtifact(UUID userId, Long artifactId) {
        log.info("ArtifactServiceImpl::deleteArtifact:: call started");
        checkUserAuthenticity(userId);
        List<Artifact> artifactsList = artifactRepository.findByIdAndCreatedBy(artifactId,userId);
        if (!artifactsList.isEmpty() || userHasDeleteAccess(userId)) {
            artifactRepository.deleteById(artifactId);
        } else {
            throw new UserNotFoundException("Artifact not found or this user cannot delete it");
        }
        log.info("ArtifactServiceImpl::deleteArtifact:: call ended");
    }

    @Override
    public ArtifactDownloadDto getAttachmentDetails(Long artifactId)  {
        Optional<Artifact>artifacts=artifactRepository.findById(artifactId);
        if(artifacts.isEmpty()){
            log.error("ArtifactServiceImpl::validateProjectName:: artifacts not found");
            throw new ArtifactNotFoundException("Account ID "+artifacts+" not found");
        }
        Artifact artifact = artifacts.get();
        ArtifactDownloadDto artifactDownloadDto=new ArtifactDownloadDto();
        artifactDownloadDto.setName(artifact.getAttachment().getName());
        artifactDownloadDto.setType(artifact.getAttachment().getType());
        artifactDownloadDto.setDownloadedInputStream(sharepointUtils.downloadFile(artifact.getAttachment().getSharepointId()));
        return artifactDownloadDto;

    }

    @Override
    public ArtifactListDto checkAndDeleteAttachment(Long artifactId) {

        Optional<Artifact>artifacts=artifactRepository.findById(artifactId);


        if(artifacts.isEmpty()){
            log.error("ArtifactServiceImpl::validateProjectName:: artifacts not found");
            throw new ArtifactNotFoundException("Account ID "+artifacts+" not found");
        }
        Artifact artifact = artifacts.get();
        sharepointUtils.deleteFile(artifacts.get().getAttachment().getSharepointId());
        artifactRepository.deleteById(artifactId);
        ArtifactListDto artifactListDto=new ArtifactListDto();
        BeanUtils.copyProperties(artifact,artifactListDto);
        AttachmentDto attachment=new AttachmentDto();
        BeanUtils.copyProperties(artifact.getAttachment(),attachment);
        artifactListDto.setAttachment(attachment);

        return artifactListDto;
        }



    private boolean userHasDeleteAccess(UUID userId){
        return true;
    }

    private List<ArtifactListDto> toArtifactListDtosList(List<Artifact> artifacts, UUID userId) {
        return artifacts.stream()
                .map(artifact -> toArtifactListDto(artifact, userId))
                .toList();
    }
    ArtifactListDto toArtifactListDto(Artifact artifact,UUID userId) {
        ArtifactListDto dto=new ArtifactListDto();
        AttachmentDto attachmentDto=new AttachmentDto();

        attachmentDto.setName(artifact.getAttachment().getName());
        dto.setId(artifact.getId());
        dto.setName(artifact.getName());
        dto.setType(artifact.getType());
        dto.setAttachment(attachmentDto);
        dto.setLink(artifact.getLink());
        dto.setComments(artifact.getComments());
        dto.setCreatedAt(artifact.getCreatedAt());
        dto.setCreatedBy(artifact.getCreatedBy());
        dto.setCreatorName(artifact.getCreatorName());
        if(userId.equals(artifact.getCreatedBy())) {
            dto.setIsDelete(true);
        }else {
            dto.setIsDelete(false);
        }
        return dto;
    }


    public ArtifactListDto setResponse(Artifact artifactResponse,ArtifactListDto responseDto){
        AttachmentDto attachmentDto=new AttachmentDto();
        attachmentDto.setName(artifactResponse.getAttachment().getName());

        attachmentDto.setType(artifactResponse.getAttachment().getType());
        responseDto.setAttachment(attachmentDto);
        responseDto.setComments(artifactResponse.getComments());
        responseDto.setName(artifactResponse.getName());
        responseDto.setType(artifactResponse.getType());
        responseDto.setId(artifactResponse.getId());
        responseDto.setCreatedBy(artifactResponse.getCreatedBy());
        responseDto.setCreatorName(artifactResponse.getCreatorName());
        responseDto.setCreatedAt(artifactResponse.getCreatedAt());
        return responseDto;

    }
    public ArtifactListDto setPropertiesForLink(ArtifactRequestDto artifactRequestDto,UUID oid,Long projectId){
        Artifact artifact = new Artifact();
        BeanUtils.copyProperties(artifactRequestDto, artifact);
        artifact.setCreatedAt(System.currentTimeMillis());
        artifact.setCreatorName(getUserName(oid));
        artifact.setCreatedBy(oid);
        artifact.setProjectId(projectId);
        Artifact artifactResponse;
        ArtifactListDto responseDto=new ArtifactListDto();
        artifactResponse=artifactRepository.save(artifact);
        BeanUtils.copyProperties(artifactResponse,responseDto);
        return responseDto;
    }
}
