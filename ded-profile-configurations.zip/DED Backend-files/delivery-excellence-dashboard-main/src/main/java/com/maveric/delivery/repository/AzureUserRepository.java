package com.maveric.delivery.repository;

import com.maveric.delivery.model.AzureUsers;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.UUID;

public interface AzureUserRepository extends MongoRepository<AzureUsers, UUID> {
}
