package com.maveric.delivery.responsedto;

import com.maveric.delivery.model.embedded.AssessmentStatus;
import com.maveric.delivery.model.embedded.TemplateCategory;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AssessmentResponseDto {
    private Long assessmentId;
    private Long accountId;
    private UUID userId;
    private String accountName;
    private Long projectId;
    private String projectName;
    private AssessmentStatus status;
    private Long initiatedOn;
    private Long dueOn;
    private Long submittedOn;
    private String reviewerName;
    private UUID reviewerId;
    private Double score;
    private List<TemplateCategory> templateCategory;
    private String overallComment;
}
