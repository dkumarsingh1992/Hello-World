package com.maveric.delivery.utils;

import com.maveric.delivery.exception.PermissionDeniedException;
import com.maveric.delivery.requestdto.DedRolesDto;
import com.maveric.delivery.requestdto.PrivilegesDto;
import com.maveric.delivery.requestdto.RolePrivilegesDto;
import com.maveric.delivery.service.RolePrivilegesService;
import com.maveric.delivery.service.UserServiceImpl;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

import static com.maveric.delivery.utils.Constants.*;

@Component
@RequiredArgsConstructor
@Slf4j
public class ValidateApiAccess {

    private final RolePrivilegesService rolePrivilegesService;
    private final UserServiceImpl userService;

    @Value("${role.enabled}")
    private boolean isRoleEnabled;

    public void isAccessible(DedRolesDto rolesDto, String module, String... privileges) {

        log.debug("Role Enabled :{}", isRoleEnabled);
        if (isRoleEnabled) {
            AtomicBoolean isAccessible = new AtomicBoolean(false);
            UUID userId = rolesDto.getOid();
            Long accountId = rolesDto.getAccountId();
            Long projectId = rolesDto.getProjectId();
            log.debug("ValidateApiAccess.isAccessible: user:{} Account :{}, Project:{} -> Module :{} privileges:{}", userId, accountId, projectId, module, privileges);
            String role = userService.getHighestRole(userId, null, null);
            RolePrivilegesDto rolePrivilegesDto = rolePrivilegesService.findByName(role);
            if (Objects.isNull(rolePrivilegesDto) || StringUtils.isEmpty(rolePrivilegesDto.getRoleName()))
                throw new PermissionDeniedException(FailedMessage.DATA_NOT_FOUND.getMessage().replace("<DATA>", "Roles"), FailedMessage.DATA_NOT_FOUND.getCode());

            List<PrivilegesDto> privilegesDtos = rolePrivilegesDto.getPrivileges();
            log.debug("ValidateApiAccess.isAccessible: user:{} Role :{} ", userId, role);
            if (CollectionUtils.isEmpty(privilegesDtos))
                throw new PermissionDeniedException(FailedMessage.DATA_NOT_FOUND.getMessage().replace("<DATA>", "Privileges"), FailedMessage.DATA_NOT_FOUND.getCode());

            switch (role) {
                case SUPER_ADMIN_ -> isAccessible.set(true);
                case ACCOUNT_ADMIN_, PROJECT_ADMIN_, DELIVERY_OWNER_, ORGANIZATION_LEADER_, TEAM_MEMBER_ ->
                        isAccessible.set(validate(privilegesDtos, module, privileges));
            }
            if (!isAccessible.get())
                throw new PermissionDeniedException(FailedMessage.PERMISSION_DENIED.getMessage(), FailedMessage.PERMISSION_DENIED.getCode());
        }
    }

    private boolean validate(List<PrivilegesDto> privilegesDtos, String module, String... action) {
        return privilegesDtos.stream().filter(Objects::nonNull).filter(privilegesDto -> privilegesDto.getName().equalsIgnoreCase(module)).findAny().map(privilegesDto -> privilegesDto.getPrivileges().stream().anyMatch(s -> Arrays.stream(action).toList().contains(s))).orElse(false);
    }

}

