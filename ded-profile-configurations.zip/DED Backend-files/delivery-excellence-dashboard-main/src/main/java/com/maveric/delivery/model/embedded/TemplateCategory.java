package com.maveric.delivery.model.embedded;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TemplateCategory {

    private AssessmentCategoryType name;
    private List<Question> questions;
}
