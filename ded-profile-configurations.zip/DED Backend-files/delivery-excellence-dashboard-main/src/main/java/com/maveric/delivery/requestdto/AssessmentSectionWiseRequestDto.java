package com.maveric.delivery.requestdto;

import com.maveric.delivery.model.embedded.AssessmentCategoryType;
import com.maveric.delivery.model.embedded.Question;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AssessmentSectionWiseRequestDto {

    private AssessmentCategoryType name;
    private Boolean submitAssessment;
    @Valid
    private List<Question> questions;
}
