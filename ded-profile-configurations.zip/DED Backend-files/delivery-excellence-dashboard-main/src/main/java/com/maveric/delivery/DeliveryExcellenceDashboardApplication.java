package com.maveric.delivery;

import io.mongock.runner.springboot.EnableMongock;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@EnableMongock
@EnableCaching
public class DeliveryExcellenceDashboardApplication {
	public static void main(String[] args) {
		SpringApplication.run(DeliveryExcellenceDashboardApplication.class, args);
	}

}
