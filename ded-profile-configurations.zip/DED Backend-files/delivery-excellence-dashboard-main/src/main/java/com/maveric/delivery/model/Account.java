package com.maveric.delivery.model;

import com.maveric.delivery.model.embedded.*;
import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;


import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * @author ankushk
 */
@Data
@Document(collection = "accounts")
public class Account  extends IdentifiedEntity{
    private String accountName;
    private AccountType accountType;
    private List<String> tags;
    private List<DedRoles> dedRoles;
    private Long dateOnboarded;
    private AccountStatus status;
    private String externalId;
    private ClientInformation clientInfo;
    private UUID createdBy;
    private Long createdAt;
    private UUID updatedBy;
    private Long updatedAt;

}
