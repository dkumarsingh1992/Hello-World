package com.maveric.delivery.repository;

import com.maveric.delivery.model.ProjectRole;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProjectRoleRepository extends MongoRepository<ProjectRole,Long> {
}
