package com.maveric.delivery.mapper;

import org.mapstruct.Mapper;


/**
 * @author ankushk
 */

@Mapper
public interface AccountMapper {

}
