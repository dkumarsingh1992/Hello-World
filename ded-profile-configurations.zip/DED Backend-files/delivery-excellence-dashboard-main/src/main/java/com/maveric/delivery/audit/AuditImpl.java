package com.maveric.delivery.audit;

import com.maveric.delivery.model.AzureUsers;
import com.maveric.delivery.repository.AuditRepository;
import com.maveric.delivery.repository.AzureUserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuditImpl {

    private final AuditRepository auditRepository;
    private final AzureUserRepository azureUserRepository;
    public void log(Audit audit) {
        audit.setTimestamp(LocalDateTime.now());
        if(null != audit.getOid())
            audit.setUsername((azureUserRepository.findById(audit.getOid())).map(AzureUsers::getDisplayName).orElse(null));
        log.info("Audit logged");
        auditRepository.save(audit);
    }


}