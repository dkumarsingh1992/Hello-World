package com.maveric.delivery.config;

public class SwaggerConfig  {
}