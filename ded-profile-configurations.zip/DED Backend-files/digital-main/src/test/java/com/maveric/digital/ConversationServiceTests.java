package com.maveric.digital;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.ContextConfiguration;

import com.maveric.digital.exceptions.AssessmentNotFoundException;
import com.maveric.digital.exceptions.ScoreCategoryNotFoundException;
import com.maveric.digital.exceptions.ScoreScaleNotFoundException;
import com.maveric.digital.exceptions.TemplateNotFoundException;
import com.maveric.digital.service.ConversationService;

@WebMvcTest
@AutoConfigureMockMvc
@ContextConfiguration(classes = { ConversationService.class })
class ConversationServiceTests {
	private static final String SCORE_NOT_FOUND = "Score Scale not found";
	private static final String TEMPLATE_NOT_FOUND = "Template not found";
	private static final String ASSESSMENT_NOT_FOUND = "Assessment not found";
	private static final String SCORE_CATEGORY_NOT_FOUND = "Score Category not found";

	@Test
	void AllExceptions() {
		ConversationService conversationService = new ConversationService();
		TemplateNotFoundException templateNotFoundExceptionDto = assertThrows(TemplateNotFoundException.class,
				() -> conversationService.toTemplateDto(null));
		TemplateNotFoundException templateNotFoundExceptionDtos = assertThrows(TemplateNotFoundException.class,
				() -> conversationService.toTemplateDtos(List.of()));

		ScoreScaleNotFoundException scoreScaleNotFoundExceptionDto = assertThrows(ScoreScaleNotFoundException.class,
				() -> conversationService.toScoreDto(null));
		ScoreScaleNotFoundException scoreScaleNotFoundExceptionDtos = assertThrows(ScoreScaleNotFoundException.class,
				() -> conversationService.toScoreDtos(List.of()));

		AssessmentNotFoundException assessmentNotFoundExceptionDto = assertThrows(AssessmentNotFoundException.class,
				() -> conversationService.toAssessmentDto(null));
		AssessmentNotFoundException assessmentNotFoundExceptionDtos = assertThrows(AssessmentNotFoundException.class,
				() -> conversationService.toAssessmentDtos(List.of()));

		ScoreCategoryNotFoundException scoreCategoryNotFoundExceptionDto = assertThrows(
				ScoreCategoryNotFoundException.class, () -> conversationService.toScoreCategoryDto(null));
		ScoreCategoryNotFoundException scoreCategoryNotFoundExceptionDtos = assertThrows(
				ScoreCategoryNotFoundException.class, () -> conversationService.toScoreCategoryDtos(List.of()));

		assertEquals(TEMPLATE_NOT_FOUND, templateNotFoundExceptionDto.getMessage());
		assertEquals(TEMPLATE_NOT_FOUND, templateNotFoundExceptionDtos.getMessage());
		assertEquals(SCORE_NOT_FOUND, scoreScaleNotFoundExceptionDto.getMessage());
		assertEquals(SCORE_NOT_FOUND, scoreScaleNotFoundExceptionDtos.getMessage());
		assertEquals(ASSESSMENT_NOT_FOUND, assessmentNotFoundExceptionDto.getMessage());
		assertEquals(ASSESSMENT_NOT_FOUND, assessmentNotFoundExceptionDtos.getMessage());
		assertEquals(SCORE_CATEGORY_NOT_FOUND, scoreCategoryNotFoundExceptionDto.getMessage());
		assertEquals(SCORE_CATEGORY_NOT_FOUND, scoreCategoryNotFoundExceptionDtos.getMessage());

	}

}
