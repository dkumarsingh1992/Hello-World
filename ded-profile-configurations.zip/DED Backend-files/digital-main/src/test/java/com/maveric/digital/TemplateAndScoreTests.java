package com.maveric.digital;

import static java.util.Collections.singletonList;
import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.maveric.digital.controller.Controller;
import com.maveric.digital.model.ScoringScale;
import com.maveric.digital.model.Template;
import com.maveric.digital.model.embedded.Options;
import com.maveric.digital.model.embedded.ProjectPhase;
import com.maveric.digital.model.embedded.ScoreRange;
import com.maveric.digital.model.embedded.TemplateQuestionnaire;
import com.maveric.digital.service.ScoreScaleService;
import com.maveric.digital.service.TemplateService;

@WebMvcTest
@AutoConfigureMockMvc
@ContextConfiguration(classes = { Controller.class, TemplateService.class,ScoreScaleService.class })
class TemplateAndScoreTests {
	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private TemplateService templateService;
	@MockBean
	private ScoreScaleService scoreScaleService;

	@MockBean
	private Controller controller;

	private Template beforeExecution() {
		Template domain = new Template();
		domain.setId(1l);
		domain.setProjectType("internal");
		domain.setCreatedAt(System.currentTimeMillis());
		domain.setUpdatedAt(System.currentTimeMillis());
		domain.setTemplatedUploadedUserName("Template1");
		domain.setProjectPhase(singletonList(this.populateProjectPhase()));
		return domain;

	}

	private ProjectPhase populateProjectPhase() {
		ProjectPhase projectPhase = new ProjectPhase();
		projectPhase.setPhaseName("Intial Phase");
		projectPhase.setTemplateQuestionnaire(singletonList(this.populateTemplateQuestionnaire()));
		return projectPhase;
	}

	private TemplateQuestionnaire populateTemplateQuestionnaire() {
		TemplateQuestionnaire questionnaire = new TemplateQuestionnaire();
		questionnaire.setFieldType("radio");
		questionnaire.setQuestion("How well-defined are the project objectives?");
		questionnaire.setScoreCategoery("importance");
		return questionnaire;

	}

	private Options populateOptions() {
		Options options = new Options();
		options.setLabel("Very well-defined");
		options.setOptionId(1l);
		options.setOptionIndex(1);
		return options;
	}

	private ScoringScale populateScoringScale() {
		ScoringScale scoringScale = new ScoringScale();
		scoringScale.setComment("Test");
		scoringScale.setCreatedBy("Ravi");
		scoringScale.setCreatedAt(System.currentTimeMillis());
		scoringScale.setId(1l);
		scoringScale.setRang(singletonList(this.populateScoreRange()));
		return scoringScale;
	}
	
	private ScoreRange populateScoreRange() {
		ScoreRange scoreRange = new ScoreRange();
		scoreRange.setFrom(1);
		scoreRange.setTo(5);
		scoreRange.setName("score1");
		scoreRange.setOptionIndex(1);
		return scoreRange;
	}
	
	@Test
	void getAllScoresScale() throws Exception {
		ScoringScale domain=this.populateScoringScale();
		when(scoreScaleService.getScoreScale()).thenReturn(singletonList(domain));
		mockMvc.perform(get("/api/v1/all/scorecale").contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
		is(domain.getId());

	}
	 

	@Test
	void getTemplateByProject() throws Exception {
		Template domain = this.beforeExecution();
		when(templateService.getTemplateByProjectType("internal")).thenReturn(singletonList(domain));
		mockMvc.perform(get("/api/v1/project/1/templates").contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
		is(domain.getId());

	}

}
