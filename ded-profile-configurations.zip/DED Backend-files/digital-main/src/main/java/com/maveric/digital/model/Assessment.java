package com.maveric.digital.model;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import com.maveric.digital.model.embedded.AssessmentProjectPhase;
import com.maveric.digital.model.embedded.AssessmentStatus;
import com.maveric.digital.model.embedded.Reviwer;

@Document(value = "assessment")
public class Assessment extends IdentifiedEntity {
	private Long submitedAt;
	private Integer templatedUploadedUser;
	private Integer submitedBy;
	private Long projectId;
	@DBRef
	private Template template;
	private List<Reviwer> reviwers;
	private List<AssessmentProjectPhase> projectPhase;
	private AssessmentStatus submitStatus;
	private Long createdAt;
	private Long updatedAt;

	public Long getSubmitedAt() {
		return submitedAt;
	}

	public void setSubmitedAt(Long submitedAt) {
		this.submitedAt = submitedAt;
	}

	public Integer getTemplatedUploadedUser() {
		return templatedUploadedUser;
	}

	public void setTemplatedUploadedUser(Integer templatedUploadedUser) {
		this.templatedUploadedUser = templatedUploadedUser;
	}

	public Integer getSubmitedBy() {
		return submitedBy;
	}

	public void setSubmitedBy(Integer submitedBy) {
		this.submitedBy = submitedBy;
	}

	public Long getProjectId() {
		return projectId;
	}

	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}

	public Template getTemplate() {
		return template;
	}

	public void setTemplate(Template template) {
		this.template = template;
	}

	public List<Reviwer> getReviwers() {
		return reviwers;
	}

	public void setReviwers(List<Reviwer> reviwers) {
		this.reviwers = reviwers;
	}

	public List<AssessmentProjectPhase> getProjectPhase() {
		return projectPhase;
	}

	public void setProjectPhase(List<AssessmentProjectPhase> projectPhase) {
		this.projectPhase = projectPhase;
	}

	public AssessmentStatus getSubmitStatus() {
		return submitStatus;
	}

	public void setSubmitStatus(AssessmentStatus submitStatus) {
		this.submitStatus = submitStatus;
	}

	public Long getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Long createdAt) {
		this.createdAt = createdAt;
	}

	public Long getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Long updatedAt) {
		this.updatedAt = updatedAt;
	}

}
