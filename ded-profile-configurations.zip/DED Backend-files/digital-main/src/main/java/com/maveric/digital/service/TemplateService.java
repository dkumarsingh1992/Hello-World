package com.maveric.digital.service;

import java.util.List;

import com.maveric.digital.model.Template;

public interface TemplateService {
	List<Template> getTemplateByProjectType(String projectType);

}
