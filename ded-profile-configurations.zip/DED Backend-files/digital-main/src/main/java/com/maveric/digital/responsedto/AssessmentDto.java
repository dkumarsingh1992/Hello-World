package com.maveric.digital.responsedto;

import java.util.List;

import com.maveric.digital.model.embedded.AssessmentProjectPhase;
import com.maveric.digital.model.embedded.AssessmentStatus;
import com.maveric.digital.model.embedded.Reviwer;

public class AssessmentDto {
	private Long assessmentId;
	private Long submitedAt;
	private Integer templatedUploadedUser;
	private Integer submitedBy;
	private Long projectId;
	private TemplateDto template;
	private List<Reviwer> reviwers;
	private List<AssessmentProjectPhase> projectPhase;
	private AssessmentStatus submitStatus;

	public Long getAssessmentId() {
		return assessmentId;
	}

	public void setAssessmentId(Long assessmentId) {
		this.assessmentId = assessmentId;
	}

	public Long getSubmitedAt() {
		return submitedAt;
	}

	public void setSubmitedAt(Long submitedAt) {
		this.submitedAt = submitedAt;
	}

	public Integer getTemplatedUploadedUser() {
		return templatedUploadedUser;
	}

	public void setTemplatedUploadedUser(Integer templatedUploadedUser) {
		this.templatedUploadedUser = templatedUploadedUser;
	}

	public Integer getSubmitedBy() {
		return submitedBy;
	}

	public void setSubmitedBy(Integer submitedBy) {
		this.submitedBy = submitedBy;
	}

	public Long getProjectId() {
		return projectId;
	}

	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}

	public List<Reviwer> getReviwers() {
		return reviwers;
	}

	public void setReviwers(List<Reviwer> reviwers) {
		this.reviwers = reviwers;
	}

	public List<AssessmentProjectPhase> getProjectPhase() {
		return projectPhase;
	}

	public void setProjectPhase(List<AssessmentProjectPhase> projectPhase) {
		this.projectPhase = projectPhase;
	}

	public TemplateDto getTemplate() {
		return template;
	}

	public void setTemplate(TemplateDto template) {
		this.template = template;
	}

	public AssessmentStatus getSubmitStatus() {
		return submitStatus;
	}

	public void setSubmitStatus(AssessmentStatus submitStatus) {
		this.submitStatus = submitStatus;
	}

}
