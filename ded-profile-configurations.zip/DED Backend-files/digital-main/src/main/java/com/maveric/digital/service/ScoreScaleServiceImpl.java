package com.maveric.digital.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.digital.exceptions.ScoreScaleNotFoundException;
import com.maveric.digital.model.ScoringScale;
import com.maveric.digital.repository.ScoreScaleRepository;

@Service
public class ScoreScaleServiceImpl implements ScoreScaleService {
	private static final String SCORE_NOT_FOUND = "Score Scale not found";
	private final ScoreScaleRepository scoreRepository;
	private final ObjectMapper mapper;
	Logger logger = LoggerFactory.getLogger(ScoreScaleServiceImpl.class);

	@Autowired
	public ScoreScaleServiceImpl(ScoreScaleRepository scoreRepository, ObjectMapper mapper) {
		this.scoreRepository = scoreRepository;
		this.mapper = mapper;

	}

	@Override
	public List<ScoringScale> getScoreScale() throws JsonProcessingException {
		logger.debug("ScoreScaleServiceImpl::getScoreScale()::Start");
		List<ScoringScale> scores = scoreRepository.findAll();
		if (CollectionUtils.isEmpty(scores)) {
			throw new ScoreScaleNotFoundException(SCORE_NOT_FOUND);
		}

		if (!CollectionUtils.isEmpty(scores)) {
			logger.debug("ScoreScaleServiceImpl::getScoreScale()::scores::{}", mapper.writeValueAsString(scores));
			return scores;
		}
		logger.debug("ScoreScaleServiceImpl::getScoreScale()::End");
		return List.of();
	}

}
