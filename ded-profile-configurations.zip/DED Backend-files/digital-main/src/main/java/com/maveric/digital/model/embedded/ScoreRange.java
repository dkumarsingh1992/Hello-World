package com.maveric.digital.model.embedded;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class ScoreRange {
	@NotBlank(message = "score range name should not blank")
	private String name;
	@NotNull(message = "from shold not be null")
	private Integer from;
	@NotNull(message = "from shold not be null")
	private Integer to;
	private Integer optionIndex;
	

	public Integer getOptionIndex() {
		return optionIndex;
	}

	public void setOptionIndex(Integer optionIndex) {
		this.optionIndex = optionIndex;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getFrom() {
		return from;
	}

	public void setFrom(Integer from) {
		this.from = from;
	}

	public Integer getTo() {
		return to;
	}

	public void setTo(Integer to) {
		this.to = to;
	}

}
