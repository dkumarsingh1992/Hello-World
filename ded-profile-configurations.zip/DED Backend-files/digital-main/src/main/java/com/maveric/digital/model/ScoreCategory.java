package com.maveric.digital.model;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.maveric.digital.model.embedded.Options;

@Document(value = "scoreCategory")
public class ScoreCategory extends IdentifiedEntity {

	private String categoryName;
	private List<Options> categoryOptions;
	private Long createdAt;
	private Long updatedAt;
	private String createdBy;

	public Long getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Long createdAt) {
		this.createdAt = createdAt;
	}

	public Long getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Long updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public List<Options> getCategoryOptions() {
		return categoryOptions;
	}

	public void setCategoryOptions(List<Options> categoryOptions) {
		this.categoryOptions = categoryOptions;
	}

}
