package com.maveric.digital.model.embedded;

public class Reviwer {
	private Integer reviewerId;
	private Integer reviewerAt;
	private String comment;

	public Integer getReviewerId() {
		return reviewerId;
	}

	public void setReviewerId(Integer reviewerId) {
		this.reviewerId = reviewerId;
	}

	public Integer getReviewerAt() {
		return reviewerAt;
	}

	public void setReviewerAt(Integer reviewerAt) {
		this.reviewerAt = reviewerAt;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

}
