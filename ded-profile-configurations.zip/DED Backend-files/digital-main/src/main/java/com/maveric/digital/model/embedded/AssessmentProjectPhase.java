package com.maveric.digital.model.embedded;

import java.util.List;

public class AssessmentProjectPhase {
	private String phaseName;
	private List<QuestionAnswer> questionAnswers;

	public String getPhaseName() {
		return phaseName;
	}

	public void setPhaseName(String phaseName) {
		this.phaseName = phaseName;
	}

	public List<QuestionAnswer> getQuestionAnswers() {
		return questionAnswers;
	}

	public void setQuestionAnswers(List<QuestionAnswer> questionAnswers) {
		this.questionAnswers = questionAnswers;
	}

}
