package com.maveric.digital.model;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import com.maveric.digital.model.embedded.ProjectPhase;

@Document(value = "template")
public class Template extends IdentifiedEntity {

	private String templateName;
	private Integer templatedUploadedUserId;
	private String projectType;
	private Long createdAt;
	private Long updatedAt;
	private String templatedUploadedUserName;
	private List<ProjectPhase> projectPhase;
	@DBRef
	private ScoringScale score;
	@DBRef
	private List<ScoreCategory> scoreCategories;

	public List<ScoreCategory> getScoreCategories() {
		return scoreCategories;
	}

	public void setScoreCategories(List<ScoreCategory> scoreCategories) {
		this.scoreCategories = scoreCategories;
	}

	public String getProjectType() {
		return projectType;
	}

	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}

	public List<ProjectPhase> getProjectPhase() {
		return projectPhase;
	}

	public void setProjectPhase(List<ProjectPhase> projectPhase) {
		this.projectPhase = projectPhase;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public Integer getTemplatedUploadedUserId() {
		return templatedUploadedUserId;
	}

	public void setTemplatedUploadedUserId(Integer templatedUploadedUserId) {
		this.templatedUploadedUserId = templatedUploadedUserId;
	}

	public String getTemplatedUploadedUserName() {
		return templatedUploadedUserName;
	}

	public void setTemplatedUploadedUserName(String templatedUploadedUserName) {
		this.templatedUploadedUserName = templatedUploadedUserName;
	}

	public ScoringScale getScore() {
		return score;
	}

	public void setScore(ScoringScale score) {
		this.score = score;
	}

	public Long getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Long createdAt) {
		this.createdAt = createdAt;
	}

	public Long getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Long updatedAt) {
		this.updatedAt = updatedAt;
	}

}
