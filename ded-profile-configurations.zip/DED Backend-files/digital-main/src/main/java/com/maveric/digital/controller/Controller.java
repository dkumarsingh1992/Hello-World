package com.maveric.digital.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.maveric.digital.responsedto.ScoreScaleDto;
import com.maveric.digital.responsedto.TemplateDto;
import com.maveric.digital.service.ConversationService;
import com.maveric.digital.service.ScoreScaleService;
import com.maveric.digital.service.TemplateService;

@RestController
@RequestMapping("api/v1")
public class Controller {
	Logger logger = LoggerFactory.getLogger(Controller.class);
	@Autowired
	private TemplateService templateService;
	@Autowired
	private ConversationService conversationService;
	@Autowired
	private ScoreScaleService scoreService;

	@GetMapping(value = "/project/{projectType}/templates")
	ResponseEntity<List<TemplateDto>> getTempate(@PathVariable("projectType") String projectType) {
		logger.debug("Controller::getTempate()::projectType::{}",projectType);
		return ResponseEntity.ok().body(conversationService.toTemplateDtos(templateService.getTemplateByProjectType(projectType)));
	}

	@GetMapping(value = "/all/scorecale")
	ResponseEntity<List<ScoreScaleDto>> getAllScoresScale() throws JsonProcessingException {
		return ResponseEntity.ok().body(conversationService.toScoreDtos(scoreService.getScoreScale()));
	}

}
