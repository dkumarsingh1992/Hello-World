package com.maveric.digital.model;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.maveric.digital.model.embedded.ScoreRange;

@Document(value = "scoringScale")
public class ScoringScale extends IdentifiedEntity {

	private String name;
	private List<ScoreRange> rang;
	private Long createdAt;
	private Long updatedAt;
	private String comment;
	private String createdBy;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Long getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Long createdAt) {
		this.createdAt = createdAt;
	}

	public Long getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Long updatedAt) {
		this.updatedAt = updatedAt;
	}

	public List<ScoreRange> getRang() {
		return rang;
	}

	public void setRang(List<ScoreRange> rang) {
		this.rang = rang;
	}

}
