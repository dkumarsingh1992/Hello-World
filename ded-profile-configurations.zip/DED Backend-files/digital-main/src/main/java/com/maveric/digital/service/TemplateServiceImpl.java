package com.maveric.digital.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.maveric.digital.model.Template;
import com.maveric.digital.repository.TemplateRepository;

@Service
public class TemplateServiceImpl implements TemplateService {
	private final TemplateRepository templateRepository;
	Logger logger = LoggerFactory.getLogger(TemplateServiceImpl.class);

	@Autowired
	public TemplateServiceImpl(TemplateRepository templateRepository) {
		this.templateRepository = templateRepository;
	}

	public List<Template> getTemplateByProjectType(String projectType) {
		logger.debug("TemplateService::getTempate()::projectType::{}", projectType);
		return templateRepository.findByProjectType(projectType);

	}

}
