package com.maveric.digital.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.maveric.digital.model.Template;


@Repository
public interface TemplateRepository extends MongoRepository<Template, Long> {
	
	List<Template> findByProjectType(String projectType);

}
