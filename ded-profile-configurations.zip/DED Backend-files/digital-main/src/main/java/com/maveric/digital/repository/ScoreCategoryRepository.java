package com.maveric.digital.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.maveric.digital.model.ScoreCategory;


@Repository
public interface ScoreCategoryRepository extends MongoRepository<ScoreCategory, Long> {
	
}
