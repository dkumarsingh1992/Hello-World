package com.maveric.digital.service;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.maveric.digital.exceptions.AssessmentNotFoundException;
import com.maveric.digital.exceptions.ScoreCategoryNotFoundException;
import com.maveric.digital.exceptions.ScoreScaleNotFoundException;
import com.maveric.digital.exceptions.TemplateNotFoundException;
import com.maveric.digital.model.Assessment;
import com.maveric.digital.model.ScoreCategory;
import com.maveric.digital.model.ScoringScale;
import com.maveric.digital.model.Template;
import com.maveric.digital.responsedto.AssessmentDto;
import com.maveric.digital.responsedto.ScoreCategoryDto;
import com.maveric.digital.responsedto.ScoreScaleDto;
import com.maveric.digital.responsedto.TemplateDto;

@Service
public class ConversationService {

	Logger logger = LoggerFactory.getLogger(ConversationService.class);
	private static final String SCORE_NOT_FOUND = "Score Scale not found";
	private static final String TEMPLATE_NOT_FOUND = "Template not found";
	private static final String ASSESSMENT_NOT_FOUND = "Assessment not found";
	private static final String SCORE_CATEGORY_NOT_FOUND = "Score Category not found";

	public TemplateDto toTemplateDto(Template domain) {
		if(Objects.isNull(domain)) {
			throw new TemplateNotFoundException(TEMPLATE_NOT_FOUND);
		}
		logger.debug("ConversationService::toTemplateDto()::Start");
		TemplateDto dto = new TemplateDto();
		dto.setTemplateName(domain.getTemplateName());
		dto.setTemplateId(domain.getId());
		dto.setProjectType(domain.getProjectType());
		dto.setScore(this.toScoreDto(domain.getScore()));
		dto.setTemplatedUploadedUserName(domain.getTemplatedUploadedUserName());
		dto.setProjectPhase(domain.getProjectPhase());
		dto.setTemplatedUploadedUserId(domain.getTemplatedUploadedUserId());
		dto.setScoreCategories(this.toScoreCategoryDtos(domain.getScoreCategories()));
		logger.debug("ConversationService::toTemplateDto()::End");
		return dto;
	}

	public ScoreScaleDto toScoreDto(ScoringScale domain) {
		logger.debug("ConversationService::toScoreDto()::Start");
		if (Objects.isNull(domain)) {
			logger.debug("ConversationService::toScoreDto()::End");
			throw new ScoreScaleNotFoundException(SCORE_NOT_FOUND);
		}
		ScoreScaleDto dto = new ScoreScaleDto();
		dto.setId(domain.getId());
		dto.setRang(domain.getRang());
		logger.debug("ConversationService::toScoreDto()::End");
		return dto;
	}

	public List<ScoreScaleDto> toScoreDtos(List<ScoringScale> domains) {
		if (CollectionUtils.isEmpty(domains)) {
			throw new ScoreScaleNotFoundException(SCORE_NOT_FOUND);
		}
		return domains.stream().filter(Objects::nonNull).map(this::toScoreDto).collect(Collectors.toList());
	}

	public List<TemplateDto> toTemplateDtos(List<Template> domains) {
		if (CollectionUtils.isEmpty(domains)) {
			throw new TemplateNotFoundException(TEMPLATE_NOT_FOUND);
		}
		return domains.stream().filter(Objects::nonNull).map(this::toTemplateDto).collect(Collectors.toList());
	}

	public AssessmentDto toAssessmentDto(Assessment domain) {
		logger.debug("ConversationService::toAssessmentDto()::Start");
		AssessmentDto dto = new AssessmentDto();
		if (Objects.isNull(domain)) {
			logger.debug("ConversationService::toAssessmentDto::End");
			throw new AssessmentNotFoundException(ASSESSMENT_NOT_FOUND);
		}
		dto.setAssessmentId(domain.getId());
		dto.setProjectId(domain.getProjectId());
		dto.setProjectPhase(domain.getProjectPhase());
		dto.setReviwers(domain.getReviwers());
		dto.setSubmitedAt(domain.getSubmitedAt());
		dto.setSubmitedBy(domain.getSubmitedBy());
		dto.setSubmitStatus(domain.getSubmitStatus());
		if (Objects.nonNull(domain.getTemplate())) {
			dto.setTemplate(this.toTemplateDto(domain.getTemplate()));
		}
		dto.setTemplatedUploadedUser(domain.getTemplatedUploadedUser());
		logger.debug("ConversationService::toAssessmentDto()::End");
		return dto;

	}

	public List<AssessmentDto> toAssessmentDtos(List<Assessment> domains) {
		if (CollectionUtils.isEmpty(domains)) {
			throw new AssessmentNotFoundException(ASSESSMENT_NOT_FOUND);
		}
		return domains.stream().filter(Objects::nonNull).map(this::toAssessmentDto).collect(Collectors.toList());
	}

	public List<ScoreCategoryDto> toScoreCategoryDtos(List<ScoreCategory> domains) {
		if (CollectionUtils.isEmpty(domains)) {
			throw new ScoreCategoryNotFoundException(SCORE_CATEGORY_NOT_FOUND);
		}
		return domains.stream().filter(Objects::nonNull).map(this::toScoreCategoryDto).collect(Collectors.toList());
	}

	public ScoreCategoryDto toScoreCategoryDto(ScoreCategory domain) {
		logger.debug("ConversationService::toScoreCategoryDto()::Start");
		ScoreCategoryDto dto = new ScoreCategoryDto();
		if (Objects.isNull(domain)) {
			logger.debug("ConversationService::toScoreCategoryDto()::End");
			throw new ScoreCategoryNotFoundException(SCORE_CATEGORY_NOT_FOUND);
		}
		dto.setCategoryId(domain.getId());
		dto.setCategoryName(domain.getCategoryName());
		dto.setCategoryOptions(domain.getCategoryOptions());
		logger.debug("ConversationService::toScoreCategoryDto()::End");
		return dto;
	}

}
