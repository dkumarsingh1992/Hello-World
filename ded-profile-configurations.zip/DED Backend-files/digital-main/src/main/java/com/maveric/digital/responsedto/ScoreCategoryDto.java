package com.maveric.digital.responsedto;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.maveric.digital.model.embedded.Options;

@Document(value = "scoreCategory")
public class ScoreCategoryDto {
	private Long categoryId;
	private String categoryName;
	private List<Options> categoryOptions;

	public Long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public List<Options> getCategoryOptions() {
		return categoryOptions;
	}

	public void setCategoryOptions(List<Options> categoryOptions) {
		this.categoryOptions = categoryOptions;
	}

}
