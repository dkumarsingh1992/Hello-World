package com.maveric.digital.responsedto;

import java.util.List;

import com.maveric.digital.model.embedded.ProjectPhase;

public class TemplateDto {

	private Long templateId;
	private String templateName;
	private Integer templatedUploadedUserId;
	private String projectType;
	private String templatedUploadedUserName;
	private ScoreScaleDto score;
	private List<ProjectPhase> projectPhase;
	private List<ScoreCategoryDto> scoreCategories;

	public List<ScoreCategoryDto> getScoreCategories() {
		return scoreCategories;
	}

	public void setScoreCategories(List<ScoreCategoryDto> scoreCategories) {
		this.scoreCategories = scoreCategories;
	}

	public String getProjectType() {
		return projectType;
	}

	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}

	public List<ProjectPhase> getProjectPhase() {
		return projectPhase;
	}

	public void setProjectPhase(List<ProjectPhase> projectPhase) {
		this.projectPhase = projectPhase;
	}

	public ScoreScaleDto getScore() {
		return score;
	}

	public void setScore(ScoreScaleDto score) {
		this.score = score;
	}

	public Long getTemplateId() {
		return templateId;
	}

	public void setTemplateId(Long templateId) {
		this.templateId = templateId;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public Integer getTemplatedUploadedUserId() {
		return templatedUploadedUserId;
	}

	public void setTemplatedUploadedUserId(Integer templatedUploadedUserId) {
		this.templatedUploadedUserId = templatedUploadedUserId;
	}

	public String getTemplatedUploadedUserName() {
		return templatedUploadedUserName;
	}

	public void setTemplatedUploadedUserName(String templatedUploadedUserName) {
		this.templatedUploadedUserName = templatedUploadedUserName;
	}

}
