package com.maveric.digital.model.embedded;

public enum AssessmentStatus {
   SAVE,
   SUBMITTED
}
