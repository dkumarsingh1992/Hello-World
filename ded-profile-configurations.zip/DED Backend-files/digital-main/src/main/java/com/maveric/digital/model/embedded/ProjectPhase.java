package com.maveric.digital.model.embedded;

import java.util.List;

public class ProjectPhase {

	private String phaseName;
	private List<TemplateQuestionnaire> templateQuestionnaire;

	public String getPhaseName() {
		return phaseName;
	}

	public void setPhaseName(String phaseName) {
		this.phaseName = phaseName;
	}

	public List<TemplateQuestionnaire> getTemplateQuestionnaire() {
		return templateQuestionnaire;
	}

	public void setTemplateQuestionnaire(List<TemplateQuestionnaire> templateQuestionnaire) {
		this.templateQuestionnaire = templateQuestionnaire;
	}

}
