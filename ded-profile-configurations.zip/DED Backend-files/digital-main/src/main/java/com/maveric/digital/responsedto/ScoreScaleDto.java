package com.maveric.digital.responsedto;

import java.util.List;

import com.maveric.digital.model.embedded.ScoreRange;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class ScoreScaleDto {
	private Long id;
	@NotBlank(message = "name should not blank")
	private String name;
	@NotNull(message = "rang should not blank")
	private List<ScoreRange> rang;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<ScoreRange> getRang() {
		return rang;
	}

	public void setRang(List<ScoreRange> rang) {
		this.rang = rang;
	}

}
