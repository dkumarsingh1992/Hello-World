package com.maveric.digital.model.embedded;

public class TemplateQuestionnaire {
	private Integer questionId;
	private String question;
	private String fieldType;
	private String scoreCategoery;

	public Integer getQuestionId() {
		return questionId;
	}

	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}

	public String getScoreCategoery() {
		return scoreCategoery;
	}

	public void setScoreCategoery(String scoreCategoery) {
		this.scoreCategoery = scoreCategoery;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getFieldType() {
		return fieldType;
	}

	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}

}
