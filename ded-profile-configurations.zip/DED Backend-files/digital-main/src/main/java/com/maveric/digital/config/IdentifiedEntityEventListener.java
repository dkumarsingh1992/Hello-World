package com.maveric.digital.config;

import java.util.Objects;
import java.util.Random;

import org.springframework.data.mongodb.core.mapping.event.AbstractMongoEventListener;
import org.springframework.data.mongodb.core.mapping.event.BeforeConvertEvent;
import org.springframework.stereotype.Component;

import com.maveric.digital.model.IdentifiedEntity;

@Component
public class IdentifiedEntityEventListener extends AbstractMongoEventListener<IdentifiedEntity> {

	@Override
	public void onBeforeConvert(BeforeConvertEvent<IdentifiedEntity> event) {
		super.onBeforeConvert(event);
		IdentifiedEntity domain = event.getSource();
		if (Objects.isNull(domain.getId())) {
			domain.setId(Math.abs(new Random().nextLong()));
		}
	}

}
